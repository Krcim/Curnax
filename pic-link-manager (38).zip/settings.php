<?php
/**
 * 设置页面 - 导出/导入数据
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/Storage.php';
require_once __DIR__ . '/includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { header('Location: index.php'); exit; }
$user = $auth->user();

$images = new Storage(FILE_IMAGES);
$links = new Storage(FILE_LINKS);
$folders = new Storage(FILE_FOLDERS);

$msgType = ''; $msgText = '';

// 计算 OUTPUT_PATH（项目目录下的 output）
define('OUTPUT_PATH', BASE_PATH . '/output');

// 主题配置文件
define('THEME_CONFIG', DATA_PATH . '/theme_config.json');
define('FOOTER_CONFIG', DATA_PATH . '/footer_config.json');
define('QUICK_ACCESS_CONFIG', DATA_PATH . '/quick_access.json');

// 读取主题配置
function loadThemeConfig() {
    if (!file_exists(THEME_CONFIG)) return ['bg_style' => 'default'];
    return json_decode(file_get_contents(THEME_CONFIG), true) ?: ['bg_style' => 'default'];
}
function saveThemeConfig($cfg) {
    file_put_contents(THEME_CONFIG, json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}
// 读取页脚配置
function loadFooterConfig() {
    if (!file_exists(FOOTER_CONFIG)) return ['content' => '', 'show_on' => []];
    return json_decode(file_get_contents(FOOTER_CONFIG), true) ?: ['content' => '', 'show_on' => []];
}
function saveFooterConfig($cfg) {
    file_put_contents(FOOTER_CONFIG, json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

function loadQuickAccessConfig() {
    if (!file_exists(QUICK_ACCESS_CONFIG)) return ['url' => '', 'ftp' => ['host' => '', 'port' => '21', 'user' => '', 'pass' => '']];
    return json_decode(file_get_contents(QUICK_ACCESS_CONFIG), true) ?: ['url' => '', 'ftp' => ['host' => '', 'port' => '21', 'user' => '', 'pass' => '']];
}
function saveQuickAccessConfig($cfg) {
    file_put_contents(QUICK_ACCESS_CONFIG, json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}

$themeCfg = loadThemeConfig();
$footerCfg = loadFooterConfig();
$quickAccessCfg = loadQuickAccessConfig();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 导出数据
    if ($action === 'export') {
        if (!is_dir(OUTPUT_PATH)) mkdir(OUTPUT_PATH, 0755, true);

        $allFolders = $folders->all();
        $allImages = $images->all();
        $folderMap = [];
        foreach ($allFolders as $f) $folderMap[$f['id']] = $f['name'];

        // 构建文件夹→图片映射
        $folderImages = ['_unassigned' => []];
        foreach ($allFolders as $f) $folderImages[$f['id']] = [];
        foreach ($allImages as $img) {
            $fid = $img['folder_id'] ?? null;
            if ($fid && isset($folderImages[$fid])) {
                $folderImages[$fid][] = $img;
            } else {
                $folderImages['_unassigned'][] = $img;
            }
        }

        $timestamp = date('Ymd_His');
        $txtPath = OUTPUT_PATH . '/export_images_' . $timestamp . '.txt';
        $treePath = OUTPUT_PATH . '/export_structure_' . $timestamp . '.txt';

        // 生成结构化 TXT
        $txtLines = [];
        $txtLines[] = '# ' . SYS_NAME . ' 数据导出';
        $txtLines[] = '# 导出时间: ' . date('Y-m-d H:i:s');
        $txtLines[] = '# 用户: ' . $user['username'];
        $txtLines[] = '';
        $txtLines[] = str_repeat('=', 60);
        $txtLines[] = '';

        foreach ($folderImages as $fid => $imgs) {
            if (empty($imgs)) continue;

            $folderLabel = ($fid === '_unassigned') ? '未分类' : ($folderMap[$fid] ?? $fid);
            $txtLines[] = '=== ' . $folderLabel . ' ===';
            $txtLines[] = '';

            foreach ($imgs as $img) {
                $imgLinks = $links->where(['image_id' => $img['id']]);

                // 找出主链接和备用链接
                $primaryUrl = '';
                $backupUrls = [];
                foreach ($imgLinks as $lk) {
                    if ($lk['is_primary']) $primaryUrl = $lk['url'];
                    else $backupUrls[] = $lk['url'];
                }
                if (!$primaryUrl && !empty($imgLinks)) {
                    $primaryUrl = $imgLinks[0]['url'];
                    $backupUrls = array_slice(array_column($imgLinks, 'url'), 1);
                }

                $txtLines[] = '--- ' . $img['name'] . ' ---';
                if ($primaryUrl) $txtLines[] = '主链接: ' . $primaryUrl;
                foreach ($backupUrls as $bu) $txtLines[] = '备用: ' . $bu;

                $sizeStr = $img['file_size'] ? ($img['file_size'] > 1048576 ? round($img['file_size'] / 1048576, 1) . 'MB' : round($img['file_size'] / 1024, 1) . 'KB') : '未知大小';
                $typeStr = $img['file_type'] ?: '未知格式';
                $origStr = $img['original_name'] ?: '-';
                $txtLines[] = '[' . $typeStr . '] [' . $sizeStr . '] [' . $origStr . '] (' . $folderLabel . ')';
                $txtLines[] = '';
            }
        }

        file_put_contents($txtPath, implode("\n", $txtLines), LOCK_EX);

        // 生成目录结构文件
        $treeLines = [];
        $treeLines[] = SYS_NAME . ' 目录结构';
        $treeLines[] = '导出时间: ' . date('Y-m-d H:i:s');
        $treeLines[] = '';
        $treeLines[] = SYS_NAME . '/';
        $treeLines[] = '├── Stock/';
        $treeLines[] = '│   └── temp/  （缓存目录）';
        $treeLines[] = '├── data/';
        $treeLines[] = '│   ├── images.json  (' . count($allImages) . ' 条记录)';
        $treeLines[] = '│   ├── links.json   (' . count($links->all()) . ' 条记录)';
        $treeLines[] = '│   ├── folders.json (' . count($allFolders) . ' 个文件夹)';
        $treeLines[] = '│   ├── users.json';
        $treeLines[] = '│   └── settings.json';
        $treeLines[] = '├── output/';
        $treeLines[] = '├── includes/';
        $treeLines[] = '├── assets/';
        $treeLines[] = '├── api/';
        $treeLines[] = '';

        $folderTree = [];
        foreach ($allFolders as $f) {
            $fid = $f['id'];
            $fname = $f['name'];
            $fimgs = $folderImages[$fid] ?? [];
            $folderTree[] = ['name' => $fname, 'count' => count($fimgs), 'images' => $fimgs];
        }
        $uimgs = $folderImages['_unassigned'] ?? [];
        if ($uimgs) {
            $folderTree[] = ['name' => '未分类', 'count' => count($uimgs), 'images' => $uimgs];
        }

        for ($i = 0; $i < count($folderTree); $i++) {
            $ft = $folderTree[$i];
            $isLast = ($i === count($folderTree) - 1);
            $prefix = $isLast ? '└── ' : '├── ';
            $childPrefix = $isLast ? '    ' : '│   ';

            $treeLines[] = $prefix . '[' . $ft['name'] . '] (' . $ft['count'] . ' 张图片)';
            for ($j = 0; $j < count($ft['images']); $j++) {
                $img = $ft['images'][$j];
                $isLastImg = ($j === count($ft['images']) - 1);
                $ip = $isLastImg ? '└── ' : '├── ';
                $treeLines[] = $childPrefix . $ip . $img['name'] . ($img['original_name'] ? ' (' . $img['original_name'] . ')' : '');
            }
            if (count($ft['images']) > 0) $treeLines[] = $childPrefix;
        }

        file_put_contents($treePath, implode("\n", $treeLines), LOCK_EX);

        $msgType = 'ok';
        $msgText = '导出完成';
        $exportFiles = [$txtPath, $treePath];
    }

    // 系统级 JSON 数据导出
    elseif ($action === 'export_json') {
        if (!is_dir(OUTPUT_PATH)) mkdir(OUTPUT_PATH, 0755, true);

        $allImages = $images->all();
        $allLinks = $links->all();
        $allFolders = $folders->all();

        $exportData = [
            'system' => SYS_NAME,
            'version' => SYS_VERSION,
            'exported_at' => date('Y-m-d H:i:s'),
            'exported_by' => $user['username'],
            'images' => $allImages,
            'links' => $allLinks,
            'folders' => $allFolders,
        ];

        $timestamp = date('Ymd_His');
        $jsonPath = OUTPUT_PATH . '/system_export_' . $timestamp . '.json';
        $jsonContent = json_encode($exportData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        file_put_contents($jsonPath, $jsonContent, LOCK_EX);

        $exportJsonPath = $jsonPath;
        $msgType = 'ok';
        $msgText = 'JSON 导出完成';
    }

    // 导入数据
    elseif ($action === 'import') {
        $mode = $_POST['import_mode'] ?? 'merge'; // merge | overwrite

        if (!isset($_FILES['import_file']) || $_FILES['import_file']['error'] !== UPLOAD_ERR_OK) {
            $msgType = 'err'; $msgText = '文件上传失败';
        } else {
            $tmpFile = $_FILES['import_file']['tmp_name'];
            $content = file_get_contents($tmpFile);
            $importData = json_decode($content, true);

            if (!$importData || !is_array($importData)) {
                $msgType = 'err'; $msgText = 'JSON 格式无效';
            } else {
                $stats = ['images' => 0, 'links' => 0, 'folders' => 0];

                if ($mode === 'overwrite') {
                    // 覆盖模式：清空后写入
                    if (isset($importData['images']) && is_array($importData['images'])) {
                        file_put_contents(FILE_IMAGES, json_encode($importData['images'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
                        $stats['images'] = count($importData['images']);
                    }
                    if (isset($importData['links']) && is_array($importData['links'])) {
                        file_put_contents(FILE_LINKS, json_encode($importData['links'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
                        $stats['links'] = count($importData['links']);
                    }
                    if (isset($importData['folders']) && is_array($importData['folders'])) {
                        file_put_contents(FILE_FOLDERS, json_encode($importData['folders'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
                        $stats['folders'] = count($importData['folders']);
                    }
                    $msgType = 'ok';
                } else {
                    // 合并模式：追加（跳过同ID）
                    if (isset($importData['images']) && is_array($importData['images'])) {
                        $existing = $images->all();
                        $existIds = array_column($existing, 'id');
                        foreach ($importData['images'] as $img) {
                            if (!in_array($img['id'] ?? '', $existIds)) {
                                $images->insert($img);
                                $stats['images']++;
                            }
                        }
                    }
                    if (isset($importData['links']) && is_array($importData['links'])) {
                        $existing = $links->all();
                        $existIds = array_column($existing, 'id');
                        foreach ($importData['links'] as $lk) {
                            if (!in_array($lk['id'] ?? '', $existIds)) {
                                $links->insert($lk);
                                $stats['links']++;
                            }
                        }
                    }
                    if (isset($importData['folders']) && is_array($importData['folders'])) {
                        $existing = $folders->all();
                        $existIds = array_column($existing, 'id');
                        foreach ($importData['folders'] as $f) {
                            if (!in_array($f['id'] ?? '', $existIds)) {
                                $folders->insert($f);
                                $stats['folders']++;
                            }
                        }
                    }
                    $msgType = 'ok';
                }

                $msgText = sprintf('导入完成：图片 %d 条，链接 %d 条，文件夹 %d 个（%s模式）',
                    $stats['images'], $stats['links'], $stats['folders'],
                    $mode === 'overwrite' ? '覆盖' : '合并');
            }
        }
    }

    // 登录背景主题设置
    elseif ($action === 'save_bg_theme') {
        $bgStyle = $_POST['bg_style'] ?? 'default';
        $cfg = loadThemeConfig();
        $cfg['bg_style'] = $bgStyle;

        if ($bgStyle === 'image') {
            $imageMode = $_POST['image_mode'] ?? 'upload';
            $cfg['image_mode'] = $imageMode;

            if ($imageMode === 'upload' && isset($_FILES['bg_image']) && $_FILES['bg_image']['error'] === UPLOAD_ERR_OK) {
                $ext = strtolower(pathinfo($_FILES['bg_image']['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['jpg','jpeg','png','gif','webp','bmp'])) {
                    $msgType = 'err'; $msgText = '不支持的图片格式，仅支持 jpg/png/gif/webp/bmp';
                } else {
                    $dest = BASE_PATH . '/index_bg.' . $ext;
                    // 删除旧背景文件
                    foreach (glob(BASE_PATH . '/index_bg.*') as $old) unlink($old);
                    move_uploaded_file($_FILES['bg_image']['tmp_name'], $dest);
                    $cfg['bg_image_path'] = 'index_bg.' . $ext;
                    // 清除之前的在线背景
                    @unlink(BASE_PATH . '/Stock/online_bg.' . (pathinfo($cfg['bg_image_url_path'] ?? '', PATHINFO_EXTENSION) ?: 'jpg'));
                    unset($cfg['bg_image_url'], $cfg['bg_image_url_path']);
                    $msgType = 'ok'; $msgText = '背景图片已上传并设置';
                }
            } elseif ($imageMode === 'url' && !empty($_POST['bg_image_url'])) {
                $url = trim($_POST['bg_image_url']);
                $cfg['bg_image_url'] = $url;

                // 尝试下载保存到本地
                $urlExt = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION));
                if (!in_array($urlExt, ['jpg','jpeg','png','gif','webp','bmp'])) $urlExt = 'jpg';
                $stockDir = BASE_PATH . '/Stock';
                if (!is_dir($stockDir)) mkdir($stockDir, 0755, true);
                // 删除旧在线背景
                @unlink($stockDir . '/online_bg.' . (pathinfo($cfg['bg_image_url_path'] ?? '', PATHINFO_EXTENSION) ?: 'jpg'));
                $dest = $stockDir . '/online_bg.' . $urlExt;
                $imgData = @file_get_contents($url);
                if ($imgData) {
                    file_put_contents($dest, $imgData);
                    $cfg['bg_image_url_path'] = 'Stock/online_bg.' . $urlExt;
                    // 清除上传背景
                    foreach (glob(BASE_PATH . '/index_bg.*') as $old) unlink($old);
                    unset($cfg['bg_image_path']);
                    $msgType = 'ok'; $msgText = '在线背景已加载并保存到本地';
                } else {
                    // 下载失败，直接引用在线链接
                    $cfg['bg_image_url_path'] = '';
                    $msgType = 'ok'; $msgText = '已设置在线背景链接（将直接引用）';
                }
            }
        }
        saveThemeConfig($cfg);
        $themeCfg = loadThemeConfig();
        if (!$msgType) { $msgType = 'ok'; $msgText = '背景主题已更新'; }
    }

    // 页脚设置
    elseif ($action === 'save_footer') {
        $cfg = loadFooterConfig();
        $cfg['content'] = $_POST['footer_content'] ?? '';
        $cfg['show_on'] = $_POST['show_on'] ?? [];
        if (in_array('all', $cfg['show_on'])) $cfg['show_on'] = ['all'];
        saveFooterConfig($cfg);
        $footerCfg = loadFooterConfig();
        $msgType = 'ok'; $msgText = '页脚设置已保存';
    }

    // 快速访问设置
    elseif ($action === 'save_quick_access') {
        $cfg = loadQuickAccessConfig();
        $cfg['url'] = trim($_POST['qa_url'] ?? '');
        $cfg['ftp']['host'] = trim($_POST['qa_ftp_host'] ?? '');
        $cfg['ftp']['port'] = trim($_POST['qa_ftp_port'] ?? '21');
        $cfg['ftp']['user'] = trim($_POST['qa_ftp_user'] ?? '');
        $cfg['ftp']['pass'] = $_POST['qa_ftp_pass'] ?? '';
        saveQuickAccessConfig($cfg);
        $quickAccessCfg = loadQuickAccessConfig();
        $msgType = 'ok'; $msgText = '快速访问设置已保存';
    }
}

// 退出
if (isset($_GET['logout'])) { $auth->logout(); header('Location: index.php'); exit; }
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>设置 - <?= SYS_NAME ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:#f0f2f5;min-height:100vh;font-size:14px;color:#333}
.header{background:#fff;border-bottom:1px solid #e8e8e8;padding:0 20px;height:52px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:16px}
.header .user{font-size:13px;color:#666}
.header .user a{color:#1677ff;text-decoration:none;margin-left:8px}
.container{max-width:800px;margin:0 auto;padding:20px}
.card{background:#fff;border-radius:8px;padding:24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.card h3{margin-bottom:16px;font-size:15px;padding-bottom:10px;border-bottom:1px solid #f0f0f0}
.card p{color:#666;font-size:13px;margin-bottom:12px;line-height:1.6}
.stats{display:flex;gap:16px;margin-bottom:20px}
.stat-item{flex:1;background:#f9f9f9;border-radius:6px;padding:16px;text-align:center}
.stat-item .num{font-size:28px;font-weight:600;color:#1677ff}
.stat-item .label{font-size:12px;color:#999;margin-top:4px}
.btn{padding:8px 20px;border:none;border-radius:5px;font-size:14px;cursor:pointer;transition:all .15s}
.btn-p{background:#1677ff;color:#fff}.btn-p:hover{background:#4096ff}
.btn-w{background:#fa8c16;color:#fff}.btn-w:hover{background:#ffa940}
.btn-d{background:#fff;color:#333;border:1px solid #d9d9d9}.btn-d:hover{border-color:#1677ff;color:#1677ff}
.btn-sm{padding:4px 12px;font-size:12px}
.fg{margin-bottom:14px}
.fg label{display:block;font-size:13px;color:#555;margin-bottom:6px}
.fg select,.fg input[type=file],.fg input[type=text]{padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px;width:100%;max-width:500px}
.fg textarea{width:100%;max-width:600px;padding:10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px;font-family:inherit;resize:vertical}
.fg select:focus,.fg input[type=text]:focus,.fg textarea:focus{outline:none;border-color:#1677ff}
.fg .hint{font-size:11px;color:#999;margin-top:4px}
.radio-group{display:flex;gap:16px;margin:8px 0}
.radio-group label{font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px}
.export-result{background:#f9f9f9;border-radius:6px;padding:14px;margin-top:14px}
.export-result .file-link{display:block;color:#1677ff;font-size:13px;margin:4px 0;text-decoration:none}
.export-result .file-link:hover{text-decoration:underline}
.toast{position:fixed;top:20px;right:20px;padding:10px 18px;border-radius:6px;color:#fff;font-size:13px;z-index:9999;opacity:0;transition:opacity .25s;pointer-events:none}
.toast.show{opacity:1}.toast.ok{background:#52c41a}.toast.err{background:#ff4d4f}.toast.warn{background:#fa8c16}
</style>
</head>
<body>

<div class="header">
  <h1><a href="dashboard.php" style="color:inherit;text-decoration:none"><?= SYS_NAME ?></a> · 设置</h1>
  <div class="user">
    <?= htmlspecialchars($user['username']) ?>
    <a href="dashboard.php">返回管理</a>
  </div>
</div>

<div class="container">

<!-- 数据统计 -->
<div class="card">
  <h3>数据概览</h3>
  <div class="stats">
    <div class="stat-item">
      <div class="num"><?= count($images->all()) ?></div>
      <div class="label">图片总数</div>
    </div>
    <div class="stat-item">
      <div class="num"><?= count($links->all()) ?></div>
      <div class="label">链接总数</div>
    </div>
    <div class="stat-item">
      <div class="num"><?= count($folders->all()) ?></div>
      <div class="label">文件夹</div>
    </div>
  </div>
</div>

<!-- 导出 -->
<div class="card">
  <h3>导出数据</h3>
  <p>将图片、链接及文件夹数据导出为结构化 TXT 文件，同时生成目录结构文件。文件将保存到 output 目录。</p>
  <form method="post">
    <input type="hidden" name="action" value="export">
    <button type="submit" class="btn btn-p">导出数据 (TXT)</button>
  </form>
  <?php if (isset($exportFiles)): ?>
  <div class="export-result">
    <strong style="font-size:13px">导出文件：</strong>
    <?php foreach ($exportFiles as $ef): ?>
    <span class="file-link"><?= htmlspecialchars($ef) ?></span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- 系统JSON导出 -->
<div class="card">
  <h3>系统级 JSON 数据导出</h3>
  <p>将全部图片、链接、文件夹数据导出为结构化 JSON 文件，可跨系统迁移或备份。文件保存至 output 目录并自动触发浏览器下载。</p>
  <form method="post" id="jsonExportForm">
    <input type="hidden" name="action" value="export_json">
    <button type="submit" class="btn btn-p">系统级 JSON 数据导出</button>
  </form>
</div>

<!-- 导入 -->
<div class="card">
  <h3>导入数据</h3>
  <p>上传 JSON 文件导入数据。JSON 结构应包含 images、links、folders 三个可选数组。</p>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="action" value="import">
    <div class="fg">
      <label>选择 JSON 文件</label>
      <input type="file" name="import_file" accept=".json" required>
    </div>
    <div class="fg">
      <label>导入模式</label>
      <div class="radio-group">
        <label><input type="radio" name="import_mode" value="merge" checked> 合并（跳过同ID记录）</label>
        <label><input type="radio" name="import_mode" value="overwrite"> 覆盖（清空后写入）</label>
      </div>
      <div class="hint">覆盖模式将清空现有数据再导入，请谨慎使用。</div>
    </div>
    <button type="submit" class="btn btn-w">导入数据</button>
  </form>
</div>

<!-- 快速访问 -->
<div class="card">
  <h3>快速访问</h3>
  <p>配置直链 URL 和 FTP 地址，Dashboard 右上角"文件管理"弹窗将使用此配置。</p>
  <form method="post" id="qaForm">
    <input type="hidden" name="action" value="save_quick_access">

    <!-- 自定义链接 -->
    <div style="margin-bottom:16px">
      <label style="font-size:13px;color:#555;display:block;margin-bottom:6px">自定义 URL 链接（直链）</label>
      <div style="display:flex;gap:8px">
        <input type="text" name="qa_url" value="<?= htmlspecialchars($quickAccessCfg['url']) ?>" placeholder="https://example.com" style="flex:1;padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px">
        <button type="button" class="btn btn-p btn-sm" onclick="submitQaForm()" style="white-space:nowrap">保存</button>
      </div>
    </div>

    <!-- FTP 配置 -->
    <div style="border-top:1px solid #f0f0f0;padding-top:16px">
      <label style="font-size:13px;color:#555;display:block;margin-bottom:8px">FTP 连接配置</label>
      <div style="display:flex;gap:8px;margin-bottom:8px">
        <input type="text" name="qa_ftp_host" value="<?= htmlspecialchars($quickAccessCfg['ftp']['host']) ?>" placeholder="主机地址 (如 ftp.example.com)" style="flex:2;padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px">
        <input type="number" name="qa_ftp_port" value="<?= htmlspecialchars($quickAccessCfg['ftp']['port']) ?>" placeholder="端口" style="width:80px;padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px">
      </div>
      <div style="display:flex;gap:8px;margin-bottom:8px">
        <input type="text" name="qa_ftp_user" value="<?= htmlspecialchars($quickAccessCfg['ftp']['user']) ?>" placeholder="用户名" style="flex:1;padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px">
        <input type="password" name="qa_ftp_pass" value="<?= htmlspecialchars($quickAccessCfg['ftp']['pass']) ?>" placeholder="密码" style="flex:1;padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px">
      </div>
      <button type="button" class="btn btn-p btn-sm" onclick="submitQaForm()">保存</button>
    </div>
  </form>
</div>
<div class="card">
  <h3>登录页背景主题</h3>
  <form method="post" enctype="multipart/form-data" id="bgForm">
    <input type="hidden" name="action" value="save_bg_theme">
    <div class="fg">
      <label>背景样式</label>
      <div class="radio-group">
        <label><input type="radio" name="bg_style" value="purple_gradient" <?= ($themeCfg['bg_style'] ?? '') === 'purple_gradient' ? 'checked' : '' ?>> 紫渐玻璃动态风格</label>
        <label><input type="radio" name="bg_style" value="default" <?= ($themeCfg['bg_style'] ?? 'default') === 'default' ? 'checked' : '' ?>> 简约默认</label>
        <label><input type="radio" name="bg_style" value="image" <?= ($themeCfg['bg_style'] ?? '') === 'image' ? 'checked' : '' ?>> 图片背景</label>
      </div>
    </div>
    <div class="fg" id="imageModeBlock" style="display:<?= ($themeCfg['bg_style'] ?? '') === 'image' ? 'block' : 'none' ?>">
      <label>图片来源</label>
      <div class="radio-group">
        <label><input type="radio" name="image_mode" value="upload" <?= ($themeCfg['image_mode'] ?? 'upload') === 'upload' ? 'checked' : '' ?>> 本地上传</label>
        <label><input type="radio" name="image_mode" value="url" <?= ($themeCfg['image_mode'] ?? '') === 'url' ? 'checked' : '' ?>> 在线链接</label>
      </div>
    </div>
    <div class="fg" id="uploadBlock" style="display:<?= ($themeCfg['bg_style'] ?? '') === 'image' && ($themeCfg['image_mode'] ?? 'upload') === 'upload' ? 'block' : 'none' ?>">
      <label>选择背景图片</label>
      <input type="file" name="bg_image" accept="image/*">
      <?php if (!empty($themeCfg['bg_image_path']) && file_exists(BASE_PATH . '/' . $themeCfg['bg_image_path'])): ?>
      <div class="hint">当前：<?= htmlspecialchars($themeCfg['bg_image_path']) ?></div>
      <?php endif; ?>
    </div>
    <div class="fg" id="urlBlock" style="display:<?= ($themeCfg['bg_style'] ?? '') === 'image' && ($themeCfg['image_mode'] ?? '') === 'url' ? 'block' : 'none' ?>">
      <label>背景图片链接</label>
      <input type="text" name="bg_image_url" placeholder="https://example.com/bg.jpg" value="<?= htmlspecialchars($themeCfg['bg_image_url'] ?? '') ?>">
      <?php if (!empty($themeCfg['bg_image_url_path']) && file_exists(BASE_PATH . '/' . $themeCfg['bg_image_url_path'])): ?>
      <div class="hint">已保存到本地：<?= htmlspecialchars($themeCfg['bg_image_url_path']) ?></div>
      <?php elseif (!empty($themeCfg['bg_image_url'])): ?>
      <div class="hint">将直接引用在线链接</div>
      <?php endif; ?>
    </div>
    <button type="submit" class="btn btn-p">保存背景设置</button>
  </form>
</div>

<!-- 页脚编辑 -->
<div class="card">
  <h3>页脚编辑</h3>
  <form method="post">
    <input type="hidden" name="action" value="save_footer">
    <div class="fg">
      <label>显示位置</label>
      <div class="radio-group">
        <label><input type="checkbox" name="show_on[]" value="login" <?= in_array('login', $footerCfg['show_on'] ?? []) || in_array('all', $footerCfg['show_on'] ?? []) ? 'checked' : '' ?>> 登录页</label>
        <label><input type="checkbox" name="show_on[]" value="home" <?= in_array('home', $footerCfg['show_on'] ?? []) || in_array('all', $footerCfg['show_on'] ?? []) ? 'checked' : '' ?>> 首页(dashboard)</label>
        <label><input type="checkbox" name="show_on[]" value="all" <?= in_array('all', $footerCfg['show_on'] ?? []) ? 'checked' : '' ?>> 全站</label>
      </div>
    </div>
    <div class="fg">
      <label>页脚内容（支持 HTML）</label>
      <textarea name="footer_content" rows="6" placeholder="输入页脚内容，支持 HTML 标签..."><?= htmlspecialchars($footerCfg['content'] ?? '') ?></textarea>
    </div>
    <button type="submit" class="btn btn-p">保存页脚设置</button>
  </form>
</div>

</div>

<div class="toast" id="toast"></div>
<script>
function T(m,t){var e=document.getElementById('toast');e.textContent=m;e.className='toast '+t+' show';setTimeout(function(){e.classList.remove('show')},3000)}

// 快速访问
function submitQaForm(){ document.getElementById('qaForm').submit(); }

// 背景主题联动
(function(){
  var radios = document.querySelectorAll('input[name="bg_style"]');
  var modeRadios = document.querySelectorAll('input[name="image_mode"]');
  var imageBlock = document.getElementById('imageModeBlock');
  var uploadBlock = document.getElementById('uploadBlock');
  var urlBlock = document.getElementById('urlBlock');

  function updateVisibility() {
    var bgStyle = document.querySelector('input[name="bg_style"]:checked').value;
    var showImage = bgStyle === 'image';
    imageBlock.style.display = showImage ? 'block' : 'none';
    if (showImage) {
      var mode = document.querySelector('input[name="image_mode"]:checked').value;
      uploadBlock.style.display = mode === 'upload' ? 'block' : 'none';
      urlBlock.style.display = mode === 'url' ? 'block' : 'none';
    } else {
      uploadBlock.style.display = 'none';
      urlBlock.style.display = 'none';
    }
  }
  radios.forEach(function(r){ r.addEventListener('change', updateVisibility); });
  modeRadios.forEach(function(r){ r.addEventListener('change', updateVisibility); });

  // 全选联动
  var allBox = document.querySelector('input[name="show_on[]"][value="all"]');
  var otherBoxes = document.querySelectorAll('input[name="show_on[]"]:not([value="all"])');
  if (allBox) {
    allBox.addEventListener('change', function() {
      if (allBox.checked) { otherBoxes.forEach(function(b){ b.checked = true; b.disabled = true; }); }
      else { otherBoxes.forEach(function(b){ b.checked = false; b.disabled = false; }); }
    });
    // 初始化
    if (allBox.checked) { otherBoxes.forEach(function(b){ b.checked = true; b.disabled = true; }); }
  }
})();
</script>
</script>

<?php if ($msgText): ?>
<script>
T(<?= json_encode($msgText, JSON_UNESCAPED_UNICODE) ?>,<?= json_encode($msgType) ?>);
<?php if (isset($exportJsonPath)): ?>
(function(){
  var a = document.createElement('a');
  a.href = '<?= htmlspecialchars(SITE_URL . '/output/' . basename($exportJsonPath)) ?>';
  a.download = '<?= htmlspecialchars(basename($exportJsonPath)) ?>';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
})();
<?php endif; ?>
<?php if (isset($exportFiles)): ?>
(function(){
  var files = <?= json_encode(array_map(function($p) { return ['url' => SITE_URL . '/output/' . basename($p), 'name' => basename($p)]; }, $exportFiles), JSON_UNESCAPED_SLASHES) ?>;
  for(var i=0; i<files.length; i++){
    var a = document.createElement('a');
    a.href = files[i].url;
    a.download = files[i].name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }
})();
<?php endif; ?>
</script>
<?php endif; ?>
</body>
</html>

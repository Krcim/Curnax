<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/Storage.php';
require_once __DIR__ . '/includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { header('Location: index.php'); exit; }
$user = $auth->user();

// 缩略图缓存目录
define('ICO_PATH', STOCK_PATH . '/ico');
if (!is_dir(ICO_PATH)) mkdir(ICO_PATH, 0755, true);

// 页脚配置
$footerCfg = file_exists(DATA_PATH . '/footer_config.json') ? (json_decode(file_get_contents(DATA_PATH . '/footer_config.json'), true) ?: []) : [];
$showFooter = in_array('home', $footerCfg['show_on'] ?? []) || in_array('all', $footerCfg['show_on'] ?? []);

$images = new Storage(FILE_IMAGES);
$links = new Storage(FILE_LINKS);
$folders = new Storage(FILE_FOLDERS);

// 辅助函数：查找预览图
function findPreview($imageId) {
    $files = glob(TEMP_PATH . '/' . $imageId . '.*');
    if ($files && count($files) > 0) {
        return [
            'path' => $files[0],
            'url' => SITE_URL . '/Stock/temp/' . basename($files[0]),
            'ext' => pathinfo($files[0], PATHINFO_EXTENSION),
        ];
    }
    return null;
}

// 获取下载目录列表
function getDownloadDirs() {
    $baseDir = DOWNLOAD_PATH . '/down';
    if (!is_dir($baseDir)) return [];
    $dirs = [];
    $items = scandir($baseDir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $fullPath = $baseDir . '/' . $item;
        if (is_dir($fullPath)) $dirs[] = $item;
    }
    return $dirs;
}

// 处理POST
$msgType = ''; $msgText = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 新建文件夹
    if ($action === 'folder_create') {
        $fname = trim($_POST['folder_name'] ?? '');
        if ($fname && mb_strlen($fname) <= 50) {
            $folders->insert([
                'user_id' => $user['id'],
                'name' => $fname,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $msgType = 'ok'; $msgText = '文件夹已创建';
        } else {
            $msgType = 'err'; $msgText = '文件夹名称无效（1-50字符）';
        }
    }
    // 删除文件夹
    elseif ($action === 'folder_delete') {
        $fid = $_POST['folder_id'] ?? '';
        if ($fid && $folders->find($fid)) {
            $images->updateWhere(['folder_id' => $fid], ['folder_id' => null]);
            $folders->delete($fid);
            $msgType = 'ok'; $msgText = '文件夹已删除，图片已移入未分类';
        }
    }
    // 重命名文件夹
    elseif ($action === 'folder_rename') {
        $fid = $_POST['folder_id'] ?? '';
        $fname = trim($_POST['folder_name'] ?? '');
        if ($fid && $fname && mb_strlen($fname) <= 50 && $folders->find($fid)) {
            $folders->update($fid, ['name' => $fname]);
            $msgType = 'ok'; $msgText = '已重命名';
        }
    }
    // 移动图片到文件夹
    elseif ($action === 'move_to_folder') {
        $iid = $_POST['image_id'] ?? '';
        $fid = $_POST['folder_id'] ?? '';
        if ($iid && $images->find($iid)) {
            $images->update($iid, ['folder_id' => $fid ?: null]);
            $msgType = 'ok'; $msgText = '已移动';
        }
    }
    // 全部检测
    elseif ($action === 'check_all') {
        $all = $links->all(); $bad = 0;
        foreach ($all as $lk) {
            $ch = curl_init($lk['url']);
            curl_setopt_array($ch, [CURLOPT_NOBODY=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>CHECK_TIMEOUT, CURLOPT_FOLLOWLOCATION=>true]);
            curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $valid = ($code >= 200 && $code < 400);
            $links->update($lk['id'], ['status'=>$valid?'active':'invalid', 'checked_at'=>date('Y-m-d H:i:s')]);
            if (!$valid) $bad++;
        }
        $msgType = $bad ? 'warn' : 'ok';
        $msgText = "检测完成：" . count($all) . "条，{$bad}条失效";
    }
    // 检测单个
    elseif ($action === 'check_link') {
        $link = $links->find($_POST['link_id']);
        if ($link) {
            $ch = curl_init($link['url']);
            curl_setopt_array($ch, [CURLOPT_NOBODY=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>CHECK_TIMEOUT, CURLOPT_FOLLOWLOCATION=>true]);
            curl_exec($ch);
            $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            $valid = ($code >= 200 && $code < 400);
            $links->update($link['id'], ['status'=>$valid?'active':'invalid', 'checked_at'=>date('Y-m-d H:i:s')]);
            $msgType = $valid ? 'ok' : 'warn';
            $msgText = $valid ? '链接有效' : '链接已失效';
        }
    }
    // URL添加
    elseif ($action === 'url_add') {
        $url = trim($_POST['url'] ?? '');
        if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
            $parsed = parse_url($url);
            $path = $parsed['path'] ?? '';
            $filename = basename($path) ?: 'untitled';
            $name = trim($_POST['name'] ?? '') ?: pathinfo($filename, PATHINFO_FILENAME);
            $label = trim($_POST['label'] ?? '默认');
            $fid = $_POST['folder_id'] ?? null;
            $head = @get_headers($url, 1);
            $size = intval($head['Content-Length'] ?? 0);
            $type = is_array($head['Content-Type'] ?? null) ? ($head['Content-Type'][0] ?? '') : ($head['Content-Type'] ?? '');

            $img = $images->insert([
                'user_id' => $user['id'],
                'name' => $name,
                'original_name' => $filename,
                'file_size' => $size,
                'file_type' => $type ?: '',
                'dimensions' => trim($_POST['dimensions'] ?? ''),
                'folder_id' => $fid ?: null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $links->insert([
                'image_id' => $img['id'],
                'url' => $url,
                'label' => $label,
                'status' => 'active',
                'is_primary' => true,
                'checked_at' => null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $msgType = 'ok'; $msgText = '图片已添加';
        } else {
            $msgType = 'err'; $msgText = 'URL无效';
        }
    }
    // 手动创建
    elseif ($action === 'manual_add') {
        $images->insert([
            'user_id' => $user['id'],
            'name' => trim($_POST['name'] ?? ''),
            'original_name' => trim($_POST['original_name'] ?? ''),
            'file_size' => intval(($_POST['file_size'] ?? 0) * 1024),
            'file_type' => trim($_POST['file_type'] ?? ''),
            'dimensions' => trim($_POST['dimensions'] ?? ''),
            'folder_id' => $_POST['folder_id'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        $msgType = 'ok'; $msgText = '记录已创建';
    }
    // 添加链接
    elseif ($action === 'add_link') {
        $links->insert([
            'image_id' => $_POST['image_id'],
            'url' => trim($_POST['url']),
            'label' => trim($_POST['label'] ?: '备用'),
            'status' => 'backup',
            'is_primary' => false,
            'checked_at' => null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        $msgType = 'ok'; $msgText = '链接已添加';
    }
    // 删除图片
    elseif ($action === 'delete_image') {
        $links->deleteWhere(['image_id' => $_POST['image_id']]);
        $images->delete($_POST['image_id']);
        @unlink(ICO_PATH . '/' . $_POST['image_id'] . '.jpg');
        $msgType = 'ok'; $msgText = '已删除';
    }
    // 清理过期缓存
    elseif ($action === 'clean_cache') {
        cleanCache();
        $msgType = 'ok'; $msgText = '过期缓存已清理';
    }
    // 清理下载目录过期文件（48小时）
    elseif ($action === 'clean_old_downloads') {
        $downDir = DOWNLOAD_PATH . '/down';
        $count = 0;
        if (is_dir($downDir)) {
            $now = time();
            $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($downDir, RecursiveDirectoryIterator::SKIP_DOTS));
            foreach ($rii as $f) {
                if ($now - $f->getMTime() > 172800) {
                    if ($f->isFile()) { unlink($f->getPathname()); $count++; }
                }
            }
        }
        $msgType = 'ok'; $msgText = "已清理 {$count} 个过期文件";
    }
    // 设置链接为主链接
    elseif ($action === 'set_primary') {
        $linkId = $_POST['link_id'];
        $link = $links->find($linkId);
        if ($link) {
            $links->updateWhere(['image_id' => $link['image_id']], ['is_primary' => false]);
            $links->update($linkId, ['is_primary' => true]);
            $msgType = 'ok'; $msgText = '已设为主链接';
        }
    }
    // 删除链接（不可删除主链接）
    elseif ($action === 'delete_link') {
        $linkId = $_POST['link_id'];
        $link = $links->find($linkId);
        if ($link && !$link['is_primary']) {
            $links->delete($linkId);
            $msgType = 'ok'; $msgText = '链接已删除';
        } else {
            $msgType = 'err'; $msgText = '无法删除主链接';
        }
    }
    // 编辑链接
    elseif ($action === 'edit_link') {
        $linkId = $_POST['link_id'];
        $link = $links->find($linkId);
        if ($link) {
            $newUrl = trim($_POST['url'] ?? '');
            $newLabel = trim($_POST['label'] ?? '');
            if ($newUrl && filter_var($newUrl, FILTER_VALIDATE_URL)) {
                $links->update($linkId, [
                    'url' => $newUrl,
                    'label' => $newLabel ?: '备用',
                ]);
                $msgType = 'ok'; $msgText = '链接已更新';
            } else {
                $msgType = 'err'; $msgText = 'URL无效';
            }
        } else {
            $msgType = 'err'; $msgText = '链接不存在';
        }
    }
    // 编辑图片属性
    elseif ($action === 'edit_image') {
        $iid = $_POST['image_id'] ?? '';
        $img = $images->find($iid);
        if ($img) {
            $fileSizeKB = floatval($_POST['file_size'] ?? 0);
            $fileSizeBytes = intval($fileSizeKB * 1024);
            $images->update($iid, [
                'name' => trim($_POST['name'] ?? ''),
                'original_name' => trim($_POST['original_name'] ?? ''),
                'file_size' => $fileSizeBytes,
                'file_type' => trim($_POST['file_type'] ?? ''),
                'dimensions' => trim($_POST['dimensions'] ?? ''),
            ]);
            $msgType = 'ok'; $msgText = '图片信息已更新';
        } else {
            $msgType = 'err'; $msgText = '图片不存在';
        }
    }
    // 批量删除
    elseif ($action === 'batch_delete') {
        $ids = json_decode($_POST['ids'] ?? '[]', true);
        $count = 0;
        foreach ($ids as $id) {
            if ($images->find($id)) {
                $links->deleteWhere(['image_id' => $id]);
                $images->delete($id);
                @unlink(ICO_PATH . '/' . $id . '.jpg');
                $count++;
            }
        }
        $msgType = 'ok'; $msgText = "已删除 {$count} 张图片";
    }
    // 批量移动
    elseif ($action === 'batch_move') {
        $ids = json_decode($_POST['ids'] ?? '[]', true);
        $fid = $_POST['folder_id'] ?? '';
        $count = 0;
        foreach ($ids as $id) {
            if ($images->find($id)) {
                $images->update($id, ['folder_id' => $fid ?: null]);
                $count++;
            }
        }
        $msgType = 'ok'; $msgText = "已移动 {$count} 张图片";
    }
    // 获取缩略图
    elseif ($action === 'fetch_thumbs') {
        $ids = json_decode($_POST['ids'] ?? '[]', true);
        $ok = 0; $fail = 0;
        foreach ($ids as $id) {
            $img = $images->find($id);
            if (!$img) continue;
            $imgLinks = $links->where(['image_id' => $id]);
            $bestUrl = '';
            foreach ($imgLinks as $l) { if ($l['status'] === 'active') { $bestUrl = $l['url']; break; } }
            if (!$bestUrl && !empty($imgLinks)) $bestUrl = $imgLinks[0]['url'];
            if (!$bestUrl) { $fail++; continue; }
            $dest = ICO_PATH . '/' . $id . '.jpg';
            $data = @file_get_contents($bestUrl);
            if ($data) { file_put_contents($dest, $data); $ok++; } else { $fail++; }
        }
        $msgType = 'ok'; $msgText = "缩略图获取完成：{$ok} 成功 / {$fail} 失败";
    }
    // 刷新全部缩略图
    elseif ($action === 'refresh_thumbs') {
        array_map('unlink', glob(ICO_PATH . '/*'));
        $all = $images->all();
        $ok = 0; $fail = 0;
        foreach ($all as $img) {
            $imgLinks = $links->where(['image_id' => $img['id']]);
            $bestUrl = '';
            foreach ($imgLinks as $l) { if ($l['status'] === 'active') { $bestUrl = $l['url']; break; } }
            if (!$bestUrl && !empty($imgLinks)) $bestUrl = $imgLinks[0]['url'];
            if (!$bestUrl) { $fail++; continue; }
            $dest = ICO_PATH . '/' . $img['id'] . '.jpg';
            $data = @file_get_contents($bestUrl);
            if ($data) { file_put_contents($dest, $data); $ok++; } else { $fail++; }
        }
        $msgType = 'ok'; $msgText = "全部缩略图刷新完成：{$ok} 成功 / {$fail} 失败";
    }
    // 批量添加 CDN 链接
    elseif ($action === 'batch_add') {
        $itemsJson = $_POST['items'] ?? '[]';
        $items = json_decode($itemsJson, true);

        if (!is_array($items) || empty($items)) {
            echo json_encode(['success' => false, 'message' => '数据为空'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $allImages = file_exists(FILE_CDN_IMAGES) ? (json_decode(file_get_contents(FILE_CDN_IMAGES), true) ?: []) : [];
        $allLinks = file_exists(FILE_CDN_LINKS) ? (json_decode(file_get_contents(FILE_CDN_LINKS), true) ?: []) : [];

        $successCount = 0;

        foreach ($items as $item) {
            $name = trim($item['name'] ?? '');
            $primaryUrl = trim($item['primary_url'] ?? '');
            $backupUrl = trim($item['backup_url'] ?? '');

            if (empty($name) || empty($primaryUrl)) continue;

            $newId = 'cdn_' . uniqid('', true);

            $slug = sanitizeFileNameBatch($name);
            if (strlen($slug) < 1) $slug = substr(md5($newId . time()), 0, 10);

            $baseSlug = $slug;
            $counter = 1;
            $exists = true;
            while ($exists) {
                $exists = false;
                foreach ($allImages as $img) {
                    if (($img['unified_slug'] ?? '') === $slug) {
                        $exists = true;
                        $slug = $baseSlug . $counter;
                        $counter++;
                        break;
                    }
                }
            }

            $allImages[] = [
                'id' => $newId,
                'name' => $name,
                'original_name' => $name,
                'file_size' => 0,
                'file_type' => 'url',
                'folder_id' => '',
                'unified_slug' => $slug,
                'created_at' => date('Y-m-d H:i:s')
            ];

            $allLinks[] = [
                'id' => 'lnk_' . uniqid('', true),
                'image_id' => $newId,
                'url' => $primaryUrl,
                'label' => '主链接',
                'is_primary' => true,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s')
            ];

            if (!empty($backupUrl)) {
                $allLinks[] = [
                    'id' => 'lnk_' . uniqid('', true),
                    'image_id' => $newId,
                    'url' => $backupUrl,
                    'label' => '备用链接',
                    'is_primary' => false,
                    'status' => 'pending',
                    'created_at' => date('Y-m-d H:i:s')
                ];
            }

            $successCount++;
        }

        file_put_contents(FILE_CDN_IMAGES, json_encode($allImages, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
        file_put_contents(FILE_CDN_LINKS, json_encode($allLinks, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);

        echo json_encode([
            'success' => true,
            'count' => $successCount
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // 保存快速导航链接
    elseif ($action === 'save_quick_links') {
        $linksJson = $_POST['links'] ?? '[]';
        $links = json_decode($linksJson, true);
        if (!is_array($links)) { $links = []; }
        $links = array_slice($links, 0, 5);
        $links = array_values(array_filter($links, function($l) {
            return !empty(trim($l['name'] ?? '')) && !empty(trim($l['url'] ?? ''));
        }));
        $file = DATA_PATH . '/quick_links.json';
        file_put_contents($file, json_encode($links, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
        echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
        exit;
    }
    // 保存视频链接
    elseif ($action === 'save_video_links') {
        $linksJson = $_POST['links'] ?? '[]';
        $links = json_decode($linksJson, true);
        if (!is_array($links)) { $links = []; }
        $links = array_values(array_filter($links, function($l) {
            return !empty(trim($l['name'] ?? '')) && !empty(trim($l['url'] ?? ''));
        }));
        // [可选] 在 config.php 定义 define('FILE_VIDEO_LINKS', DATA_PATH . '/video_links.json'); 后替换为 FILE_VIDEO_LINKS
        $file = DATA_PATH . '/video_links.json';
        file_put_contents($file, json_encode($links, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
        echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

function sanitizeFileNameBatch($name) {
    $name = preg_replace('/\.[^.]+$/', '', $name);
    $name = preg_replace('/[^a-zA-Z0-9_-]/', '', $name);
    $name = strtolower($name);
    return $name;
}

function cacheStats() {
    $size = 0; $count = 0;
    if (is_dir(TEMP_PATH)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(TEMP_PATH, RecursiveDirectoryIterator::SKIP_DOTS));
        foreach ($rii as $f) { $size += $f->getSize(); $count++; }
    }
    return ['size'=>$size, 'count'=>$count];
}
function cleanCache() {
    if (!is_dir(TEMP_PATH)) return;
    $now = time();
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(TEMP_PATH, RecursiveDirectoryIterator::SKIP_DOTS));
    foreach ($rii as $f) {
        if ($now - $f->getMTime() > CACHE_TTL) unlink($f->getPathname());
    }
}

function downStats() {
    $size = 0; $count = 0;
    $downDir = DOWNLOAD_PATH . '/down';
    if (is_dir($downDir)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($downDir, RecursiveDirectoryIterator::SKIP_DOTS));
        foreach ($rii as $f) { $size += $f->getSize(); $count++; }
    }
    return ['size' => $size, 'count' => $count];
}

$cache = cacheStats();
$down = downStats();
$allFolders = $folders->all();
$currentFolder = $_GET['folder'] ?? 'all';

// 分页 + 筛选
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = intval($_GET['per_page'] ?? 20);
if (!in_array($perPage, [20, 50, 100, 200])) {
    $perPage = 20;
}
$allImages = array_reverse($images->all());
if ($currentFolder !== 'all') {
    $allImages = array_filter($allImages, function($img) use ($currentFolder) {
        return ($img['folder_id'] ?? null) === $currentFolder;
    });
}
$allImages = array_values($allImages);
$totalPages = ceil(count($allImages) / $perPage);
$pageImages = array_slice($allImages, ($page-1)*$perPage, $perPage);

// 构建图片-链接映射数据（供前端详情弹窗使用）
$imageDataMap = [];
foreach ($allImages as $img) {
    $imgLinks = $links->where(['image_id' => $img['id']]);
    $preview = findPreview($img['id']);
    $folderName = '';
    if (!empty($img['folder_id'])) {
        $f = $folders->find($img['folder_id']);
        $folderName = $f ? $f['name'] : '';
    }
    $imageDataMap[$img['id']] = [
        'id' => $img['id'],
        'name' => $img['name'],
        'original_name' => $img['original_name'],
        'file_size' => $img['file_size'],
        'file_type' => $img['file_type'],
        'dimensions' => $img['dimensions'],
        'folder_id' => $img['folder_id'] ?? null,
        'folder_name' => $folderName,
        'preview' => $preview,
        'links' => $imgLinks,
    ];
}

// 下载目录列表
$downloadDirs = getDownloadDirs();

// 快速导航链接
$qlFile = DATA_PATH . '/quick_links.json';
$quickLinks = file_exists($qlFile) ? json_decode(file_get_contents($qlFile), true) : [];
$quickLinks = is_array($quickLinks) ? array_slice($quickLinks, 0, 5) : [];

// 退出
if (isset($_GET['logout'])) { $auth->logout(); header('Location: index.php'); exit; }
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= SYS_NAME ?></title>
<!-- BETA: Pico CSS 美化 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@picocss/pico@2/css/pico.classless.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:#f0f2f5;min-height:100vh;font-size:14px;color:#333}
.header{background:#fff;border-bottom:1px solid #e8e8e8;padding:0 20px;height:52px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.header h1{font-size:16px}
.header .user{font-size:13px;color:#666}
.header .user a{color:#ff4d4f;text-decoration:none;margin-left:10px}
.header .user a.nav-btn{display:inline-block;padding:3px 12px;background:#52c41a;color:#fff;border-radius:20px;text-decoration:none;margin-left:8px;font-size:12px;transition:background .2s}.header .user a.nav-btn:hover{background:#73d13d}.header .user a.about-btn{background:#52c41a;border-radius:20px}
.layout{display:flex;min-height:calc(100vh - 52px)}
/* 侧边栏 */
.sidebar{width:220px;background:#fff;border-right:1px solid #e8e8e8;padding:12px 0;flex-shrink:0;overflow-y:auto}
.sidebar .section{padding:0 14px;margin-bottom:8px}
.sidebar .section-title{font-size:12px;color:#999;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;padding:0 2px}
.sidebar .folder-item{display:flex;align-items:center;padding:7px 14px;font-size:13px;cursor:pointer;transition:background .15s;text-decoration:none;color:#333;gap:8px}
.sidebar .folder-item:hover{background:#f5f5f5}
.sidebar .folder-item.active{background:#e6f7ff;color:#1677ff;font-weight:500;border-right:3px solid #1677ff}
.sidebar .folder-item .icon{font-size:16px;width:20px;text-align:center;flex-shrink:0}
.sidebar .folder-item .count{font-size:11px;color:#999;margin-left:auto}
.sidebar .folder-item.active .count{color:#1677ff}
.sidebar .folder-actions{display:none;gap:2px;margin-left:auto}
.sidebar .folder-item:hover .count{display:none}
.sidebar .folder-item:hover .folder-actions{display:flex}
.sidebar .folder-actions button{background:none;border:none;cursor:pointer;font-size:12px;padding:2px 5px;border-radius:3px;color:#999}
.sidebar .folder-actions button:hover{background:#f0f0f0;color:#333}
.sidebar .folder-actions .del-btn:hover{color:#ff4d4f;background:#fff2f0}
.sidebar .new-folder{padding:8px 14px;display:flex;gap:6px}
.sidebar .new-folder input{flex:1;padding:6px 8px;border:1px solid #d9d9d9;border-radius:4px;font-size:12px;min-width:0}
.sidebar .new-folder input:focus{outline:none;border-color:#1677ff}
.sidebar .new-folder button{padding:6px 10px;background:#1677ff;color:#fff;border:none;border-radius:4px;font-size:12px;cursor:pointer;white-space:nowrap}
.sidebar .new-folder button:hover{background:#4096ff}
/* 主区域 */
.main{flex:1;padding:16px;overflow-y:auto;min-width:0}
.container{max-width:1400px}
.cache-bar{background:#fff;border-radius:6px;padding:10px 16px;margin-bottom:12px;display:flex;align-items:center;gap:14px;font-size:13px;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.cache-bar .meter{flex:1;height:8px;background:#f0f0f0;border-radius:4px;overflow:hidden}
.cache-bar .meter div{height:100%;background:#1677ff;border-radius:4px;transition:width .3s}
.toolbar{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;align-items:center}
.toolbar .search-input{padding:6px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px;width:200px}
.toolbar .search-input:focus{outline:none;border-color:#1677ff}
.btn{padding:6px 14px;border:none;border-radius:5px;font-size:13px;cursor:pointer;transition:all .15s;white-space:nowrap}
.btn-p{background:#1677ff;color:#fff}.btn-p:hover{background:#4096ff}
.btn-d{background:#fff;color:#333;border:1px solid #d9d9d9}.btn-d:hover{border-color:#1677ff;color:#1677ff}
.btn-r{background:#ff4d4f;color:#fff}.btn-r:hover{background:#ff7875}
.btn-w{background:#fa8c16;color:#fff}.btn-w:hover{background:#ffa940}
.btn-g{background:#52c41a;color:#fff}.btn-g:hover{background:#73d13d}
.btn-xs{padding:2px 8px;font-size:12px}
.btn:disabled{opacity:.6;cursor:not-allowed}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:6px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.04)}
th{background:#fafafa;padding:10px 14px;text-align:left;font-size:13px;color:#666;font-weight:500;border-bottom:1px solid #f0f0f0;white-space:nowrap}
td{padding:8px 14px;border-bottom:1px solid #f5f5f5;font-size:13px;vertical-align:top}
tr:hover td{background:#fafafa}
.link-row{display:flex;align-items:center;gap:5px;margin:3px 0;flex-wrap:wrap}
.url-txt{font-size:12px;color:#1677ff;word-break:break-all;flex:1;min-width:0;cursor:pointer}
.url-txt:hover{text-decoration:underline}
.tag{padding:1px 6px;border-radius:3px;font-size:11px;white-space:nowrap}
.tag-ok{background:#f6ffed;color:#52c41a}.tag-fail{background:#fff2f0;color:#ff4d4f}.tag-bk{background:#fff7e6;color:#fa8c16}
.tag-p{background:#e6f7ff;color:#1677ff}
.pagination{text-align:center;margin-top:12px;display:flex;gap:6px;justify-content:center}
.pagination a,.pagination span{padding:5px 10px;border-radius:4px;border:1px solid #d9d9d9;font-size:13px;text-decoration:none;color:#333}
.pagination a:hover{border-color:#1677ff;color:#1677ff}
.pagination .active{background:#1677ff;color:#fff;border-color:#1677ff}
.pagination .disabled{color:#bbb;border-color:#e8e8e8;cursor:default}
/* 缩略图 */
.thumb-toolbar{display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:6px 10px;background:#fafafa;border-radius:6px;border:1px solid #f0f0f0}
.thumb-info{font-size:12px;color:#999}
.tb-thumb{width:36px;height:36px;border-radius:4px;overflow:hidden;background:#f5f5f5;display:flex;align-items:center;justify-content:center;border:1px solid #e8e8e8}
.tb-thumb img{width:100%;height:100%;object-fit:cover}
.tb-thumb:not(.loaded)::after{content:'';width:16px;height:16px;border:2px solid #d9d9d9;border-radius:3px}
/* 弹窗 */
.modal-o{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.4);z-index:999;align-items:center;justify-content:center}
.modal-o.show{display:flex}
.modal{background:#fff;border-radius:10px;padding:28px;width:480px;max-width:90%;max-height:85vh;overflow-y:auto}
.modal.wide{width:900px}
.modal h3{margin-bottom:16px;font-size:16px}
.fg{margin-bottom:12px}
.fg label{display:block;font-size:13px;color:#555;margin-bottom:4px}
.fg input,.fg select{width:100%;padding:7px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px}
.fg input:focus,.fg select:focus{outline:none;border-color:#1677ff}
.fg .hint{font-size:11px;color:#999;margin-top:2px}
.fg-row{display:flex;gap:10px}.fg-row .fg{flex:1}
.modal-btns{display:flex;gap:8px;margin-top:18px;justify-content:flex-end}
/* 详情弹窗 */
.detail-layout{display:flex;gap:20px;min-height:400px}
.detail-preview{width:300px;flex-shrink:0;background:#fafafa;border-radius:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;min-height:200px}
.detail-preview img{max-width:100%;max-height:300px;object-fit:contain}
.detail-preview .no-preview{color:#bbb;font-size:13px;text-align:center;padding:40px}
.detail-preview .dl-btn-area{margin-top:10px;padding-bottom:10px}
.detail-info{flex:1;min-width:0;overflow-y:auto;max-height:60vh}
.detail-info table{box-shadow:none;margin-bottom:16px}
.detail-info table td{padding:5px 8px;font-size:12px}
.detail-info .attr-label{color:#999;width:80px;white-space:nowrap}
.detail-links{margin-bottom:16px}
.detail-links .link-item{display:flex;align-items:center;gap:6px;margin:4px 0;font-size:12px}
.detail-links .link-item .lk-url{color:#1677ff;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* 格式标签 */
.format-tabs{display:flex;gap:0;border-bottom:2px solid #f0f0f0;margin-bottom:10px}
.format-tabs .tab-btn{padding:8px 16px;border:none;background:none;font-size:13px;cursor:pointer;color:#666;border-bottom:2px solid transparent;margin-bottom:-2px;transition:all .15s}
.format-tabs .tab-btn:hover{color:#1677ff}
.format-tabs .tab-btn.active{color:#1677ff;border-bottom-color:#1677ff;font-weight:500}
.format-content{position:relative}
.format-content textarea,.format-content pre{width:100%;min-height:60px;padding:10px;background:#f9f9f9;border:1px solid #e8e8e8;border-radius:6px;font-size:12px;font-family:'Consolas','Courier New',monospace;resize:vertical;white-space:pre-wrap;word-break:break-all}
.format-content .copy-btn{position:absolute;top:6px;right:6px;padding:3px 10px;background:#fff;border:1px solid #d9d9d9;border-radius:4px;font-size:11px;cursor:pointer}
.format-content .copy-btn:hover{background:#1677ff;color:#fff;border-color:#1677ff}
.empty{text-align:center;padding:48px;color:#bbb;font-size:14px}
.toast{position:fixed;top:20px;right:20px;padding:10px 18px;border-radius:6px;color:#fff;font-size:13px;z-index:9999;opacity:0;transition:opacity .25s;pointer-events:none}
.toast.show{opacity:1}.toast.ok{background:#52c41a}.toast.err{background:#ff4d4f}.toast.warn{background:#fa8c16}
.rename-input{font-size:12px;padding:2px 6px;border:1px solid #d9d9d9;border-radius:3px;width:100px}
/* 批量操作列表 */
.batch-list{max-height:400px;overflow-y:auto;border:1px solid #f0f0f0;border-radius:6px;margin-bottom:12px}
.batch-item{display:flex;align-items:center;padding:8px 12px;border-bottom:1px solid #f5f5f5;gap:10px;font-size:13px}
.batch-item:hover{background:#fafafa}
.batch-item:last-child{border-bottom:none}
.batch-item input[type=checkbox]{flex-shrink:0}
.batch-item .bi-name{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.batch-item .bi-links{display:flex;gap:8px}
.batch-item .bi-links label{font-size:12px;cursor:pointer;display:flex;align-items:center;gap:3px}
.batch-item .bi-links input[type=radio]{margin:0}
.batch-header{display:flex;align-items:center;padding:8px 12px;background:#fafafa;border-bottom:1px solid #f0f0f0;font-size:12px;color:#666;gap:10px}
.batch-header input[type=checkbox]{flex-shrink:0}
/* 下载进度 */
.dl-progress{display:none;margin-top:12px}
.dl-progress .bar{height:8px;background:#f0f0f0;border-radius:4px;overflow:hidden;margin-bottom:4px}
.dl-progress .bar div{height:100%;background:#52c41a;border-radius:4px;transition:width .3s}
.dl-progress .txt{font-size:12px;color:#666;text-align:center}
/* 快速访问弹窗 */
.qa-modal .modal{max-width:600px}
.qa-header{display:flex;align-items:center;justify-content:space-between;padding:0;border-bottom:1px solid #f0f0f0;margin-bottom:0}
.qa-tabs{display:flex;gap:0}
.qa-tab{padding:12px 24px;font-size:14px;font-weight:500;color:#999;cursor:pointer;border-bottom:2px solid transparent;transition:all .2s;user-select:none}
.qa-tab:hover{color:#555}
.qa-tab.active{color:#1677ff;border-bottom-color:#1677ff}
.qa-top-btn{display:flex;align-items:center;gap:4px;padding:8px 14px;font-size:13px;color:#1677ff;background:#e6f4ff;border:none;border-radius:5px;cursor:pointer;margin-right:16px;transition:all .2s}
.qa-top-btn:hover{background:#bae0ff}
.qa-body{padding:24px}
.qa-body .fg{margin-bottom:14px}
.qa-body .fg label{display:block;font-size:13px;color:#555;margin-bottom:5px}
.qa-body .fg input[type=text],.qa-body .fg input[type=password],.qa-body .fg input[type=number]{width:100%;padding:9px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px;box-sizing:border-box}
.qa-body .fg-row{display:flex;gap:8px}
.qa-body .fg-row .fg{flex:1}
.qa-panel{display:none}
.qa-panel.active{display:block}
.qa-body .btn-row{display:flex;gap:8px;margin-top:4px}
.site-footer{position:fixed;bottom:0;left:0;right:0;text-align:center;padding:10px 20px;font-size:12px;color:#999;z-index:1;background:rgba(255,255,255,.8)}
.site-footer a{color:inherit;text-decoration:underline}
/* 关于弹窗 */
.about-modal .modal{max-width:560px}
.about-body{padding:28px 32px}
.about-body h2{font-size:20px;color:#333;margin-bottom:6px}
.about-body .ver{font-size:13px;color:#999;margin-bottom:20px}
.about-body .desc{font-size:14px;color:#555;line-height:1.8;margin-bottom:20px}
.about-body .feature-list{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:20px}
.about-body .feature-item{display:flex;align-items:center;gap:8px;padding:8px 12px;background:#f6ffed;border-radius:6px;font-size:13px;color:#333}
.about-body .feature-item .fi-icon{font-size:16px;flex-shrink:0}
.about-body .footer-note{margin-top:20px;padding-top:16px;border-top:1px solid #f0f0f0;font-size:13px;color:#999;line-height:1.6}
.about-body .footer-note strong{color:#722ed1}
.quick-link-item:hover .ql-del{visibility:visible !important}
.video-link-item:hover .vl-del{visibility:visible !important}
/* Pico CSS 冲突修复 */
body { max-width: none; padding: 0; }
button, .btn { border-radius: 4px; font-size: 13px; }
.btn-xs { padding: 2px 8px; font-size: 12px; --pico-font-size: 12px; }
input, textarea { --pico-font-size: 13px; }
a { text-decoration: none; }
h1, h2, h3, h4 { margin: 0; --pico-typography-spacing-vertical: 0.5em; }
table { margin: 0; }
td, th { padding: 8px 10px; }
nav, aside { margin: 0; padding: 0; }
.sidebar { background: #fafafa; border-right: 1px solid #e8e8e8; }
.modal-o { z-index: 1000; }
.modal { background: #fff; }
/* 保持按钮颜色体系 */
.btn-p { background: #1677ff; color: #fff; border: 1px solid #1677ff; }
.btn-d { background: #fff; color: #666; border: 1px solid #d9d9d9; }
.btn-r { background: #ff4d4f; color: #fff; border: 1px solid #ff4d4f; }
.btn-p:hover { background: #4096ff; border-color: #4096ff; }
.btn-d:hover { color: #1677ff; border-color: #1677ff; }
.btn-r:hover { background: #ff7875; border-color: #ff7875; }
</style>
</head>
<body>

<div class="header">
  <h1><a href="dashboard.php" style="color:inherit;text-decoration:none"><?= SYS_NAME ?></a></h1>
  <div class="user">
    <?= htmlspecialchars($user['username']) ?>
    <a class="nav-btn" href="user.php">用户管理</a>
    <a class="nav-btn" href="settings.php">设置</a>
    <a class="nav-btn" href="#" onclick="showQuickAccess();return false">文件管理</a>
    <a class="nav-btn about-btn" href="#" onclick="showAbout();return false">关于</a>
    <a href="?logout=1">退出</a>
  </div>
</div>

<div class="layout">
<!-- 左侧边栏 -->
<div class="sidebar">
  <div class="section" style="margin-bottom:4px">
    <div class="section-title" style="color:#ff4d4f">内测 <span style="display:inline-block;width:6px;height:6px;background:#ff4d4f;border-radius:50%;margin-left:4px;vertical-align:middle;animation:pulse 2s infinite"></span></div>
    <a href="cdn.php" class="folder-item" style="color:#ff4d4f;font-weight:500">
      <span class="icon">&#127760;</span>CDN 分发管理
    </a>
  </div>
  <style>@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}</style>
  <div class="section">
    <div class="section-title">文件夹</div>
    <a href="?folder=all" class="folder-item <?= $currentFolder==='all'?'active':'' ?>">
      <span class="icon">&#128193;</span>全部
      <span class="count"><?= count($images->all()) ?></span>
    </a>
    <?php foreach ($allFolders as $f): ?>
    <?php $fcount = count(array_filter($images->all(), fn($i) => ($i['folder_id']??null)===$f['id'])); ?>
    <a href="?folder=<?= htmlspecialchars($f['id']) ?>" class="folder-item <?= $currentFolder===$f['id']?'active':'' ?>">
      <span class="icon">&#128194;</span><?= htmlspecialchars($f['name']) ?>
      <span class="count"><?= $fcount ?></span>
      <span class="folder-actions">
        <button title="重命名" onclick="event.preventDefault();event.stopPropagation();startRename('<?= htmlspecialchars($f['id']) ?>','<?= htmlspecialchars(addslashes($f['name'])) ?>')">&#9998;</button>
        <button class="del-btn" title="删除" onclick="event.preventDefault();event.stopPropagation();if(confirm('删除文件夹「<?= htmlspecialchars(addslashes($f['name'])) ?>」？\n图片将移入未分类。'))submitForm('folder_delete','folder_id','<?= htmlspecialchars($f['id']) ?>')">&#10005;</button>
      </span>
    </a>
    <?php endforeach; ?>
  </div>
  <!-- 视频URL管理 -->
  <div class="quick-nav" style="margin-bottom:12px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
      <span style="font-size:12px;color:#999;font-weight:500">视频URL管理</span>
      <button onclick="openVideoLinkModal()" title="添加视频链接" style="width:22px;height:22px;border:1px dashed #1677ff;border-radius:50%;background:none;color:#1677ff;font-size:14px;line-height:20px;cursor:pointer;text-align:center;padding:0">+</button>
    </div>
    <div id="videoLinkList">
      <?php
      // [可选] 在 config.php 定义 define('FILE_VIDEO_LINKS', DATA_PATH . '/video_links.json'); 后替换为 FILE_VIDEO_LINKS
      $vlFile = DATA_PATH . '/video_links.json';
      $videoLinks = file_exists($vlFile) ? json_decode(file_get_contents($vlFile), true) : [];
      $videoLinks = is_array($videoLinks) ? $videoLinks : [];
      foreach ($videoLinks as $vl):
      ?>
      <a href="<?= htmlspecialchars($vl['url']) ?>" target="_blank" class="video-link-item"
         style="display:flex;align-items:center;padding:6px 8px;margin:2px 0;border-radius:4px;color:#333;text-decoration:none;font-size:13px;transition:background 0.2s"
         onmouseover="this.style.background='#f0f5ff'" onmouseout="this.style.background='none'">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="#1677ff" style="margin-right:6px;flex-shrink:0"><circle cx="12" cy="12" r="10" fill="none" stroke="#1677ff" stroke-width="2"/><polygon points="9,17 17,12 9,7" fill="#1677ff"/></svg>
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($vl['name']) ?></span>
        <span onclick="deleteVideoLink(event, '<?= htmlspecialchars($vl['name']) ?>')" style="color:#ccc;font-size:14px;margin-left:4px;cursor:pointer;visibility:hidden" class="vl-del">&times;</span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <!-- 快速导航 -->
  <div class="quick-nav" style="margin-bottom:12px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
      <span style="font-size:12px;color:#999;font-weight:500">快速导航</span>
      <button onclick="openQuickLinkModal()" title="添加快捷链接" style="width:22px;height:22px;border:1px dashed #1677ff;border-radius:50%;background:none;color:#1677ff;font-size:14px;line-height:20px;cursor:pointer;text-align:center;padding:0">+</button>
    </div>
    <div id="quickLinkList">
      <?php foreach ($quickLinks as $ql): ?>
      <a href="<?= htmlspecialchars($ql['url']) ?>" target="_blank" class="quick-link-item" style="display:flex;align-items:center;padding:6px 8px;margin:2px 0;border-radius:4px;color:#333;text-decoration:none;font-size:13px;transition:background 0.2s"
         onmouseover="this.style.background='#f0f5ff'" onmouseout="this.style.background='none'">
        <span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= htmlspecialchars($ql['name']) ?></span>
        <span onclick="deleteQuickLink(event, '<?= htmlspecialchars($ql['name']) ?>')" style="color:#ccc;font-size:14px;margin-left:4px;cursor:pointer;visibility:hidden" class="ql-del">&times;</span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <form method="post" class="new-folder" onsubmit="return this.folder_name.value.trim()!==''">
    <input type="hidden" name="action" value="folder_create">
    <input type="text" name="folder_name" placeholder="新文件夹名称..." required maxlength="50">
    <button type="submit">+ 新建</button>
  </form>
</div>

<!-- 主区域 -->
<div class="main">
<div class="container">

<div class="cache-bar">
  <span>缓存目录: Stock/temp</span>
  <div class="meter"><div style="width:<?= min(100, $cache['size']/CACHE_MAX_SIZE*100) ?>%"></div></div>
  <span><?= round($cache['size']/1048576,1) ?>MB / 5120MB · <?= $cache['count'] ?>个文件</span>
  <button class="btn btn-w btn-xs" onclick="submitForm('clean_cache')">清理过期</button>
</div>

<div class="cache-bar" style="background:#f6ffed;border:1px solid #b7eb8f">
  <span>下载目录: Stock/down</span>
  <div class="meter"><div style="width:<?= min(100, $down['size']/10737418240*100); background:#52c41a ?>%"></div></div>
  <span><?= round($down['size']/1048576,1) ?>MB / 10240MB · <?= $down['count'] ?>个文件</span>
  <button class="btn btn-r btn-xs" onclick="submitForm('clean_old_downloads')">清理过期48h</button>
</div>

<div class="thumb-toolbar">
  <span style="font-size:12px;color:#888;margin-right:8px">缩略图</span>
  <button class="btn btn-p btn-xs" onclick="fetchThumbs()">获取缩略图</button>
  <button class="btn btn-d btn-xs" onclick="refreshThumbs()">缓存刷新</button>
  <span class="thumb-info" id="thumbInfo"></span>
</div>

<div class="toolbar">
  <input type="text" class="search-input" id="searchInput" placeholder="搜索图片名称/原始名..." oninput="filterTable()">
  <button class="btn btn-d btn-xs" onclick="filterTable()">搜索</button>
  <button class="btn btn-p" onclick="showModal('urlModal')">URL 添加</button>
  <button class="btn btn-d" onclick="showModal('manualModal')">手动创建</button>
  <button class="btn btn-p btn-xs" onclick="openBatchModal()" style="margin-left:8px">批量添加</button>
  <button class="btn btn-d" onclick="showBatchCopy()">批量复制链接</button>
  <button class="btn btn-d" onclick="showBatchDownload()">批量下载</button>
  <button class="btn btn-r btn-xs" onclick="batchDelete()" style="display:none" id="batchDeleteBtn">批量删除</button>
  <button class="btn btn-d btn-xs" onclick="showBatchMove()" style="display:none" id="batchMoveBtn">移动到文件夹</button>
  <button class="btn btn-p btn-xs" onclick="batchDownloadLocal()" style="display:none" id="batchDLLocalBtn">批量下载至本地</button>
  <button class="btn btn-w" style="margin-left:auto" onclick="submitForm('check_all')">检测全部链接</button>
</div>

<table id="imageTable">
<thead><tr>
  <th style="width:30px"><input type="checkbox" id="selectAll" onclick="toggleAllRows(this)"></th>
  <th style="width:44px">预览</th><th>名称</th><th>原始文件名</th><th>大小</th><th style="width:70px">类型</th><th>尺寸</th><th style="width:100px">文件夹</th><th>链接</th><th style="width:120px">操作</th>
</tr></thead>
<tbody>
<?php if (empty($pageImages)): ?>
<tr><td colspan="10" class="empty">暂无记录，点击上方按钮添加</td></tr>
<?php else: foreach ($pageImages as $img):
    $imgLinks = $links->where(['image_id'=>$img['id']]);
    $hasValid = false;
    foreach ($imgLinks as $l) { if ($l['status'] === 'active') { $hasValid = true; break; } }
    $folderName = '';
    if (!empty($img['folder_id'])) {
        $f = $folders->find($img['folder_id']);
        $folderName = $f ? $f['name'] : '';
    }
    $displayName = $img['name'];
    $truncName = mb_strlen($displayName) > 15 ? mb_substr($displayName, 0, 15) . '...' : $displayName;
    $displayOrig = $img['original_name'] ?: '-';
    $truncOrig = mb_strlen($displayOrig) > 15 ? mb_substr($displayOrig, 0, 15) . '...' : $displayOrig;
    $icoPath = ICO_PATH . '/' . $img['id'] . '.jpg';
    $hasIco = file_exists($icoPath);
    $icoUrl = $hasIco ? SITE_URL . '/Stock/ico/' . $img['id'] . '.jpg' : '';
?>
<tr data-image-id="<?= htmlspecialchars($img['id']) ?>">
  <td><input type="checkbox" class="row-check thumb-target" value="<?= htmlspecialchars($img['id']) ?>" onchange="updateBatchBtns()"></td>
  <td><div class="tb-thumb <?= $hasIco ? 'loaded' : '' ?>"><?= $hasIco ? '<img src="'.htmlspecialchars($icoUrl).'" alt="" loading="lazy">' : '' ?></div></td>
  <td><strong title="<?= htmlspecialchars($displayName) ?>"><?= htmlspecialchars($truncName) ?></strong></td>
  <td style="font-size:12px;color:#888" title="<?= htmlspecialchars($displayOrig) ?>"><?= htmlspecialchars($truncOrig) ?></td>
  <td><?= $img['file_size'] ? ($img['file_size']>1048576 ? round($img['file_size']/1048576,1).'MB' : round($img['file_size']/1024,1).'KB') : '-' ?></td>
  <td style="font-size:12px"><?= htmlspecialchars($img['file_type'] ?: '-') ?></td>
  <td style="font-size:12px"><?= htmlspecialchars($img['dimensions'] ?: '-') ?></td>
  <td style="font-size:12px;color:#888"><?= htmlspecialchars($folderName ?: '未分类') ?></td>
  <td>
    <?php
      $imgExt = 'png';
      if ($img['file_type']) { $parts = explode('/', $img['file_type']); $imgExt = end($parts); }
      $uniUrl = SITE_URL . '/i/' . urlencode($img['name']) . '.' . $imgExt;
    ?>
    <div class="link-row uni-link" style="background:#f0f5ff;border:1px dashed #1677ff;border-radius:4px;padding:4px 6px;margin-bottom:6px">
      <span style="font-size:11px;color:#1677ff;font-weight:bold;white-space:nowrap">统一链接</span>
      <span class="url-txt" onclick="copyUrl('<?= htmlspecialchars($uniUrl) ?>')" title="点击复制"><?= htmlspecialchars($uniUrl) ?></span>
      <button class="btn btn-p btn-xs" onclick="copyUrl('<?= htmlspecialchars($uniUrl) ?>')">复制</button>
    </div>
    <?php foreach ($imgLinks as $lk): ?>
    <div class="link-row" id="link-row-<?= $lk['id'] ?>">
      <span class="url-txt" onclick="copyUrl('<?= htmlspecialchars($lk['url']) ?>')" title="点击复制：<?= htmlspecialchars($lk['url']) ?>"><?= htmlspecialchars($lk['label']) ?></span>
      <?php if ($lk['is_primary']): ?><span class="tag tag-p">主</span><?php endif; ?>
      <span class="tag <?= $lk['status']==='active'?'tag-ok':($lk['status']==='invalid'?'tag-fail':'tag-bk') ?>"><?= ['active'=>'有效','invalid'=>'失效','backup'=>'备用'][$lk['status']] ?></span>
      <button class="btn btn-d btn-xs" onclick="copyUrl('<?= htmlspecialchars($lk['url']) ?>')">复制</button>
      <button class="btn btn-d btn-xs" onclick="submitForm('check_link','link_id','<?= $lk['id'] ?>')">检测</button>
      <?php if (!$lk['is_primary']): ?>
      <button class="btn btn-g btn-xs" onclick="submitForm('set_primary','link_id','<?= $lk['id'] ?>')">设主</button>
      <?php endif; ?>
      <button class="btn btn-d btn-xs" onclick="editLinkInline('<?= $lk['id'] ?>','<?= htmlspecialchars(addslashes($lk['url'])) ?>','<?= htmlspecialchars(addslashes($lk['label'])) ?>')">编辑</button>
      <?php if (!$lk['is_primary']): ?>
      <button class="btn btn-r btn-xs" onclick="if(confirm('确认删除此链接？'))submitForm('delete_link','link_id','<?= $lk['id'] ?>')">删除</button>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <button class="btn btn-d btn-xs" style="margin-top:5px" onclick="showAddLink('<?= $img['id'] ?>')">+ 添加链接</button>
  </td>
  <td>
    <button class="btn btn-p btn-xs" onclick="showDetail('<?= $img['id'] ?>')">详情</button>
    <button class="btn btn-d btn-xs" style="margin-top:4px" onclick="getBest('<?= $img['id'] ?>')">取最佳</button>
    <button class="btn btn-r btn-xs" style="margin-top:4px" onclick="if(confirm('确认删除此图片及所有链接？'))submitForm('delete_image','image_id','<?= $img['id'] ?>')">删除</button>
  </td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>

<?php if ($totalPages > 1): ?>
<div class="pagination">
  <?php
  $f = htmlspecialchars($currentFolder);
  $pp = $perPage;
  // 上一页
  if ($page > 1): ?>
    <a href="?page=<?=($page-1)?>&per_page=<?=$pp?>&folder=<?=$f?>">上一页</a>
  <?php else: ?>
    <span class="disabled">上一页</span>
  <?php endif;
  // 页码：总页数<=7全部显示，否则用省略号
  if ($totalPages <= 7): 
    for ($i=1;$i<=$totalPages;$i++):
      if ($i==$page): ?><span class="active"><?=$i?></span><?php else: ?><a href="?page=<?=$i?>&per_page=<?=$pp?>&folder=<?=$f?>"><?=$i?></a><?php endif;
    endfor;
  else:
    $pages = [1];
    if ($page > 3) $pages[] = '...';
    for ($i=max(2,$page-1);$i<=min($totalPages-1,$page+1);$i++) $pages[] = $i;
    if ($page < $totalPages - 2) $pages[] = '...';
    $pages[] = $totalPages;
    foreach ($pages as $p):
      if ($p === '...'): ?><span>...</span><?php 
      elseif ($p == $page): ?><span class="active"><?=$p?></span><?php 
      else: ?><a href="?page=<?=$p?>&per_page=<?=$pp?>&folder=<?=$f?>"><?=$p?></a><?php endif;
    endforeach;
  endif;
  // 下一页
  if ($page < $totalPages): ?>
    <a href="?page=<?=($page+1)?>&per_page=<?=$pp?>&folder=<?=$f?>">下一页</a>
  <?php else: ?>
    <span class="disabled">下一页</span>
  <?php endif; ?>
  <span style="margin-left:12px">每页
    <?php foreach ([20,50,100,200] as $n): ?>
      <?php if ($n==$pp): ?><span class="active"><?=$n?></span><?php else: ?><a href="?page=1&per_page=<?=$n?>&folder=<?=$f?>"><?=$n?></a><?php endif; ?>
    <?php endforeach; ?>条
  </span>
</div>
<?php endif; ?>
</div>
</div>
</div>

<!-- 详情弹窗 -->
<div class="modal-o" id="detailModal"><div class="modal wide">
<h3>图片详情</h3>
<div class="detail-layout">
  <div style="display:flex;flex-direction:column;width:300px;flex-shrink:0">
    <div style="margin-bottom:8px" id="loadPreviewBtnArea"></div>
    <div class="detail-preview" id="detailPreview"></div>
  </div>
  <div class="detail-info" id="detailInfo"></div>
</div>
<div class="modal-btns">
  <select id="detailFolderSelect" onchange="moveToFolder()" style="padding:5px 8px;border:1px solid #d9d9d9;border-radius:4px;font-size:12px;margin-right:auto">
    <option value="">移动至...</option>
    <option value="">未分类</option>
    <?php foreach ($allFolders as $f): ?>
    <option value="<?= htmlspecialchars($f['id']) ?>"><?= htmlspecialchars($f['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <button type="button" class="btn btn-d" onclick="closeModal('detailModal')">关闭</button>
</div>
</div></div>

<!-- URL添加弹窗 -->
<div class="modal-o" id="urlModal"><div class="modal">
<h3>通过 URL 添加图片</h3>
<form method="post"><input type="hidden" name="action" value="url_add">
  <div class="fg"><label>图片 URL *</label><input type="url" name="url" required placeholder="https://example.com/image.png"></div>
  <div class="fg"><label>图片名称</label><input type="text" name="name" placeholder="留空自动解析URL文件名"></div>
  <div class="fg"><label>链接标签</label><input type="text" name="label" value="默认" placeholder="默认"></div>
  <div class="fg"><label>图片尺寸</label><input type="text" name="dimensions" placeholder="如 1920x1080"></div>
  <div class="fg"><label>所属文件夹</label><select name="folder_id">
    <option value="">未分类</option>
    <?php foreach ($allFolders as $f): ?>
    <option value="<?= htmlspecialchars($f['id']) ?>" <?= $currentFolder!=='all' && $currentFolder===$f['id']?'selected':'' ?>><?= htmlspecialchars($f['name']) ?></option>
    <?php endforeach; ?>
  </select></div>
  <div class="modal-btns">
    <button type="submit" class="btn btn-p">添加</button>
    <button type="button" class="btn btn-d" onclick="closeModal('urlModal')">取消</button>
  </div>
</form></div></div>

<!-- 手动创建弹窗 -->
<div class="modal-o" id="manualModal"><div class="modal">
<h3>手动创建图片记录</h3>
<form method="post"><input type="hidden" name="action" value="manual_add">
  <div class="fg"><label>图片名称 *</label><input type="text" name="name" required placeholder="给图片取个名字"></div>
  <div class="fg"><label>原始文件名</label><input type="text" name="original_name" placeholder="如 photo_001.jpg"></div>
  <div class="fg-row">
    <div class="fg"><label>文件大小 (KB)</label><input type="number" name="file_size" step="0.1" placeholder="如 256.5"></div>
    <div class="fg"><label>图片类型</label><select name="file_type">
      <option value="">-- 未知 --</option>
      <option>image/png</option><option>image/jpeg</option><option>image/gif</option>
      <option>image/webp</option><option>image/bmp</option><option>image/svg+xml</option>
      <option>image/avif</option>
    </select></div>
  </div>
  <div class="fg"><label>尺寸</label><input type="text" name="dimensions" placeholder="如 1920x1080"></div>
  <div class="fg"><label>所属文件夹</label><select name="folder_id">
    <option value="">未分类</option>
    <?php foreach ($allFolders as $f): ?>
    <option value="<?= htmlspecialchars($f['id']) ?>" <?= $currentFolder!=='all' && $currentFolder===$f['id']?'selected':'' ?>><?= htmlspecialchars($f['name']) ?></option>
    <?php endforeach; ?>
  </select></div>
  <div class="modal-btns">
    <button type="submit" class="btn btn-p">创建</button>
    <button type="button" class="btn btn-d" onclick="closeModal('manualModal')">取消</button>
  </div>
</form></div></div>

<!-- 添加链接弹窗 -->
<div class="modal-o" id="linkModal"><div class="modal">
<h3>添加备用链接</h3>
<form method="post"><input type="hidden" name="action" value="add_link">
  <input type="hidden" name="image_id" id="linkImgId">
  <div class="fg"><label>链接 URL *</label><input type="url" name="url" required placeholder="https://..."></div>
  <div class="fg"><label>标签</label><input type="text" name="label" value="备用" placeholder="备用/CDN/图床2"></div>
  <div class="modal-btns">
    <button type="submit" class="btn btn-p">添加</button>
    <button type="button" class="btn btn-d" onclick="closeModal('linkModal')">取消</button>
  </div>
</form></div></div>

<!-- 批量复制链接弹窗 -->
<div class="modal-o" id="batchCopyModal"><div class="modal wide">
<h3>批量复制链接</h3>
<p style="font-size:12px;color:#999;margin-bottom:12px">为每张图片选择一个链接，点击按钮复制全部选中链接（每行一个URL）</p>
<div class="batch-header">
  <label style="font-size:12px;cursor:pointer"><input type="checkbox" id="batchCopySelectAll" onchange="toggleAllCopyCheck(this)"> 全选</label>
  <span style="margin-left:auto;font-size:12px;color:#999">默认选择：最佳链接</span>
</div>
<div class="batch-list" id="batchCopyList"></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doBatchCopy()">一键复制选中链接</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchCopyModal')">取消</button>
</div>
</div></div>

<!-- 批量下载弹窗 -->
<div class="modal-o" id="batchDownloadModal"><div class="modal wide">
<h3>批量下载图片</h3>
<div class="batch-header">
  <label style="font-size:12px;cursor:pointer"><input type="checkbox" id="batchDlSelectAll" onchange="toggleAllDlCheck(this)"> 全选</label>
  <span style="font-size:12px;color:#999">当前筛选共 <span id="batchDlCount">0</span> 张</span>
</div>
<div class="batch-list" id="batchDownloadList" style="max-height:250px"></div>
<div class="fg-row">
  <div class="fg">
    <label>命名方式</label>
    <select id="dlNamingMode">
      <option value="original">原始名称</option>
      <option value="custom">自定义名称</option>
    </select>
  </div>
  <div class="fg" id="dlCustomNameWrap" style="display:none">
    <label>自定义名称</label>
    <input type="text" id="dlCustomName" placeholder="如 my_image">
    <div class="hint">多张图片会自动添加序号：my_image_1.jpg</div>
  </div>
</div>
<div class="fg">
  <label>目标文件夹</label>
  <div style="display:flex;gap:8px">
    <select id="dlFolderSelect" style="flex:1;padding:7px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px">
      <option value="默认">默认</option>
      <?php foreach ($downloadDirs as $dd): ?>
      <option value="<?= htmlspecialchars($dd) ?>"><?= htmlspecialchars($dd) ?></option>
      <?php endforeach; ?>
      <option value="__new__">+ 新建文件夹</option>
    </select>
    <input type="text" id="dlNewFolder" placeholder="新文件夹名" style="flex:1;padding:7px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px;display:none">
  </div>
  <div class="hint">图片将下载到 Stock/systemtmp/down/{文件夹}/</div>
</div>
<div class="dl-progress" id="dlProgress">
  <div class="bar"><div id="dlProgressBar" style="width:0%"></div></div>
  <div class="txt" id="dlProgressTxt">准备中...</div>
</div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" id="startDlBtn" onclick="startBatchDownload()">开始下载</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchDownloadModal')">取消</button>
</div>
</div></div>

<!-- 批量移动弹窗 -->
<div class="modal-o" id="batchMoveModal"><div class="modal">
<h3>移动到文件夹</h3>
<p style="font-size:12px;color:#999;margin-bottom:12px">将选中的图片移动到目标文件夹</p>
<div class="fg"><label>目标文件夹</label><select id="batchMoveFolder">
  <option value="">未分类</option>
  <?php foreach ($allFolders as $f): ?>
  <option value="<?= htmlspecialchars($f['id']) ?>"><?= htmlspecialchars($f['name']) ?></option>
  <?php endforeach; ?>
</select></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doBatchMove()">确定移动</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchMoveModal')">取消</button>
</div>
</div></div>

<!-- 下载选项弹窗（详情页单文件） -->
<div class="modal-o" id="downloadOptModal"><div class="modal" style="width:360px">
  <h3>下载选项</h3>
  <p style="font-size:13px;color:#666;margin-bottom:16px" id="downloadOptName"></p>
  <div class="modal-btns" style="flex-direction:column;gap:10px">
    <button type="button" class="btn btn-p" onclick="doDownloadCached()" style="width:100%">缓存后下载</button>
    <button type="button" class="btn btn-d" onclick="doDownloadDirect()" style="width:100%">直接访问</button>
    <button type="button" class="btn" style="width:100%;background:#f5f5f5;color:#666" onclick="closeModal('downloadOptModal')">取消</button>
  </div>
</div></div>

<!-- 批量下载选项弹窗 -->
<div class="modal-o" id="batchDownloadOptModal"><div class="modal" style="width:380px">
  <h3>批量下载选项</h3>
  <p style="font-size:13px;color:#666;margin-bottom:16px" id="batchDownloadOptCount"></p>
  <div class="modal-btns" style="flex-direction:column;gap:10px">
    <button type="button" class="btn btn-p" onclick="doBatchCached()" style="width:100%">缓存后下载</button>
    <button type="button" class="btn btn-w" onclick="doBatchZIP()" style="width:100%">打包自动下载</button>
    <button type="button" class="btn" style="width:100%;background:#f5f5f5;color:#666" onclick="closeModal('batchDownloadOptModal')">取消</button>
  </div>
</div></div>

<!-- 文件管理快速访问弹窗 -->
<div class="modal-o qa-modal" id="quickAccessModal"><div class="modal">
<div class="qa-header">
  <div class="qa-tabs">
    <div class="qa-tab active" data-tab="url" onclick="qaSwitchTab('url')">直链</div>
    <div class="qa-tab" data-tab="ftp" onclick="qaSwitchTab('ftp')">FTP</div>
  </div>
  <button class="qa-top-btn" onclick="qaOpenNewWindow()" title="新窗口打开">↗ 新窗口打开</button>
</div>
<div class="qa-body">
  <div class="qa-panel active" id="qaPanelUrl">
    <div class="fg">
      <label>访问地址</label>
      <input type="text" id="qaUrl" value="" placeholder="未配置" readonly style="background:#fafafa">
    </div>
  </div>
  <div class="qa-panel" id="qaPanelFtp">
    <div class="fg-row">
      <div class="fg"><label>主机</label><input type="text" id="qaFtpHost" value="" placeholder="未配置" readonly style="background:#fafafa"></div>
      <div class="fg" style="max-width:80px"><label>端口</label><input type="number" id="qaFtpPort" value="" placeholder="21" readonly style="background:#fafafa"></div>
    </div>
    <div class="fg-row">
      <div class="fg"><label>用户名</label><input type="text" id="qaFtpUser" value="" placeholder="未配置" readonly style="background:#fafafa"></div>
      <div class="fg"><label>密码</label><input type="password" id="qaFtpPass" value="" placeholder="未配置" readonly style="background:#fafafa"></div>
    </div>
  </div>
  <div class="modal-btns" style="margin-top:8px">
    <button type="button" class="btn" style="background:#f5f5f5;color:#666" onclick="closeModal('quickAccessModal')">关闭</button>
  </div>
</div>
</div></div>

<div class="toast" id="toast"></div>

<script>
var IMAGE_DATA = <?= json_encode($imageDataMap, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
var SITE_URL = <?= json_encode(SITE_URL) ?>;
var QUICK_ACCESS_CFG = <?= file_exists(DATA_PATH . '/quick_access.json') ? file_get_contents(DATA_PATH . '/quick_access.json') : '{"url":"","ftp":{"host":"","port":"21","user":"","pass":""}}' ?>;
var CURRENT_DETAIL_ID = null;
var ALL_IMAGE_DATA = IMAGE_DATA;

function T(m,t){var e=document.getElementById('toast');e.textContent=m;e.className='toast '+t+' show';setTimeout(function(){e.classList.remove('show')},2500)}
function showModal(id){document.getElementById(id).classList.add('show')}
function closeModal(id){document.getElementById(id).classList.remove('show')}
function showAddLink(id){document.getElementById('linkImgId').value=id;showModal('linkModal')}

/* 文件管理快速访问 */
function showQuickAccess(){
  var c=QUICK_ACCESS_CFG;
  document.getElementById('qaUrl').value=c.url||'';
  document.getElementById('qaFtpHost').value=c.ftp.host||'';
  document.getElementById('qaFtpPort').value=c.ftp.port||'21';
  document.getElementById('qaFtpUser').value=c.ftp.user||'';
  document.getElementById('qaFtpPass').value=c.ftp.pass||'';
  qaSwitchTab('url');
  showModal('quickAccessModal');
}
function qaSwitchTab(tab){
  document.querySelectorAll('.qa-tab').forEach(function(t){t.classList.toggle('active',t.dataset.tab===tab)});
  document.querySelectorAll('.qa-panel').forEach(function(p){p.classList.toggle('active',p.id==='qaPanel'+tab.charAt(0).toUpperCase()+tab.slice(1))});
}
function qaOpenNewWindow(){
  var activeTab=document.querySelector('.qa-tab.active').dataset.tab;
  var c=QUICK_ACCESS_CFG;
  if(activeTab==='url'){
    if(c.url)window.open(c.url,'_blank');
    else T('请先在设置页面配置直链地址','err');
  }else{
    var h=c.ftp.host,p=c.ftp.port||21;
    if(!h){T('请先在设置页面配置FTP信息','err');return}
    window.open('ftp://'+c.ftp.user+':'+c.ftp.pass+'@'+h+':'+p+'/','_blank');
  }
}

function copyUrl(url){if(navigator.clipboard){navigator.clipboard.writeText(url).then(function(){T('已复制','ok')})}else{var ta=document.createElement('textarea');ta.value=url;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();document.execCommand('copy');document.body.removeChild(ta);T('已复制','ok')}}

function showAbout(){showModal('aboutModal')}

function submitForm(action, key, val){
  var f=document.createElement('form');f.method='post';f.style.display='none';
  var h='<input type="hidden" name="action" value="'+action+'">';
  if(key)h+='<input type="hidden" name="'+key+'" value="'+val+'">';
  f.innerHTML=h;document.body.appendChild(f);f.submit();
}

function submitFormMulti(action, fields){
  var f=document.createElement('form');f.method='post';f.style.display='none';
  var h='<input type="hidden" name="action" value="'+action+'">';
  for(var k in fields){h+='<input type="hidden" name="'+k+'" value="'+fields[k]+'">';}
  f.innerHTML=h;document.body.appendChild(f);f.submit();
}

/* 缩略图 */
function getCheckedThumbIds(){
  var ids=[];
  document.querySelectorAll('.row-check.thumb-target:checked').forEach(function(cb){ids.push(cb.value)});
  return ids;
}
function fetchThumbs(){
  var ids=getCheckedThumbIds();
  if(!ids.length){T('请先勾选需要获取缩略图的图片','warn');return}
  submitFormMulti('fetch_thumbs',{ids:JSON.stringify(ids)});
}
function refreshThumbs(){
  if(!confirm('缓存刷新将删除所有已缓存的缩略图并重新生成，可能耗时较长。确定继续？'))return;
  submitForm('refresh_thumbs');
}

function getBest(id){
  fetch('api/replace.php?image_id='+id).then(function(r){return r.json()}).then(function(d){
    if(d.ok){navigator.clipboard.writeText(d.url);T('最佳链接已复制','ok')}
    else T('无可用链接','err')
  })
}

// 搜索过滤
function filterTable(){
  var query = document.getElementById('searchInput').value.toLowerCase();
  var rows = document.querySelectorAll('#imageTable tbody tr[data-image-id]');
  var found = 0;
  rows.forEach(function(row){
    var cells = row.querySelectorAll('td');
    if(cells.length < 3) return;
    var name = (cells[1].textContent || '').toLowerCase();
    var orig = (cells[2].textContent || '').toLowerCase();
    if(!query || name.indexOf(query)!==-1 || orig.indexOf(query)!==-1){
      row.style.display = '';
      found++;
    }else{
      row.style.display = 'none';
    }
  });
  var noRes = document.getElementById('noSearchResult');
  if(!query){
    if(noRes) noRes.style.display = 'none';
  }else if(found === 0){
    if(!noRes){
      noRes = document.createElement('tr');
      noRes.id = 'noSearchResult';
      noRes.innerHTML = '<td colspan="9" class="empty">没有匹配的记录</td>';
      document.querySelector('#imageTable tbody').appendChild(noRes);
    }
    noRes.style.display = '';
  }else{
    if(noRes) noRes.style.display = 'none';
  }
}

// 获取当前可见图片的ID列表
function getVisibleImageIds(){
  var ids = [];
  var rows = document.querySelectorAll('#imageTable tbody tr[data-image-id]');
  rows.forEach(function(row){
    if(row.style.display !== 'none'){
      ids.push(row.getAttribute('data-image-id'));
    }
  });
  return ids;
}

// 详情弹窗
function showDetail(imageId){
  CURRENT_DETAIL_ID = imageId;
  var data = ALL_IMAGE_DATA[imageId];
  if(!data){T('数据加载失败','err');return;}

  var preview = document.getElementById('detailPreview');
  var btnArea = document.getElementById('loadPreviewBtnArea');
  if(data.preview){
    btnArea.innerHTML = '';
    var ext = data.preview.ext || 'jpg';
    preview.innerHTML = '<img src="'+data.preview.url+'" alt="'+escHtml(data.name)+'" onerror="this.parentElement.innerHTML=\'<div class=no-preview>预览加载失败</div>\'">' +
      '<div class="dl-btn-area"><button class="btn btn-g btn-xs" onclick="downloadSingle(\''+imageId+'\',\''+escAttr(data.name)+'\')">下载图片</button></div>';
  }else{
    btnArea.innerHTML = '<button class="btn btn-p btn-xs" onclick="loadPreview(\''+imageId+'\')">加载预览</button>';
    preview.innerHTML = '<div class="no-preview">点击「<span style="color:#1677ff">加载预览</span>」按钮查看图片</div>' +
      '<div class="dl-btn-area"><button class="btn btn-g btn-xs" onclick="downloadSingle(\''+imageId+'\',\''+escAttr(data.name)+'\')">下载图片</button></div>';
  }

  var info = document.getElementById('detailInfo');
  var sizeStr = data.file_size ? (data.file_size>1048576 ? (data.file_size/1048576).toFixed(1)+'MB' : (data.file_size/1024).toFixed(1)+'KB') : '-';
  var primaryLink = null;
  var otherLinks = [];
  if(data.links){
    for(var i=0; i<data.links.length; i++){
      var lk = data.links[i];
      if(lk.is_primary) primaryLink = lk;
      else otherLinks.push(lk);
    }
    if(!primaryLink && data.links.length>0){primaryLink = data.links[0]; otherLinks = data.links.slice(1);}
  }

  var sizeKB = data.file_size ? (data.file_size / 1024).toFixed(1) : '';
  var html = '';

  html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">';
  html += '<strong style="font-size:13px">属性</strong>';
  html += '<button class="btn btn-d btn-xs" id="editAttrBtn" onclick="toggleEditMode()">编辑</button>';
  html += '<button class="btn btn-d btn-xs" onclick="refetchImage()">重新获取</button>';
  html += '<button class="btn btn-d btn-xs" onclick="downloadToLocal(\''+imageId+'\',\''+escAttr(data.name)+'\')">下载至本地</button>';
  html += '</div>';

  html += '<table id="attrTable">';
  html += '<tr><td class="attr-label">名称</td><td><span id="attr-name-view"><strong>'+escHtml(data.name)+'</strong></span><input type="text" id="attr-name-edit" value="'+escHtml(data.name)+'" style="display:none;width:100%;padding:3px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px"></td></tr>';
  html += '<tr><td class="attr-label">原始名称</td><td><span id="attr-orig-view">'+escHtml(data.original_name || '-')+'</span><input type="text" id="attr-orig-edit" value="'+escHtml(data.original_name || '')+'" style="display:none;width:100%;padding:3px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px"></td></tr>';
  html += '<tr><td class="attr-label">大小 (KB)</td><td><span id="attr-size-view">'+sizeStr+'</span><input type="number" id="attr-size-edit" value="'+sizeKB+'" step="0.1" style="display:none;width:100%;padding:3px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px"></td></tr>';
  html += '<tr><td class="attr-label">类型</td><td><span id="attr-type-view">'+escHtml(data.file_type || '-')+'</span><select id="attr-type-edit" style="display:none;width:100%;padding:3px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px"><option value="">未知</option><option value="image/png">image/png</option><option value="image/jpeg">image/jpeg</option><option value="image/gif">image/gif</option><option value="image/webp">image/webp</option><option value="image/bmp">image/bmp</option><option value="image/svg+xml">image/svg+xml</option><option value="image/avif">image/avif</option></select></td></tr>';
  html += '<tr><td class="attr-label">尺寸</td><td><span id="attr-dim-view">'+escHtml(data.dimensions || '-')+'</span><input type="text" id="attr-dim-edit" value="'+escHtml(data.dimensions || '')+'" style="display:none;width:100%;padding:3px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px" placeholder="如 1920x1080"></td></tr>';
  html += '<tr><td class="attr-label">文件夹</td><td>'+escHtml(data.folder_name || '未分类')+'</td></tr>';
  html += '</table>';

  html += '<div id="editControls" style="display:none;margin-top:8px;gap:8px">';
  html += '<button class="btn btn-g btn-xs" onclick="saveEdit()">保存</button>';
  html += '<button class="btn btn-d btn-xs" onclick="cancelEdit()">取消</button>';
  html += '</div>';

  html += '<div class="detail-links"><strong style="font-size:13px">链接列表</strong>';
  if(primaryLink){
    html += '<div class="link-item" id="detail-link-'+primaryLink.id+'"><span class="tag tag-p">主</span><span class="tag tag-'+(primaryLink.status==='active'?'ok':(primaryLink.status==='invalid'?'fail':'bk'))+'">'+({'active':'有效','invalid':'失效','backup':'备用'}[primaryLink.status]||primaryLink.status)+'</span><span class="lk-url" title="'+escHtml(primaryLink.url)+'">'+escHtml(primaryLink.label)+': '+escHtml(primaryLink.url)+'</span><button class="btn btn-d btn-xs" onclick="copyUrl(\''+escAttr(primaryLink.url)+'\')">复制</button><button class="btn btn-d btn-xs" onclick="editLinkInline(\''+primaryLink.id+'\',\''+escAttr(primaryLink.url)+'\',\''+escAttr(primaryLink.label)+'\')">编辑</button></div>';
  }
  for(var j=0; j<otherLinks.length; j++){
    var ol = otherLinks[j];
    html += '<div class="link-item" id="detail-link-'+ol.id+'"><span class="tag tag-'+(ol.status==='active'?'ok':(ol.status==='invalid'?'fail':'bk'))+'">'+({'active':'有效','invalid':'失效','backup':'备用'}[ol.status]||ol.status)+'</span><span class="lk-url" title="'+escHtml(ol.url)+'">'+escHtml(ol.label)+': '+escHtml(ol.url)+'</span><button class="btn btn-d btn-xs" onclick="copyUrl(\''+escAttr(ol.url)+'\')">复制</button><button class="btn btn-d btn-xs" onclick="editLinkInline(\''+ol.id+'\',\''+escAttr(ol.url)+'\',\''+escAttr(ol.label)+'\')">编辑</button><button class="btn btn-r btn-xs" onclick="deleteDetailLink(\''+ol.id+'\')">删除</button></div>';
  }
  if(!primaryLink && otherLinks.length===0){
    html += '<div style="color:#bbb;font-size:12px">暂无链接</div>';
  }
  html += '</div>';

  var pUrl = primaryLink ? primaryLink.url : '';
  var pName = data.name;
  var formats = {
    'HTML': '&lt;img src=&quot;'+escHtml(pUrl)+'&quot; alt=&quot;'+escHtml(pName)+'&quot;&gt;',
    'Markdown': '!['+pName+']('+pUrl+')',
    'MarkdownWithLink': '[!['+pName+']('+pUrl+')]('+pUrl+')',
    'BBCode': '[img]'+pUrl+'[/img]'
  };

  html += '<div class="format-tabs">';
  html += '<button class="tab-btn active" onclick="switchTab(this,\'HTML\')">HTML</button>';
  html += '<button class="tab-btn" onclick="switchTab(this,\'Markdown\')">Markdown</button>';
  html += '<button class="tab-btn" onclick="switchTab(this,\'MarkdownWithLink\')">MarkdownWithLink</button>';
  html += '<button class="tab-btn" onclick="switchTab(this,\'BBCode\')">BBCode</button>';
  html += '</div>';

  var keys = ['HTML','Markdown','MarkdownWithLink','BBCode'];
  for(var k=0; k<keys.length; k++){
    var display = k===0 ? 'block' : 'none';
    html += '<div class="format-content" id="fmt-'+keys[k]+'" style="display:'+display+'">';
    html += '<textarea readonly rows="3" id="fmt-text-'+keys[k]+'">'+formats[keys[k]]+'</textarea>';
    html += '<button class="copy-btn" onclick="copyFormat(\''+keys[k]+'\')">一键复制</button>';
    html += '</div>';
  }

  document.getElementById('detailFolderSelect').value = data.folder_id || '';
  info.innerHTML = html;
  var typeSel = document.getElementById('attr-type-edit');
  if(typeSel) typeSel.value = data.file_type || '';
  showModal('detailModal');
}

function switchTab(btn, name){
  var tabs = btn.parentElement.querySelectorAll('.tab-btn');
  for(var i=0;i<tabs.length;i++) tabs[i].classList.remove('active');
  btn.classList.add('active');
  var keys = ['HTML','Markdown','MarkdownWithLink','BBCode'];
  for(var j=0;j<keys.length;j++){
    document.getElementById('fmt-'+keys[j]).style.display = keys[j]===name ? 'block' : 'none';
  }
}

function copyFormat(name){
  var ta = document.getElementById('fmt-text-'+name);
  var text = ta.value;
  if(navigator.clipboard){navigator.clipboard.writeText(text).then(function(){T('格式已复制','ok')})}
  else{var tmp=document.createElement('textarea');tmp.value=text;tmp.style.position='fixed';tmp.style.opacity='0';document.body.appendChild(tmp);tmp.select();document.execCommand('copy');document.body.removeChild(tmp);T('格式已复制','ok')}
}

function moveToFolder(){
  var sel = document.getElementById('detailFolderSelect');
  if(!CURRENT_DETAIL_ID || !sel.value && sel.value!=='') return;
  submitFormMulti('move_to_folder', {image_id: CURRENT_DETAIL_ID, folder_id: sel.value});
}

// 单张下载
function downloadSingle(imageId, name){
  var folder = '默认';
  T('开始下载: '+name,'ok');
  var formData = new FormData();
  formData.append('image_id', imageId);
  formData.append('folder_name', folder);
  fetch('api/download.php', {method:'POST', body:formData})
    .then(function(r){return r.json()})
    .then(function(d){
      if(d.ok){T('下载完成: '+d.path,'ok')}
      else{T('下载失败: '+d.error,'err')}
    });
}

function escHtml(s){return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function escAttr(s){return (s||'').replace(/'/g,"\\'").replace(/"/g,'&quot;');}

function startRename(fid, oldName){
  var newName = prompt('重命名文件夹：', oldName);
  if(newName && newName.trim() && newName.trim() !== oldName){
    submitFormMulti('folder_rename', {folder_id: fid, folder_name: newName.trim()});
  }
}

// ========== 批量复制链接 ==========
function showBatchCopy(){
  var ids = getVisibleImageIds();
  var listDiv = document.getElementById('batchCopyList');
  var html = '';
  for(var i=0; i<ids.length; i++){
    var data = ALL_IMAGE_DATA[ids[i]];
    if(!data || !data.links || data.links.length===0) continue;
    html += '<div class="batch-item" data-image-id="'+data.id+'">';
    html += '<input type="checkbox" class="batch-copy-check" checked onchange="updateCopySelectAll()">';
    html += '<span class="bi-name" title="'+escHtml(data.name)+'">'+escHtml(data.name)+'</span>';
    html += '<span class="bi-links">';
    for(var j=0; j<data.links.length; j++){
      var lk = data.links[j];
      var checked = lk.is_primary ? ' checked' : '';
      html += '<label><input type="radio" name="copy_link_'+data.id+'" value="'+j+'"'+checked+'> '+escHtml(lk.label)+'</label>';
    }
    html += '</span></div>';
  }
  if(!html) html = '<div class="empty" style="padding:20px">当前筛选无可用图片</div>';
  listDiv.innerHTML = html;
  document.getElementById('batchCopySelectAll').checked = true;
  showModal('batchCopyModal');
}

function toggleAllCopyCheck(cb){
  var checks = document.querySelectorAll('#batchCopyList .batch-copy-check');
  for(var i=0;i<checks.length;i++) checks[i].checked = cb.checked;
}

function updateCopySelectAll(){
  var checks = document.querySelectorAll('#batchCopyList .batch-copy-check');
  var allChecked = true;
  for(var i=0;i<checks.length;i++){if(!checks[i].checked){allChecked=false;break;}}
  document.getElementById('batchCopySelectAll').checked = allChecked;
}

function doBatchCopy(){
  var items = document.querySelectorAll('#batchCopyList .batch-item');
  var urls = [];
  for(var i=0;i<items.length;i++){
    var cb = items[i].querySelector('.batch-copy-check');
    if(!cb.checked) continue;
    var imageId = items[i].getAttribute('data-image-id');
    var selected = items[i].querySelector('input[type=radio]:checked');
    if(!selected) continue;
    var linkIdx = parseInt(selected.value);
    var data = ALL_IMAGE_DATA[imageId];
    if(data && data.links && data.links[linkIdx]){
      urls.push(data.links[linkIdx].url);
    }
  }
  if(urls.length===0){T('没有选中任何链接','warn');return;}
  navigator.clipboard.writeText(urls.join('\n')).then(function(){
    T('已复制 '+urls.length+' 个链接','ok');
    closeModal('batchCopyModal');
  });
}

// ========== 批量下载 ==========
function showBatchDownload(){
  var ids = getVisibleImageIds();
  var listDiv = document.getElementById('batchDownloadList');
  document.getElementById('batchDlCount').textContent = ids.length;
  var html = '';
  for(var i=0; i<ids.length; i++){
    var data = ALL_IMAGE_DATA[ids[i]];
    if(!data) continue;
    html += '<div class="batch-item" data-image-id="'+data.id+'">';
    html += '<input type="checkbox" class="batch-dl-check" checked onchange="updateDlSelectAll()">';
    html += '<span class="bi-name" title="'+escHtml(data.name)+'">'+escHtml(data.name)+'</span>';
    if(data.links && data.links.length>0){
      html += '<span style="font-size:11px;color:#999">'+data.links.length+'个链接</span>';
    }else{
      html += '<span style="font-size:11px;color:#ff4d4f">无链接</span>';
    }
    html += '</div>';
  }
  if(!html) html = '<div class="empty" style="padding:20px">当前筛选无可用图片</div>';
  listDiv.innerHTML = html;
  document.getElementById('batchDlSelectAll').checked = true;
  document.getElementById('dlProgress').style.display = 'none';
  document.getElementById('startDlBtn').disabled = false;
  showModal('batchDownloadModal');
}

function toggleAllDlCheck(cb){
  var checks = document.querySelectorAll('#batchDownloadList .batch-dl-check');
  for(var i=0;i<checks.length;i++) checks[i].checked = cb.checked;
}

function updateDlSelectAll(){
  var checks = document.querySelectorAll('#batchDownloadList .batch-dl-check');
  var allChecked = true;
  for(var i=0;i<checks.length;i++){if(!checks[i].checked){allChecked=false;break;}}
  document.getElementById('batchDlSelectAll').checked = allChecked;
}

// 下载文件夹下拉联动
document.addEventListener('DOMContentLoaded', function(){
  var dlFolderSelect = document.getElementById('dlFolderSelect');
  var dlNewFolder = document.getElementById('dlNewFolder');
  if(dlFolderSelect){
    dlFolderSelect.onchange = function(){
      if(this.value === '__new__'){
        dlNewFolder.style.display = '';
        dlNewFolder.focus();
      }else{
        dlNewFolder.style.display = 'none';
      }
    };
  }
  var dlNamingMode = document.getElementById('dlNamingMode');
  var dlCustomNameWrap = document.getElementById('dlCustomNameWrap');
  if(dlNamingMode){
    dlNamingMode.onchange = function(){
      dlCustomNameWrap.style.display = this.value === 'custom' ? '' : 'none';
    };
  }
});

function startBatchDownload(){
  var items = document.querySelectorAll('#batchDownloadList .batch-item');
  var ids = [];
  for(var i=0;i<items.length;i++){
    var cb = items[i].querySelector('.batch-dl-check');
    if(cb.checked) ids.push(items[i].getAttribute('data-image-id'));
  }
  if(ids.length===0){T('请选择至少一张图片','warn');return;}

  var namingMode = document.getElementById('dlNamingMode').value;
  var customName = document.getElementById('dlCustomName').value.trim();
  var folderSelect = document.getElementById('dlFolderSelect');
  var folderName = folderSelect.value;
  if(folderName === '__new__'){
    folderName = document.getElementById('dlNewFolder').value.trim();
    if(!folderName){T('请输入新文件夹名称','warn');return;}
  }

  if(namingMode === 'custom' && !customName){T('请输入自定义名称','warn');return;}

  document.getElementById('dlProgress').style.display = '';
  document.getElementById('startDlBtn').disabled = true;
  var progressBar = document.getElementById('dlProgressBar');
  var progressTxt = document.getElementById('dlProgressTxt');
  progressBar.style.width = '0%';
  progressTxt.textContent = '准备下载...';

  var total = ids.length;
  var completed = 0;
  var failed = 0;

  function downloadNext(index){
    if(index >= ids.length){
      progressTxt.textContent = '下载完成：成功 '+(total-failed)+' 张，失败 '+failed+' 张';
      T('批量下载完成','ok');
      document.getElementById('startDlBtn').disabled = false;
      return;
    }
    var imageId = ids[index];
    var formData = new FormData();
    formData.append('image_id', imageId);
    formData.append('folder_name', folderName);
    if(namingMode === 'custom' && customName){
      formData.append('custom_name', customName + (total > 1 ? '_'+(index+1) : ''));
    }
    progressTxt.textContent = '下载中 '+(index+1)+'/'+total+'...';
    fetch('api/download.php', {method:'POST', body:formData})
      .then(function(r){return r.json()})
      .then(function(d){
        completed++;
        if(!d.ok) failed++;
        progressBar.style.width = Math.round(completed/total*100)+'%';
        downloadNext(index+1);
      })
      .catch(function(){
        completed++; failed++;
        progressBar.style.width = Math.round(completed/total*100)+'%';
        downloadNext(index+1);
      });
  }
  downloadNext(0);
}

// ========== 加载预览图 ==========
function loadPreview(imageId){
  var data = ALL_IMAGE_DATA[imageId];
  if(!data || !data.links || data.links.length===0){T('没有可用链接','err');return;}
  var url = null;
  // 优先使用主链接
  for(var i=0; i<data.links.length; i++){
    if(data.links[i].is_primary){url=data.links[i].url;break;}
  }
  if(!url) url = data.links[0].url;
  // 如果主链接失效，尝试第一个有效备用链接
  for(var k=0; k<data.links.length; k++){
    var lk = data.links[k];
    if(lk.is_primary && lk.status==='invalid'){
      // 找有效备用
      for(var m=0; m<data.links.length; m++){
        if(!data.links[m].is_primary && data.links[m].status==='active'){
          url = data.links[m].url; break;
        }
      }
      break;
    }
  }
  var preview = document.getElementById('detailPreview');
  var btnArea = document.getElementById('loadPreviewBtnArea');
  btnArea.innerHTML = '';
  var img = new Image();
  img.style.maxWidth='100%'; img.style.maxHeight='300px'; img.style.objectFit='contain';
  img.alt = data.name;
  img.onload = function(){
    preview.innerHTML = '';
    preview.appendChild(img);
    var dlArea = document.createElement('div');
    dlArea.className = 'dl-btn-area';
    dlArea.innerHTML = '<button class="btn btn-g btn-xs" onclick="downloadSingle(\''+imageId+'\',\''+escAttr(data.name)+'\')">下载图片</button>';
    preview.appendChild(dlArea);
  };
  img.onerror = function(){
    preview.innerHTML = '<div class="no-preview">预览加载失败<br><small>主链接和备用链接均无法访问</small></div>' +
      '<div class="dl-btn-area"><button class="btn btn-g btn-xs" onclick="downloadSingle(\''+imageId+'\',\''+escAttr(data.name)+'\')">下载图片</button></div>';
  };
  img.src = url;
}

// ========== 链接编辑 ==========
function editLinkInline(linkId, url, label){
  var row = document.getElementById('link-row-'+linkId) || document.getElementById('detail-link-'+linkId);
  if(!row) return;
  var oldHTML = row.innerHTML;
  row.setAttribute('data-old-html', oldHTML);
  row.innerHTML = '<input type="text" id="edit-link-url-'+linkId+'" value="'+escHtml(url)+'" style="flex:1;min-width:120px;padding:2px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px;margin-right:4px">' +
    '<input type="text" id="edit-link-label-'+linkId+'" value="'+escHtml(label)+'" style="width:60px;padding:2px 6px;border:1px solid #d9d9d9;border-radius:3px;font-size:12px;margin-right:4px">' +
    '<button class="btn btn-g btn-xs" onclick="saveLinkEdit(\''+linkId+'\')">保存</button>' +
    '<button class="btn btn-d btn-xs" onclick="cancelLinkEdit(\''+linkId+'\')">取消</button>';
}

function saveLinkEdit(linkId){
  var urlInput = document.getElementById('edit-link-url-'+linkId);
  var labelInput = document.getElementById('edit-link-label-'+linkId);
  if(!urlInput || !labelInput) return;
  var newUrl = urlInput.value.trim();
  var newLabel = labelInput.value.trim();
  if(!newUrl){T('URL不能为空','err');return;}
  var f = document.createElement('form');
  f.method = 'post'; f.style.display = 'none';
  f.innerHTML = '<input type="hidden" name="action" value="edit_link">' +
    '<input type="hidden" name="link_id" value="'+linkId+'">' +
    '<input type="hidden" name="url" value="'+escHtml(newUrl)+'">' +
    '<input type="hidden" name="label" value="'+escHtml(newLabel)+'">';
  document.body.appendChild(f); f.submit();
}

function cancelLinkEdit(linkId){
  var row = document.getElementById('link-row-'+linkId) || document.getElementById('detail-link-'+linkId);
  if(!row) return;
  var oldHTML = row.getAttribute('data-old-html');
  if(oldHTML) row.innerHTML = oldHTML;
}

// ========== 详情弹窗中删除链接 ==========
function deleteDetailLink(linkId){
  if(!confirm('确认删除此链接？')) return;
  var f = document.createElement('form');
  f.method = 'post'; f.style.display = 'none';
  f.innerHTML = '<input type="hidden" name="action" value="delete_link">' +
    '<input type="hidden" name="link_id" value="'+linkId+'">';
  document.body.appendChild(f); f.submit();
}

// ========== 属性编辑模式 ==========
var isEditMode = false;

function toggleEditMode(){
  isEditMode = true;
  document.getElementById('attr-name-view').style.display = 'none';
  document.getElementById('attr-name-edit').style.display = '';
  document.getElementById('attr-orig-view').style.display = 'none';
  document.getElementById('attr-orig-edit').style.display = '';
  document.getElementById('attr-size-view').style.display = 'none';
  document.getElementById('attr-size-edit').style.display = '';
  document.getElementById('attr-type-view').style.display = 'none';
  document.getElementById('attr-type-edit').style.display = '';
  document.getElementById('attr-dim-view').style.display = 'none';
  document.getElementById('attr-dim-edit').style.display = '';
  document.getElementById('editAttrBtn').style.display = 'none';
  document.getElementById('editControls').style.display = 'flex';
}

function cancelEdit(){
  isEditMode = false;
  var data = ALL_IMAGE_DATA[CURRENT_DETAIL_ID];
  var sizeStr = data.file_size ? (data.file_size>1048576 ? (data.file_size/1048576).toFixed(1)+'MB' : (data.file_size/1024).toFixed(1)+'KB') : '-';
  document.getElementById('attr-name-view').innerHTML = '<strong>'+escHtml(data.name)+'</strong>';
  document.getElementById('attr-orig-view').textContent = data.original_name || '-';
  document.getElementById('attr-size-view').textContent = sizeStr;
  document.getElementById('attr-type-view').textContent = data.file_type || '-';
  document.getElementById('attr-dim-view').textContent = data.dimensions || '-';
  document.getElementById('attr-name-view').style.display = '';
  document.getElementById('attr-name-edit').style.display = 'none';
  document.getElementById('attr-orig-view').style.display = '';
  document.getElementById('attr-orig-edit').style.display = 'none';
  document.getElementById('attr-size-view').style.display = '';
  document.getElementById('attr-size-edit').style.display = 'none';
  document.getElementById('attr-type-view').style.display = '';
  document.getElementById('attr-type-edit').style.display = 'none';
  document.getElementById('attr-dim-view').style.display = '';
  document.getElementById('attr-dim-edit').style.display = 'none';
  document.getElementById('editAttrBtn').style.display = '';
  document.getElementById('editControls').style.display = 'none';
}

function saveEdit(){
  var name = document.getElementById('attr-name-edit').value.trim();
  var origName = document.getElementById('attr-orig-edit').value.trim();
  var fileSizeKB = document.getElementById('attr-size-edit').value;
  var fileType = document.getElementById('attr-type-edit').value;
  var dimensions = document.getElementById('attr-dim-edit').value.trim();
  if(!name){ T('名称不能为空','err'); return; }
  submitFormMulti('edit_image', {
    image_id: CURRENT_DETAIL_ID,
    name: name,
    original_name: origName,
    file_size: fileSizeKB,
    file_type: fileType,
    dimensions: dimensions
  });
}

// ========== 重新获取图片信息 ==========
function refetchImage(){
  if(!CURRENT_DETAIL_ID) return;
  T('正在重新获取...','ok');
  fetch('api/refetch.php?image_id='+CURRENT_DETAIL_ID)
    .then(function(r){return r.json()})
    .then(function(d){
      if(d.ok){
        T('信息已更新','ok');
        if(d.file_size !== null) ALL_IMAGE_DATA[CURRENT_DETAIL_ID].file_size = d.file_size;
        if(d.file_type !== null) ALL_IMAGE_DATA[CURRENT_DETAIL_ID].file_type = d.file_type;
        if(isEditMode){
          if(d.file_size !== null){
            document.getElementById('attr-size-edit').value = (d.file_size / 1024).toFixed(1);
          }
          if(d.file_type !== null){
            document.getElementById('attr-type-edit').value = d.file_type;
          }
        } else {
          showDetail(CURRENT_DETAIL_ID);
        }
      } else {
        T('获取失败: '+d.msg,'err');
      }
    })
    .catch(function(){ T('请求失败','err'); });
}

// ========== 批量选择 ==========
function getCheckedIds(){
  var checks = document.querySelectorAll('#imageTable tbody .row-check:checked');
  var ids = [];
  for(var i=0;i<checks.length;i++){
    var tr = checks[i].closest('tr');
    if(tr.style.display !== 'none') ids.push(checks[i].value);
  }
  return ids;
}

function toggleAllRows(cb){
  var checks = document.querySelectorAll('#imageTable tbody .row-check');
  for(var i=0;i<checks.length;i++){
    var tr = checks[i].closest('tr');
    if(tr.style.display !== 'none') checks[i].checked = cb.checked;
  }
  updateBatchBtns();
}

function updateBatchBtns(){
  var ids = getCheckedIds();
  var show = ids.length > 0;
  document.getElementById('batchDeleteBtn').style.display = show ? '' : 'none';
  document.getElementById('batchMoveBtn').style.display = show ? '' : 'none';
  document.getElementById('batchDLLocalBtn').style.display = show ? '' : 'none';
  var allChecks = document.querySelectorAll('#imageTable tbody .row-check');
  var visibleCount = 0, checkedCount = 0;
  for(var i=0;i<allChecks.length;i++){
    if(allChecks[i].closest('tr').style.display !== 'none'){
      visibleCount++;
      if(allChecks[i].checked) checkedCount++;
    }
  }
  document.getElementById('selectAll').checked = visibleCount > 0 && checkedCount === visibleCount;
  document.getElementById('selectAll').indeterminate = checkedCount > 0 && checkedCount < visibleCount;
}

function batchDelete(){
  var ids = getCheckedIds();
  if(ids.length===0){T('请先勾选图片','warn');return;}
  if(!confirm('确认删除选中的 '+ids.length+' 张图片？')) return;
  var f=document.createElement('form');f.method='post';f.style.display='none';
  f.innerHTML='<input type="hidden" name="action" value="batch_delete"><input type="hidden" name="ids" value="'+escHtml(JSON.stringify(ids))+'">';
  document.body.appendChild(f);f.submit();
}

function showBatchMove(){
  var ids = getCheckedIds();
  if(ids.length===0){T('请先勾选图片','warn');return;}
  showModal('batchMoveModal');
}

function doBatchMove(){
  var ids = getCheckedIds();
  var fid = document.getElementById('batchMoveFolder').value;
  var f=document.createElement('form');f.method='post';f.style.display='none';
  f.innerHTML='<input type="hidden" name="action" value="batch_move"><input type="hidden" name="ids" value="'+escHtml(JSON.stringify(ids))+'"><input type="hidden" name="folder_id" value="'+fid+'">';
  document.body.appendChild(f);f.submit();
}

// 批量下载 - 弹窗选择
function batchDownloadLocal(){
  var ids = getCheckedIds();
  if(ids.length===0){T('请先勾选图片','warn');return;}
  document.getElementById('batchDownloadOptCount').textContent = '已选中 '+ids.length+' 张图片';
  showModal('batchDownloadOptModal');
  window._batchIds = ids;
}

// 批量：缓存后下载
function doBatchCached(){
  closeModal('batchDownloadOptModal');
  var ids = window._batchIds || getCheckedIds();
  if(ids.length===0){T('请先勾选图片','warn');return;}
  T('开始缓存下载 '+ids.length+' 张...','ok');
  var count = ids.length, done = 0, failed = 0;
  ids.forEach(function(id){
    var imgData = ALL_IMAGE_DATA[id];
    if(!imgData){ failed++; done++; checkBatchDone(); return; }
    var fd = new FormData();
    fd.append('image_id', id);
    fd.append('folder_name', '默认');
    fetch('api/download.php', {method:'POST', body:fd})
      .then(function(r){return r.json()})
      .then(function(d){
        if(d.ok){
          var a2 = document.createElement('a');
          a2.href = SITE_URL + '/Stock/systemtmp/down/默认/' + d.filename;
          a2.download = (imgData.name||id) + '.' + d.filename.split('.').pop();
          document.body.appendChild(a2);
          a2.click();
          document.body.removeChild(a2);
        }
        done++; checkBatchDone();
      })
      .catch(function(){ done++; failed++; checkBatchDone(); });
  });
  function checkBatchDone(){
    if(done >= count){
      T('下载完成: '+ (count-failed) +'/'+count+' 张'+(failed>0?', '+failed+' 张失败':''), failed>0?'warn':'ok');
    }
  }
}

// 批量：打包自动下载
function doBatchZIP(){
  closeModal('batchDownloadOptModal');
  var ids = window._batchIds || getCheckedIds();
  if(ids.length===0){T('请先勾选图片','warn');return;}
  T('正在打包下载 '+ids.length+' 张图片...','ok');
  var formData = new FormData();
  formData.append('ids', JSON.stringify(ids));
  fetch('api/batch_download_zip.php', {method:'POST', body:formData})
    .then(function(r){return r.json()})
    .then(function(d){
      if(d.ok){
        var a = document.createElement('a');
        a.href = d.url;
        a.download = d.filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        T('已触发下载: '+d.count+' 张'+(d.failed>0?', '+d.failed+' 张失败':''),'ok');
      }else{
        T('打包失败: '+d.error,'err');
      }
    })
    .catch(function(){T('请求失败','err');});
}

// 单文件下载 - 弹窗选择
function downloadToLocal(imageId, name){
  document.getElementById('downloadOptName').textContent = name || imageId;
  window._downloadId = imageId;
  window._downloadName = name;
  showModal('downloadOptModal');
}

// 单文件：缓存后下载
function doDownloadCached(){
  closeModal('downloadOptModal');
  var imageId = window._downloadId, name = window._downloadName;
  T('正在缓存下载: '+name,'ok');
  var formData = new FormData();
  formData.append('image_id', imageId);
  formData.append('folder_name', '默认');
  fetch('api/download.php', {method:'POST', body:formData})
    .then(function(r){return r.json()})
    .then(function(d){
      if(d.ok){
        var a2 = document.createElement('a');
        a2.href = SITE_URL + '/Stock/systemtmp/down/默认/' + d.filename;
        a2.download = name + '.' + d.filename.split('.').pop();
        document.body.appendChild(a2);
        a2.click();
        document.body.removeChild(a2);
        T('已触发下载','ok');
      }else{
        T('服务器缓存失败: '+d.error,'warn');
      }
    })
    .catch(function(){T('请求失败','err');});
}

// 单文件：直接访问
function doDownloadDirect(){
  closeModal('downloadOptModal');
  var imageId = window._downloadId, name = window._downloadName;
  var data = ALL_IMAGE_DATA[imageId];
  if(data && data.links && data.links.length>0){
    var directUrl = null;
    for(var i=0;i<data.links.length;i++){
      if(data.links[i].is_primary && data.links[i].status==='active'){directUrl=data.links[i].url;break;}
    }
    if(!directUrl) directUrl = data.links[0].url;
    window.open(directUrl, '_blank');
    T('已在新标签页打开','ok');
  }else{
    T('无可用链接','warn');
  }
}

// 配合搜索：更新批量按钮状态
var origFilterTable = filterTable;
filterTable = function(){
  origFilterTable();
  updateBatchBtns();
};

// ========== 批量添加 CDN 链接 ==========
function openBatchModal() {
    document.getElementById('batchTextarea').value = '';
    document.getElementById('batchMsg').textContent = '';
    document.getElementById('batchModal').classList.add('show');
}
function closeBatchModal() {
    document.getElementById('batchModal').classList.remove('show');
}
function submitBatchAdd() {
    var input = document.getElementById('batchTextarea').value.trim();
    if (!input) { alert('请输入内容'); return; }

    var lines = input.split('\n').filter(function(l){ return l.trim(); });
    var items = [];
    var errors = [];

    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        var nameMatch = line.match(/^(.+?)\s*\[/);
        if (!nameMatch) {
            errors.push('第' + (i+1) + '行：找不到名称');
            continue;
        }
        var name = nameMatch[1].trim();

        var urlMatches = line.match(/\[([^\]]+)\]/g);
        if (!urlMatches || urlMatches.length === 0) {
            errors.push('第' + (i+1) + '行：缺少 [链接]');
            continue;
        }

        var urls = urlMatches.map(function(m){ return m.slice(1, -1).trim(); });
        var primaryUrl = urls[0];
        var backupUrl = urls.length > 1 ? urls[1] : '';

        if (!/^https?:\/\/.+/.test(primaryUrl)) {
            errors.push('第' + (i+1) + '行：主链接格式无效');
            continue;
        }
        if (backupUrl && !/^https?:\/\/.+/.test(backupUrl)) {
            errors.push('第' + (i+1) + '行：备用链接格式无效');
            continue;
        }
        items.push({name: name, primary_url: primaryUrl, backup_url: backupUrl});
    }

    if (errors.length > 0) {
        alert('格式错误：\n' + errors.join('\n'));
        if (items.length === 0) return;
        if (!confirm('共 ' + items.length + ' 条格式正确，是否继续？（错误行将跳过）')) return;
    }
    if (items.length === 0) { alert('没有有效的条目'); return; }

    var btn = document.getElementById('batchSubmitBtn');
    var msg = document.getElementById('batchMsg');
    btn.disabled = true;
    btn.textContent = '添加中...';
    msg.textContent = '';

    var fd = new FormData();
    fd.append('action', 'batch_add');
    fd.append('items', JSON.stringify(items));

    fetch('', {method:'POST', body:fd})
        .then(function(r){return r.json()})
        .then(function(d){
            btn.disabled = false;
            btn.textContent = '确认添加';
            if (d.success) {
                msg.innerHTML = '<span style="color:#52c41a">成功添加 ' + d.count + ' 条，即将刷新...</span>';
                setTimeout(function(){ location.reload(); }, 1000);
            } else {
                msg.innerHTML = '<span style="color:#ff4d4f">' + (d.message || '失败') + '</span>';
            }
        })
        .catch(function(){
            btn.disabled = false;
            btn.textContent = '确认添加';
            msg.innerHTML = '<span style="color:#ff4d4f">请求失败</span>';
        });
}

// 视频URL管理
var videoLinks = <?= json_encode($videoLinks, JSON_UNESCAPED_UNICODE) ?>;

function renderVideoLinks() {
    var container = document.getElementById('videoLinkList');
    var html = '';
    for (var i = 0; i < videoLinks.length; i++) {
        var vl = videoLinks[i];
        html += '<a href="' + vl.url + '" target="_blank" class="video-link-item" ' +
            'style="display:flex;align-items:center;padding:6px 8px;margin:2px 0;border-radius:4px;color:#333;text-decoration:none;font-size:13px;transition:background 0.2s" ' +
            'onmouseover="this.style.background=\'#f0f5ff\'" onmouseout="this.style.background=\'none\'">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="#1677ff" style="margin-right:6px;flex-shrink:0"><circle cx="12" cy="12" r="10" fill="none" stroke="#1677ff" stroke-width="2"/><polygon points="9,17 17,12 9,7" fill="#1677ff"/></svg>' +
            '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + escapeHtml(vl.name) + '</span>' +
            '<span onclick="deleteVideoLink(event, ' + i + ')" style="color:#ccc;font-size:14px;margin-left:4px;cursor:pointer;visibility:hidden" class="vl-del">&times;</span>' +
            '</a>';
    }
    container.innerHTML = html;
    var items = container.querySelectorAll('.video-link-item');
    for (var j = 0; j < items.length; j++) {
        items[j].addEventListener('mouseenter', function() { this.querySelector('.vl-del').style.visibility = 'visible'; });
        items[j].addEventListener('mouseleave', function() { this.querySelector('.vl-del').style.visibility = 'hidden'; });
    }
}

function openVideoLinkModal() {
    document.getElementById('vlName').value = '';
    document.getElementById('vlUrl').value = '';
    document.getElementById('vlMsg').textContent = '';
    document.getElementById('videoLinkModal').classList.add('show');
}

function closeVideoLinkModal() {
    document.getElementById('videoLinkModal').classList.remove('show');
}

function addVideoLink() {
    var name = document.getElementById('vlName').value.trim();
    var url = document.getElementById('vlUrl').value.trim();
    if (!name) { document.getElementById('vlMsg').textContent = '请输入名称'; return; }
    if (!url) { document.getElementById('vlMsg').textContent = '请输入链接'; return; }
    if (!/^https?:\/\/.+/.test(url)) { document.getElementById('vlMsg').textContent = '链接需以 http:// 或 https:// 开头'; return; }
    videoLinks.push({name: name, url: url});
    closeVideoLinkModal();
    saveVideoLinks();
    renderVideoLinks();
}

function deleteVideoLink(event, index) {
    event.preventDefault();
    event.stopPropagation();
    videoLinks.splice(index, 1);
    saveVideoLinks();
    renderVideoLinks();
}

function saveVideoLinks() {
    var fd = new FormData();
    fd.append('action', 'save_video_links');
    fd.append('links', JSON.stringify(videoLinks));
    fetch('', {method:'POST', body:fd});
}

renderVideoLinks();

// 快速导航链接
var quickLinks = <?= json_encode($quickLinks, JSON_UNESCAPED_UNICODE) ?>;

function renderQuickLinks() {
    var container = document.getElementById('quickLinkList');
    var html = '';
    for (var i = 0; i < quickLinks.length; i++) {
        var ql = quickLinks[i];
        html += '<a href="' + ql.url + '" target="_blank" class="quick-link-item" ' +
            'style="display:flex;align-items:center;padding:6px 8px;margin:2px 0;border-radius:4px;color:#333;text-decoration:none;font-size:13px;transition:background 0.2s" ' +
            'onmouseover="this.style.background=\'#f0f5ff\'" onmouseout="this.style.background=\'none\'">' +
            '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + escapeHtml(ql.name) + '</span>' +
            '<span onclick="deleteQuickLink(event, ' + i + ')" style="color:#ccc;font-size:14px;margin-left:4px;cursor:pointer;visibility:hidden" class="ql-del">&times;</span>' +
            '</a>';
    }
    container.innerHTML = html;
    var items = container.querySelectorAll('.quick-link-item');
    for (var j = 0; j < items.length; j++) {
        items[j].addEventListener('mouseenter', function() {
            this.querySelector('.ql-del').style.visibility = 'visible';
        });
        items[j].addEventListener('mouseleave', function() {
            this.querySelector('.ql-del').style.visibility = 'hidden';
        });
    }
}

function openQuickLinkModal() {
    document.getElementById('qlName').value = '';
    document.getElementById('qlUrl').value = '';
    document.getElementById('qlMsg').textContent = '';
    document.getElementById('quickLinkModal').classList.add('show');
}

function closeQuickLinkModal() {
    document.getElementById('quickLinkModal').classList.remove('show');
}

function addQuickLink() {
    var name = document.getElementById('qlName').value.trim();
    var url = document.getElementById('qlUrl').value.trim();
    if (!name) { document.getElementById('qlMsg').textContent = '请输入名称'; return; }
    if (!url) { document.getElementById('qlMsg').textContent = '请输入网址'; return; }
    if (!/^https?:\/\/.+/.test(url)) { document.getElementById('qlMsg').textContent = '网址需以 http:// 或 https:// 开头'; return; }
    if (quickLinks.length >= 5) { document.getElementById('qlMsg').textContent = '最多添加 5 个链接'; return; }
    quickLinks.push({name: name, url: url});
    closeQuickLinkModal();
    saveQuickLinks();
    renderQuickLinks();
}

function deleteQuickLink(event, index) {
    event.preventDefault();
    event.stopPropagation();
    quickLinks.splice(index, 1);
    saveQuickLinks();
    renderQuickLinks();
}

function saveQuickLinks() {
    var fd = new FormData();
    fd.append('action', 'save_quick_links');
    fd.append('links', JSON.stringify(quickLinks));
    fetch('', {method:'POST', body:fd});
}

function escapeHtml(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

renderQuickLinks();

// 点击遮罩关闭弹窗
document.addEventListener('click', function(e) {
    if (e.target.id === 'batchModal') closeBatchModal();
    if (e.target.id === 'quickLinkModal') closeQuickLinkModal();
    if (e.target.id === 'videoLinkModal') closeVideoLinkModal();
});
</script>

<?php if ($msgText): ?>
<script>T(<?= json_encode($msgText) ?>,<?= json_encode($msgType) ?>)</script>
<?php endif; ?>
<?php if ($showFooter && !empty($footerCfg['content'])): ?>
<div class="site-footer"><?= $footerCfg['content'] ?></div>
<?php endif; ?>

<div id="aboutModal" class="modal-o about-modal" onclick="if(event.target===this)closeModal('aboutModal')">
  <div class="modal">
    <div class="modal-header">
      <span>关于 <?= SYS_NAME ?></span>
      <button class="modal-close" onclick="closeModal('aboutModal')">&times;</button>
    </div>
    <div class="about-body">
      <h2><?= SYS_NAME ?></h2>
      <div class="ver">版本 <?= SYS_VERSION ?></div>
      <div class="desc"><?= SYS_NAME ?> 是一款轻量级的图链管理系统，专注于图片资源的外链生成与管理。通过简洁直观的操作界面，帮助用户快速上传图片、生成直链、组织分类，适用于个人博客、小型站点、图文内容创作等场景。</div>
      <div class="feature-list">
        <div class="feature-item"><span class="fi-icon">📁</span> 多文件夹分类管理</div>
        <div class="feature-item"><span class="fi-icon">🔗</span> 一键生成外链直链</div>
        <div class="feature-item"><span class="fi-icon">🖼️</span> 缩略图预览与缓存</div>
        <div class="feature-item"><span class="fi-icon">📊</span> 存储空间统计监控</div>
        <div class="feature-item"><span class="fi-icon">🔍</span> 批量检测链接有效性</div>
        <div class="feature-item"><span class="fi-icon">⚡</span> 快速访问直链/FTP</div>
        <div class="feature-item"><span class="fi-icon">🎨</span> 登录页主题自定义</div>
        <div class="feature-item"><span class="fi-icon">⬇️</span> 远程图片批量下载</div>
      </div>
      <div class="footer-note"><strong>开源计划：</strong>本项目后续将开源至 GitHub，支持社区贡献与二次开发。敬请关注更新，届时将提供详细的部署文档与开发者指南。</div>
    </div>
  </div>
</div>
<!-- 批量添加 CDN 链接弹窗 -->
<div class="modal-o" id="batchModal">
  <div class="modal" style="max-width:600px">
    <h3>批量添加链接</h3>
    <div style="padding:16px">
      <div style="font-size:12px;color:#999;margin-bottom:8px">
        格式：名称 [主链接] [备用链接]（每行一个，备用链接可选）
      </div>
      <textarea id="batchTextarea" rows="8" placeholder="示例：
WPS办公软件 [https://vip.123pan.cn/xxx/wps.zip] [https://ycoemxt.cn/xxx/wps.exe]
Steam客户端 [https://vip.123pan.cn/xxx/steam.exe]" 
      style="width:100%;padding:8px;border:1px solid #d9d9d9;border-radius:4px;font-family:Consolas,monospace;font-size:13px;resize:vertical;box-sizing:border-box"></textarea>
      <div id="batchMsg" style="margin-top:8px;font-size:12px;min-height:18px"></div>
      <div style="margin-top:14px;text-align:right">
        <button class="btn btn-d btn-xs" onclick="closeBatchModal()">取消</button>
        <button class="btn btn-p btn-xs" id="batchSubmitBtn" onclick="submitBatchAdd()" style="margin-left:8px">确认添加</button>
      </div>
    </div>
  </div>
</div>

<!-- 视频链接弹窗 -->
<div class="modal-o" id="videoLinkModal">
  <div class="modal" style="max-width:420px">
    <h3>添加视频链接</h3>
    <div style="padding:16px">
      <div style="margin-bottom:12px">
        <label style="display:block;font-size:12px;color:#666;margin-bottom:4px">名称</label>
        <input type="text" id="vlName" placeholder="如：演示视频" style="width:100%;padding:8px;border:1px solid #d9d9d9;border-radius:4px;box-sizing:border-box">
      </div>
      <div style="margin-bottom:12px">
        <label style="display:block;font-size:12px;color:#666;margin-bottom:4px">视频链接</label>
        <input type="text" id="vlUrl" placeholder="https://..." style="width:100%;padding:8px;border:1px solid #d9d9d9;border-radius:4px;box-sizing:border-box">
      </div>
      <div id="vlMsg" style="font-size:12px;color:#ff4d4f;min-height:18px;margin-bottom:8px"></div>
      <div style="text-align:right">
        <button class="btn btn-d btn-xs" onclick="closeVideoLinkModal()">取消</button>
        <button class="btn btn-p btn-xs" onclick="addVideoLink()" style="margin-left:8px">保存</button>
      </div>
    </div>
  </div>
</div>

<!-- 快速链接弹窗 -->
<div class="modal-o" id="quickLinkModal">
  <div class="modal" style="max-width:420px">
    <h3>添加快捷链接</h3>
    <div style="padding:16px">
      <div style="margin-bottom:12px">
        <label style="display:block;font-size:12px;color:#666;margin-bottom:4px">名称</label>
        <input type="text" id="qlName" placeholder="如：百度" style="width:100%;padding:8px;border:1px solid #d9d9d9;border-radius:4px;box-sizing:border-box">
      </div>
      <div style="margin-bottom:12px">
        <label style="display:block;font-size:12px;color:#666;margin-bottom:4px">网址</label>
        <input type="text" id="qlUrl" placeholder="https://www.baidu.com" style="width:100%;padding:8px;border:1px solid #d9d9d9;border-radius:4px;box-sizing:border-box">
      </div>
      <div id="qlMsg" style="font-size:12px;color:#ff4d4f;min-height:18px;margin-bottom:8px"></div>
      <div style="text-align:right">
        <button class="btn btn-d btn-xs" onclick="closeQuickLinkModal()">取消</button>
        <button class="btn btn-p btn-xs" onclick="addQuickLink()" style="margin-left:8px">保存</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>

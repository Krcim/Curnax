<?php
// d.php - CDN 统一链接跳转器
// 格式: https://imgapi.hiyxin.top/CDN/d/{slug}
// 行为: 302 跳转到对应的分发链接

header('X-Robots-Tag: noindex');

// 1. 提取 slug（兼容 GET 参数和 URL 路径两种方式）
$slug = '';
if (!empty($_GET['slug'])) {
    $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['slug']);
} else {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $uri = parse_url($uri, PHP_URL_PATH);
    $parts = explode('/', trim($uri, '/'));
    $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', end($parts));
}

if (empty($slug)) {
    http_response_code(404);
    exit('Not Found');
}

// 2. 加载 CDN 条目数据
$itemsFile = __DIR__ . '/data/cdn_images.json';
if (!file_exists($itemsFile)) {
    http_response_code(500);
    exit('Service Error');
}
$items = json_decode(file_get_contents($itemsFile), true) ?: [];

// 3. 匹配 unified_slug
$matchedItem = null;
foreach ($items as $item) {
    if (($item['unified_slug'] ?? '') === $slug) {
        $matchedItem = $item;
        break;
    }
}
if (!$matchedItem) {
    http_response_code(404);
    exit('Link Not Found');
}

// 4. 加载分发链接数据，找到该条目的激活链接
$linksFile = __DIR__ . '/data/cdn_links.json';
$links = file_exists($linksFile) ? (json_decode(file_get_contents($linksFile), true) ?: []) : [];

// 筛选该条目的链接，过滤状态为 invalid 的
$itemLinks = [];
foreach ($links as $link) {
    if (($link['image_id'] ?? '') === ($matchedItem['id'] ?? '') && ($link['status'] ?? '') !== 'invalid') {
        $itemLinks[] = $link;
    }
}

// 5. 优先级: is_primary > 第一个 active > 第一个
$redirectUrl = null;
foreach ($itemLinks as $link) {
    if (!empty($link['is_primary'])) {
        $redirectUrl = $link['url'] ?? '';
        break;
    }
}
if (!$redirectUrl) {
    foreach ($itemLinks as $link) {
        if (!empty($link['url'])) {
            $redirectUrl = $link['url'];
            break;
        }
    }
}
if (!$redirectUrl) {
    foreach ($links as $link) {
        if (($link['image_id'] ?? '') === ($matchedItem['id'] ?? '') && !empty($link['url'])) {
            $redirectUrl = $link['url'];
            break;
        }
    }
}

if (empty($redirectUrl)) {
    http_response_code(404);
    exit('No Available Link');
}

// 6. 302 跳转
header('Location: ' . $redirectUrl, true, 302);
exit;
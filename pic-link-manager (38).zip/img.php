<?php
/**
 * 统一链接入口 — 302 跳转到当前主链
 * 请求: imgapi.hiyxin.top/i/pmF6Mff.png  →  302 → CDN 真身
 *        imgapi.hiyxin.top/f/分类名/pmF6Mff.png
 * 流量走 CDN，服务器只处理几十字节的 302 响应
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/Storage.php';

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// ── 解析 URL ──
$folderId = null;

// /i/name.ext
if (preg_match('#^/i/([^/]+)\.([a-zA-Z0-9]+)$#', $uri, $m)) {
    $name = urldecode($m[1]);
    $ext  = $m[2];
}
// /f/slug/name.ext
elseif (preg_match('#^/f/([^/]+)/([^/]+)\.([a-zA-Z0-9]+)$#', $uri, $m)) {
    $slug = urldecode($m[1]);
    $name = urldecode($m[2]);
    $ext  = $m[3];
    $folders = new Storage(FILE_FOLDERS);
    $folder  = $folders->findWhere(['name' => $slug]);
    $folderId = $folder ? $folder['id'] : null;
} else {
    http_response_code(404);
    header('Content-Type: text/plain');
    exit('Not Found');
}

// ── 查找图片 ──
$images   = new Storage(FILE_IMAGES);
$allImgs  = $images->all();
$image    = null;
foreach ($allImgs as $img) {
    $imgExt = '';
    if ($img['file_type']) { $parts = explode('/', $img['file_type']); $imgExt = strtolower(end($parts)); }
    if (
        ($img['name'] ?? '') === $name &&
        $imgExt === strtolower($ext)
    ) {
        if ($folderId === null || ($img['folder_id'] ?? null) === $folderId) {
            $image = $img;
            break;
        }
    }
}
if (!$image) { http_response_code(404); header('Content-Type: text/plain'); exit('Image Not Found'); }

// ── 取主链 ──
$links    = new Storage(FILE_LINKS);
$imgLinks = $links->where(['image_id' => $image['id']]);

$redirectUrl = '';

// 优先级: 主链 active > 备用 active > 主链(任意) > 第一条
foreach ($imgLinks as $lk) {
    if ($lk['is_primary'] && $lk['status'] === 'active') { $redirectUrl = $lk['url']; break; }
}
if (!$redirectUrl) {
    foreach ($imgLinks as $lk) {
        if (!$lk['is_primary'] && $lk['status'] === 'active') { $redirectUrl = $lk['url']; break; }
    }
}
if (!$redirectUrl) {
    foreach ($imgLinks as $lk) {
        if ($lk['is_primary']) { $redirectUrl = $lk['url']; break; }
    }
}
if (!$redirectUrl && !empty($imgLinks)) {
    $redirectUrl = $imgLinks[0]['url'];
}

if (!$redirectUrl) { http_response_code(404); header('Content-Type: text/plain'); exit('No Active Link'); }

// ── 302 跳转 ──
header('Location: ' . $redirectUrl, true, 302);
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Robots-Tag: noindex');
exit;
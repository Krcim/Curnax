<?php
/**
 * 登录 / 注册 页面
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/Storage.php';
require_once __DIR__ . '/includes/Auth.php';

// 已安装检查
if (!file_exists(FILE_SETTINGS)) {
    header('Location: install.php');
    exit;
}

$auth = new Auth();

// 已登录直接跳转
if ($auth->check()) {
    header('Location: dashboard.php');
    exit;
}

$mode = $_GET['mode'] ?? 'login'; // login | register
$error = '';

// 读取主题配置
define('THEME_CONFIG', DATA_PATH . '/theme_config.json');
$themeCfg = file_exists(THEME_CONFIG) ? (json_decode(file_get_contents(THEME_CONFIG), true) ?: []) : [];
$bgStyle = $themeCfg['bg_style'] ?? 'default';

// 读取页脚配置
define('FOOTER_CONFIG_INDEX', DATA_PATH . '/footer_config.json');
$footerCfg = file_exists(FOOTER_CONFIG_INDEX) ? (json_decode(file_get_contents(FOOTER_CONFIG_INDEX), true) ?: []) : [];
$showFooter = in_array('login', $footerCfg['show_on'] ?? []) || in_array('all', $footerCfg['show_on'] ?? []);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['action'] ?? '') === 'register') {
        $result = $auth->register($_POST['username'] ?? '', $_POST['password'] ?? '', $_POST['email'] ?? '');
        if ($result['ok']) {
            $auth->login($_POST['username'], $_POST['password']);
            header('Location: dashboard.php');
            exit;
        } else {
            $error = $result['msg'];
            $mode = 'register';
        }
    } else {
        $result = $auth->login($_POST['username'] ?? '', $_POST['password'] ?? '');
        if ($result['ok']) {
            header('Location: dashboard.php');
            exit;
        } else {
            $error = $result['msg'];
        }
    }
}

// 生成背景样式
$bgStyleCSS = '';
$bgClass = '';

if ($bgStyle === 'purple_gradient') {
    $bgClass = 'bg-purple-gradient';
} elseif ($bgStyle === 'image') {
    $imageMode = $themeCfg['image_mode'] ?? 'upload';
    $bgImageUrl = '';
    if ($imageMode === 'upload' && !empty($themeCfg['bg_image_path'])) {
        $bgImageUrl = SITE_URL . '/' . $themeCfg['bg_image_path'] . '?v=' . time();
    } elseif ($imageMode === 'url') {
        if (!empty($themeCfg['bg_image_url_path']) && file_exists(BASE_PATH . '/' . $themeCfg['bg_image_url_path'])) {
            $bgImageUrl = SITE_URL . '/' . $themeCfg['bg_image_url_path'] . '?v=' . time();
        } elseif (!empty($themeCfg['bg_image_url'])) {
            $bgImageUrl = $themeCfg['bg_image_url'];
        }
    }
    if ($bgImageUrl) {
        $bgStyleCSS = 'background: url(' . $bgImageUrl . ') center/cover no-repeat fixed;';
        $bgClass = 'bg-image';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $mode === 'login' ? '登录' : '注册' ?> - <?= SYS_NAME ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:#f0f2f5;min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column}

/* 紫渐玻璃动态风格 */
.bg-purple-gradient{background:linear-gradient(-45deg,#6b21a8,#3b82f6,#a855f7,#6366f1,#8b5cf6);background-size:400% 400%;animation:gradientShift 15s ease infinite}
@keyframes gradientShift{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
.bg-purple-gradient .login-box{background:rgba(255,255,255,.12);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.25);border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,.15),inset 0 1px 0 rgba(255,255,255,.1)}
.bg-purple-gradient .login-box h1,.bg-purple-gradient .login-box .sub{color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.3)}
.bg-purple-gradient .login-box label{color:rgba(255,255,255,.85)}
.bg-purple-gradient .login-box input{background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);color:#fff}
.bg-purple-gradient .login-box input::placeholder{color:rgba(255,255,255,.5)}
.bg-purple-gradient .login-box input:focus{background:rgba(255,255,255,.2);border-color:rgba(255,255,255,.5)}
.bg-purple-gradient .login-box .btn{background:rgba(255,255,255,.25);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.3);color:#fff}
.bg-purple-gradient .login-box .btn:hover{background:rgba(255,255,255,.35)}
.bg-purple-gradient .login-box .switch{color:rgba(255,255,255,.7)}
.bg-purple-gradient .login-box .switch a{color:#c4b5fd}
.bg-purple-gradient .login-box .error{background:rgba(255,77,79,.2);border-color:rgba(255,77,79,.3);color:#ffccc7}

/* 图片背景 */
.bg-image{<?= $bgStyleCSS ?>}
.bg-image .login-box{background:rgba(255,255,255,.92);border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.15)}

.login-box{background:#fff;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.08);padding:40px;width:400px;max-width:90%;transition:all .3s}
h1{font-size:24px;color:#1a1a1a;margin-bottom:4px;text-align:center}
.sub{color:#999;font-size:14px;margin-bottom:24px;text-align:center}
.form-group{margin-bottom:16px}
label{display:block;font-size:14px;color:#333;margin-bottom:6px}
input[type=text],input[type=password],input[type=email]{width:100%;padding:10px 12px;border:1px solid #d9d9d9;border-radius:6px;font-size:14px;transition:all .2s}
input:focus{outline:none;border-color:#1677ff;box-shadow:0 0 0 2px rgba(22,119,255,.1)}
.btn{display:block;width:100%;padding:10px;background:#1677ff;color:#fff;border:none;border-radius:6px;font-size:15px;cursor:pointer;transition:background .2s}
.btn:hover{background:#4096ff}
.error{background:#fff2f0;border:1px solid #ffccc7;color:#ff4d4f;padding:10px;border-radius:6px;margin-bottom:16px;font-size:14px}
.switch{text-align:center;margin-top:16px;font-size:14px;color:#666}
.switch a{color:#1677ff;text-decoration:none}
.switch a:hover{text-decoration:underline}

/* 页脚 */
.site-footer{position:fixed;bottom:0;left:0;right:0;text-align:center;padding:12px 20px;font-size:12px;color:#999;z-index:1}
.bg-purple-gradient .site-footer{color:rgba(255,255,255,.5)}
.site-footer a{color:inherit;text-decoration:underline}
</style>
</head>
<body class="<?= $bgClass ?>">
<div class="login-box">
<h1><?= SYS_NAME ?></h1>
<p class="sub"><?= $mode === 'login' ? '登录您的账号' : '创建新账号' ?></p>

<?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<form method="post">
  <input type="hidden" name="action" value="<?= $mode === 'register' ? 'register' : 'login' ?>">
  <div class="form-group">
    <label>用户名</label>
    <input type="text" name="username" required minlength="3" autocomplete="username">
  </div>
  <div class="form-group">
    <label>密码</label>
    <input type="password" name="password" required minlength="6" autocomplete="<?= $mode === 'login' ? 'current-password' : 'new-password' ?>">
  </div>
  <?php if ($mode === 'register'): ?>
  <div class="form-group">
    <label>邮箱（选填）</label>
    <input type="email" name="email">
  </div>
  <?php endif; ?>
  <button type="submit" class="btn"><?= $mode === 'login' ? '登录' : '注册' ?></button>
</form>

<p class="switch">
<?php if ($mode === 'login'): ?>
  没有账号？<a href="?mode=register">立即注册</a>
<?php else: ?>
  已有账号？<a href="?mode=login">立即登录</a>
<?php endif; ?>
</p>
</div>

<?php if ($showFooter && !empty($footerCfg['content'])): ?>
<div class="site-footer"><?= $footerCfg['content'] ?></div>
<?php endif; ?>
</body>
</html>

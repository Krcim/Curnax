<?php
/**
 * 图片下载 API
 * POST: image_id, folder_name, custom_name(可选)
 * 从主链接下载图片到 Stock/systemtmp/down/{folder_name}/
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Storage.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'未登录']); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['ok'=>false,'error'=>'仅支持POST']); exit;
}

$imageId = $_POST['image_id'] ?? '';
$folderName = trim($_POST['folder_name'] ?? '默认');
$customName = trim($_POST['custom_name'] ?? '');

if (!$imageId) { echo json_encode(['ok'=>false,'error'=>'缺少 image_id']); exit; }

// 安全过滤文件夹名
$folderName = preg_replace('/[^a-zA-Z0-9_\x{4e00}-\x{9fa5}-]/u', '_', $folderName);
if ($folderName === '') $folderName = '默认';

$images = new Storage(FILE_IMAGES);
$links = new Storage(FILE_LINKS);

$image = $images->find($imageId);
if (!$image) { echo json_encode(['ok'=>false,'error'=>'图片记录不存在']); exit; }

// 查找最佳链接
$imgLinks = $links->where(['image_id' => $imageId]);
$bestLink = null;
foreach ($imgLinks as $lk) {
    if ($lk['is_primary'] && $lk['status'] === 'active') { $bestLink = $lk; break; }
}
if (!$bestLink) {
    foreach ($imgLinks as $lk) {
        if ($lk['status'] === 'active') { $bestLink = $lk; break; }
    }
}
if (!$bestLink && !empty($imgLinks)) {
    // 无 active 链接时尝试第一个 (可能是 backup)
    $bestLink = $imgLinks[0];
}
if (!$bestLink) { echo json_encode(['ok'=>false,'error'=>'无可用链接']); exit; }

// 确定文件名
$urlPath = parse_url($bestLink['url'], PHP_URL_PATH);
$ext = $urlPath ? strtolower(pathinfo($urlPath, PATHINFO_EXTENSION)) : '';
$validExts = ['jpg','jpeg','png','gif','webp','bmp','svg','avif','ico','tiff'];
if (!in_array($ext, $validExts)) $ext = 'jpg';

if ($customName) {
    $filename = $customName . '.' . $ext;
} else {
    $filename = $imageId . '.' . $ext;
}

// 确保目录存在
$downDir = DOWNLOAD_PATH . '/down/' . $folderName;
if (!is_dir($downDir)) mkdir($downDir, 0755, true);

$savePath = $downDir . '/' . $filename;

// 尝试从主链接下载，失败则试备用链接
$success = false;
$linksToTry = [];
$linksToTry[] = $bestLink;
foreach ($imgLinks as $lk) {
    if ($lk['id'] !== $bestLink['id']) $linksToTry[] = $lk;
}

$lastError = '';
foreach ($linksToTry as $tryLink) {
    $ch = curl_init($tryLink['url']);
    $fp = fopen($savePath, 'wb');
    if (!$fp) { $lastError = '无法创建文件'; continue; }

    curl_setopt_array($ch, [
        CURLOPT_FILE => $fp,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_FAILONERROR => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    ]);
    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    fclose($fp);

    if ($httpCode >= 200 && $httpCode < 400 && !$curlError) {
        $success = true;
        break;
    } else {
        $lastError = $curlError ?: "HTTP $httpCode";
        @unlink($savePath);
    }
}

if (!$success) {
    echo json_encode(['ok'=>false,'error'=>'下载失败: ' . $lastError]); exit;
}

// 获取文件大小
$fileSize = filesize($savePath);

echo json_encode([
    'ok' => true,
    'path' => $savePath,
    'filename' => $filename,
    'folder' => $folderName,
    'size' => $fileSize,
    'url' => $bestLink['url'],
], JSON_UNESCAPED_UNICODE);

<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Storage.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'未登录']); exit; }

$imageId = $_GET['image_id'] ?? '';
if (!$imageId) { echo json_encode(['ok'=>false,'error'=>'缺少参数']); exit; }

$links = new Storage(FILE_LINKS);
$all = $links->where(['image_id' => $imageId]);

$primaryValid = null; $anyValid = null; $fallback = null;
foreach ($all as $lk) {
    if ($lk['is_primary'] && $lk['status'] === 'active') { $primaryValid = $lk; break; }
    if (!$anyValid && $lk['status'] === 'active') $anyValid = $lk;
    if (!$fallback) $fallback = $lk;
}
$best = $primaryValid ?? $anyValid ?? $fallback;
echo json_encode($best ? ['ok'=>true,'url'=>$best['url'],'label'=>$best['label']] : ['ok'=>false,'error'=>'无链接']);

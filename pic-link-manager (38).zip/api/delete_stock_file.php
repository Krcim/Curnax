<?php
/**
 * 文件管理 - 删除 Stock/ 下文件
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'未登录']); exit; }

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
$relPath = $data['path'] ?? '';
$relPath = base64_decode($relPath);

if (!$relPath) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'无效路径']); exit; }

$fullPath = realpath(BASE_PATH . '/' . $relPath);
if (!$fullPath || strpos($fullPath, realpath(STOCK_PATH)) !== 0) {
    http_response_code(403); echo json_encode(['ok'=>false,'error'=>'越权路径']); exit;
}
if (!file_exists($fullPath)) {
    http_response_code(404); echo json_encode(['ok'=>false,'error'=>'文件不存在']); exit;
}

if (is_dir($fullPath)) {
    // 递归删除目录
    $it = new RecursiveDirectoryIterator($fullPath, RecursiveDirectoryIterator::SKIP_DOTS);
    $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($files as $f) {
        if ($f->isDir()) rmdir($f->getRealPath());
        else unlink($f->getRealPath());
    }
    rmdir($fullPath);
} else {
    unlink($fullPath);
}

echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
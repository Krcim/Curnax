<?php
/**
 * 批量下载 ZIP API
 * POST: ids (JSON数组)
 * 下载所有图片到临时目录，打包 ZIP，返回 ZIP 地址
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Storage.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'未登录']); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['ok'=>false,'error'=>'仅支持POST']); exit;
}

$ids = json_decode($_POST['ids'] ?? '[]', true);
if (empty($ids)) { echo json_encode(['ok'=>false,'error'=>'未指定图片']); exit; }

$images = new Storage(FILE_IMAGES);
$links = new Storage(FILE_LINKS);

$tempDir = TEMP_PATH . '/batch_zip_' . uniqid();
if (!mkdir($tempDir, 0755, true)) {
    echo json_encode(['ok'=>false,'error'=>'无法创建临时目录']); exit;
}

$downloaded = [];
$failed = 0;

foreach ($ids as $id) {
    $img = $images->find($id);
    if (!$img) { $failed++; continue; }

    $imgLinks = $links->where(['image_id' => $id]);
    $bestUrl = null;

    foreach ($imgLinks as $lk) {
        if ($lk['is_primary'] && $lk['status'] === 'active') { $bestUrl = $lk['url']; break; }
    }
    if (!$bestUrl) {
        foreach ($imgLinks as $lk) {
            if ($lk['status'] === 'active') { $bestUrl = $lk['url']; break; }
        }
    }
    if (!$bestUrl && !empty($imgLinks)) $bestUrl = $imgLinks[0]['url'];
    if (!$bestUrl) { $failed++; continue; }

    $urlPath = parse_url($bestUrl, PHP_URL_PATH);
    $ext = $urlPath ? strtolower(pathinfo($urlPath, PATHINFO_EXTENSION)) : '';
    $validExts = ['jpg','jpeg','png','gif','webp','bmp','svg','avif','ico','tiff'];
    if (!in_array($ext, $validExts)) $ext = 'jpg';

    $safeName = preg_replace('/[^a-zA-Z0-9_\x{4e00}-\x{9fa5}-]/u', '_', $img['name'] ?: 'image');
    $filename = $safeName . '.' . $ext;
    $filepath = $tempDir . '/' . $filename;

    // 去重：同名文件加序号
    $counter = 1;
    while (file_exists($filepath)) {
        $filename = $safeName . '_' . $counter . '.' . $ext;
        $filepath = $tempDir . '/' . $filename;
        $counter++;
    }

    $ch = curl_init($bestUrl);
    $fp = fopen($filepath, 'wb');
    if (!$fp) { $failed++; curl_close($ch); continue; }

    curl_setopt_array($ch, [
        CURLOPT_FILE => $fp,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_FAILONERROR => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    ]);
    curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fp);

    if ($httpCode >= 200 && $httpCode < 400 && filesize($filepath) > 0) {
        $downloaded[] = $filename;
    } else {
        @unlink($filepath);
        $failed++;
    }
}

if (empty($downloaded)) {
    array_map('unlink', glob($tempDir . '/*') ?: []);
    rmdir($tempDir);
    echo json_encode(['ok'=>false,'error'=>'所有图片下载失败']); exit;
}

// 创建 ZIP（存入 Stock/temp 缓存目录）
$zipName = 'batch_download_' . date('Ymd_His') . '.zip';
$zipPath = TEMP_PATH . '/' . $zipName;

$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
    array_map('unlink', glob($tempDir . '/*') ?: []);
    rmdir($tempDir);
    echo json_encode(['ok'=>false,'error'=>'无法创建 ZIP 文件']); exit;
}

$files = array_diff(scandir($tempDir), ['.', '..']);
foreach ($files as $f) {
    $zip->addFile($tempDir . '/' . $f, $f);
}
$zip->close();

// 清理临时目录
foreach ($files as $f) @unlink($tempDir . '/' . $f);
rmdir($tempDir);

$zipUrl = SITE_URL . '/Stock/temp/' . $zipName;

echo json_encode([
    'ok' => true,
    'url' => $zipUrl,
    'path' => $zipPath,
    'filename' => $zipName,
    'count' => count($downloaded),
    'failed' => $failed,
], JSON_UNESCAPED_UNICODE);

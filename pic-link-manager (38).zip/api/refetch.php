<?php
/**
 * 重新获取图片信息 API
 * 根据图片的主链接 URL 发送 HEAD 请求获取 Content-Length 和 Content-Type，
 * 更新 images.json 并返回结果。
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Storage.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
$auth->requireLogin();

$imageId = $_GET['image_id'] ?? '';
if (!$imageId) {
    http_response_code(400);
    die(json_encode(['ok' => false, 'msg' => '缺少 image_id'], JSON_UNESCAPED_UNICODE));
}

$images = new Storage(FILE_IMAGES);
$links  = new Storage(FILE_LINKS);

$img = $images->find($imageId);
if (!$img) {
    http_response_code(404);
    die(json_encode(['ok' => false, 'msg' => '图片不存在'], JSON_UNESCAPED_UNICODE));
}

// 找到主链接
$imgLinks = $links->where(['image_id' => $imageId]);
$primaryUrl = null;
foreach ($imgLinks as $lk) {
    if ($lk['is_primary']) {
        $primaryUrl = $lk['url'];
        break;
    }
}
if (!$primaryUrl && !empty($imgLinks)) {
    $primaryUrl = $imgLinks[0]['url'];
}

if (!$primaryUrl) {
    die(json_encode(['ok' => false, 'msg' => '没有可用链接'], JSON_UNESCAPED_UNICODE));
}

// HEAD 请求获取信息
$ch = curl_init($primaryUrl);
curl_setopt_array($ch, [
    CURLOPT_NOBODY         => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => CHECK_TIMEOUT,
    CURLOPT_FOLLOWLOCATION => true,
]);
curl_exec($ch);
$contentLength = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
$contentType   = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
$httpCode      = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$fileSize = ($contentLength > 0) ? intval($contentLength) : null;
$fileType = $contentType ?: null;

// 更新 images.json
$updates = [];
if ($fileSize !== null) {
    $updates['file_size'] = $fileSize;
}
if ($fileType !== null) {
    $updates['file_type'] = $fileType;
}
if (!empty($updates)) {
    $images->update($imageId, $updates);
}

header('Content-Type: application/json; charset=utf-8');
die(json_encode([
    'ok'           => true,
    'file_size'    => $fileSize,
    'file_type'    => $fileType,
    'file_size_kb' => $fileSize !== null ? round($fileSize / 1024, 1) : null,
    'http_code'    => $httpCode,
], JSON_UNESCAPED_UNICODE));
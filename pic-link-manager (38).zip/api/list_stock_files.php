<?php
/**
 * 文件管理 - 列出 Stock/ 目录树
 */
ob_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { ob_end_clean(); http_response_code(403); echo json_encode(['ok'=>false,'error'=>'未登录']); exit; }

function scanDirTree($dir, $basePath) {
    $result = [];
    set_error_handler(function(){ return true; });
    $items = @scandir($dir);
    restore_error_handler();
    if (!$items) return $result;

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        $fullPath = $dir . '/' . $item;
        $relPath = str_replace('\\', '/', substr($fullPath, strlen($basePath) + 1));
        set_error_handler(function(){ return true; });
        $isDir = is_dir($fullPath);
        $size = $isDir ? 0 : filesize($fullPath);
        restore_error_handler();

        $result[] = [
            'name' => $item,
            'path_enc' => base64_encode($relPath),
            'is_dir' => $isDir,
            'size' => $size,
            'ext' => $isDir ? '' : strtolower(pathinfo($item, PATHINFO_EXTENSION)),
        ];
    }
    return $result;
}

try {
    $files = scanDirTree(STOCK_PATH, BASE_PATH);
    ob_end_clean();
    echo json_encode(['ok' => true, 'files' => $files], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    ob_end_clean();
    echo json_encode(['ok' => false, 'error' => '目录读取失败：' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
}
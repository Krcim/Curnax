<?php
/**
 * 文件管理 - 获取 Stock/ 下文件（下载用）
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'未登录']); exit; }

$f = $_GET['f'] ?? '';
$relPath = base64_decode(urldecode($f));
if (!$relPath) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'无效路径']); exit; }

$fullPath = realpath(BASE_PATH . '/' . $relPath);
if (!$fullPath || strpos($fullPath, realpath(STOCK_PATH)) !== 0) {
    http_response_code(403); echo json_encode(['ok'=>false,'error'=>'越权路径']); exit;
}
if (!file_exists($fullPath) || is_dir($fullPath)) {
    http_response_code(404); echo json_encode(['ok'=>false,'error'=>'文件不存在']); exit;
}

$name = basename($fullPath);
$ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
$mimeMap = [
    'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
    'gif' => 'image/gif', 'webp' => 'image/webp', 'bmp' => 'image/bmp',
    'pdf' => 'application/pdf', 'zip' => 'application/zip',
    'txt' => 'text/plain', 'json' => 'application/json',
    'mp4' => 'video/mp4', 'mp3' => 'audio/mpeg',
];
$mime = $mimeMap[$ext] ?? 'application/octet-stream';

header('Content-Type: ' . $mime);
header('Content-Disposition: attachment; filename="' . rawurlencode($name) . '"');
header('Content-Length: ' . filesize($fullPath));
readfile($fullPath);
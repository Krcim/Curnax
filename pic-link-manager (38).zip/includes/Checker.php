<?php
/**
 * 链接失效检测器
 */
class Checker {
    private Storage $links;
    private Storage $images;
    private ImageBed $bed;

    public function __construct() {
        $this->links = new Storage(FILE_LINKS);
        $this->images = new Storage(FILE_IMAGES);
        $this->bed = new ImageBed();
    }

    /** 检测单条链接 */
    public function checkOne(array $link): array {
        $bed = $this->bed->get($link['bed_id']);
        $adapter = $bed ? $this->bed->createAdapter($bed) : null;
        if (!$adapter) {
            $isValid = $this->httpCheck($link['url']);
        } else {
            $isValid = $adapter->check($link['url']);
        }

        $newStatus = $isValid ? 'active' : 'invalid';
        $this->links->update($link['id'], [
            'status' => $newStatus,
            'checked_at' => date('Y-m-d H:i:s'),
        ]);

        return [
            'link_id' => $link['id'],
            'url' => $link['url'],
            'was' => $link['status'],
            'now' => $newStatus,
            'valid' => $isValid,
        ];
    }

    /** 批量检测 */
    public function checkAll(): array {
        $allLinks = $this->links->all();
        $results = [];
        foreach ($allLinks as $link) {
            $results[] = $this->checkOne($link);
        }
        return $results;
    }

    /** 检测指定图片的所有链接 */
    public function checkImage(string $imageId): array {
        $links = $this->links->where(['image_id' => $imageId]);
        $results = [];
        foreach ($links as $link) {
            $results[] = $this->checkOne($link);
        }
        return $results;
    }

    /** 通用HTTP HEAD检测 */
    private function httpCheck(string $url): bool {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => CHECK_TIMEOUT,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $httpCode >= 200 && $httpCode < 400;
    }

    /** 获取图片可用链接（按优先级：active primary → active → backup） */
    public function getBestUrl(string $imageId): ?string {
        $links = $this->links->where(['image_id' => $imageId, 'status' => 'active']);
        if (!$links) {
            $links = $this->links->where(['image_id' => $imageId, 'status' => 'backup']);
        }
        if (!$links) return null;

        // 优先主链接
        foreach ($links as $link) {
            if (!empty($link['is_primary'])) return $link['url'];
        }
        return $links[0]['url'];
    }
}

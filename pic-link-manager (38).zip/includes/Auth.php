<?php
/**
 * 用户认证模块
 */
class Auth {
    private Storage $users;

    public function __construct() {
        $this->users = new Storage(FILE_USERS);
    }

    /** 注册 */
    public function register(string $username, string $password, string $email = ''): array {
        $username = trim($username);
        $email = trim($email);

        if (strlen($username) < 3) return ['ok' => false, 'msg' => '用户名至少3个字符'];
        if (strlen($password) < 6) return ['ok' => false, 'msg' => '密码至少6个字符'];

        // 查重
        $exist = $this->users->where(['username' => $username]);
        if ($exist) return ['ok' => false, 'msg' => '用户名已存在'];

        $user = [
            'username' => $username,
            'password_hash' => password_hash($password, PASSWORD_BCRYPT),
            'email' => $email,
            'role' => 'user',
            'created_at' => date('Y-m-d H:i:s'),
        ];
        $user = $this->users->insert($user);
        return ['ok' => true, 'msg' => '注册成功', 'user' => $user];
    }

    /** 登录 */
    public function login(string $username, string $password): array {
        $list = $this->users->where(['username' => trim($username)]);
        if (!$list) return ['ok' => false, 'msg' => '用户名或密码错误'];
        $user = $list[0];
        if (!password_verify($password, $user['password_hash'])) {
            return ['ok' => false, 'msg' => '用户名或密码错误'];
        }
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role'],
        ];
        $this->users->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);
        return ['ok' => true, 'msg' => '登录成功'];
    }

    /** 退出 */
    public function logout(): void {
        unset($_SESSION['user']);
        session_destroy();
    }

    /** 检查登录 */
    public function check(): bool {
        return isset($_SESSION['user']['id']);
    }

    /** 当前用户 */
    public function user(): ?array {
        return $_SESSION['user'] ?? null;
    }

    /** 需要登录（API拦截用） */
    public function requireLogin(): void {
        if (!$this->check()) {
            http_response_code(401);
            die(json_encode(['ok' => false, 'msg' => '请先登录'], JSON_UNESCAPED_UNICODE));
        }
    }

    /** 获取用户详情 */
    public function getById(string $id): ?array {
        return $this->users->find($id);
    }
}

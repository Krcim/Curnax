<?php
/**
 * JSON 文件存储引擎
 * 基于文件实现的轻量数据库，无需 MySQL
 */
class Storage {
    private string $file;
    private array $data = [];
    private array $index = []; // id => offset 索引

    public function __construct(string $file) {
        $this->file = $file;
        $this->load();
    }

    /** 加载数据文件 */
    private function load(): void {
        if (!file_exists($this->file)) {
            $dir = dirname($this->file);
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            file_put_contents($this->file, json_encode([]), LOCK_EX);
            $this->data = [];
            return;
        }
        $raw = file_get_contents($this->file);
        $this->data = json_decode($raw, true) ?: [];
        $this->rebuildIndex();
    }

    /** 重建索引 */
    private function rebuildIndex(): void {
        $this->index = [];
        foreach ($this->data as $i => $row) {
            if (isset($row['id'])) {
                $this->index[$row['id']] = $i;
            }
        }
    }

    /** 保存到文件 */
    private function save(): void {
        file_put_contents($this->file, json_encode($this->data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
    }

    /** 插入记录 */
    public function insert(array $row): array {
        if (!isset($row['id'])) {
            $row['id'] = $this->nextId();
        }
        $this->data[] = $row;
        $this->index[$row['id']] = count($this->data) - 1;
        $this->save();
        return $row;
    }

    /** 更新记录 */
    public function update($id, array $updates): bool {
        $idx = $this->findIndex($id);
        if ($idx === null) return false;
        $this->data[$idx] = array_merge($this->data[$idx], $updates);
        $this->save();
        return true;
    }

    /** 删除记录 */
    public function delete($id): bool {
        $idx = $this->findIndex($id);
        if ($idx === null) return false;
        array_splice($this->data, $idx, 1);
        unset($this->index[$id]);
        $this->rebuildIndex();
        $this->save();
        return true;
    }

    /** 查询单条 */
    public function find($id): ?array {
        $idx = $this->findIndex($id);
        return $idx !== null ? $this->data[$idx] : null;
    }

    /** 条件查询多条 */
    public function where(array $conditions, array $orderBy = [], int $limit = 0, int $offset = 0): array {
        $result = [];
        foreach ($this->data as $row) {
            $match = true;
            foreach ($conditions as $key => $val) {
                if (!isset($row[$key]) || $row[$key] != $val) {
                    $match = false;
                    break;
                }
            }
            if ($match) $result[] = $row;
        }

        // 排序
        if ($orderBy) {
            $field = key($orderBy);
            $dir = current($orderBy);
            usort($result, function ($a, $b) use ($field, $dir) {
                $va = $a[$field] ?? '';
                $vb = $b[$field] ?? '';
                return $dir === 'desc' ? ($vb <=> $va) : ($va <=> $vb);
            });
        }

        if ($limit > 0) {
            $result = array_slice($result, $offset, $limit);
        }
        return $result;
    }

    /** 获取全部 */
    public function all(): array {
        return $this->data;
    }

    /** 计数 */
    public function count(array $conditions = []): int {
        if (empty($conditions)) return count($this->data);
        return count($this->where($conditions));
    }

    /** 批量更新 */
    public function updateWhere(array $conditions, array $updates): int {
        $count = 0;
        foreach ($this->data as $i => $row) {
            $match = true;
            foreach ($conditions as $key => $val) {
                if (!isset($row[$key]) || $row[$key] != $val) { $match = false; break; }
            }
            if ($match) {
                $this->data[$i] = array_merge($this->data[$i], $updates);
                $count++;
            }
        }
        if ($count) $this->save();
        return $count;
    }

    /** 批量删除 */
    public function deleteWhere(array $conditions): int {
        $before = count($this->data);
        $this->data = array_values(array_filter($this->data, function ($row) use ($conditions) {
            foreach ($conditions as $key => $val) {
                if (isset($row[$key]) && $row[$key] == $val) return false;
            }
            return true;
        }));
        $deleted = $before - count($this->data);
        $this->rebuildIndex();
        $this->save();
        return $deleted;
    }

    private function findIndex($id): ?int {
        return $this->index[$id] ?? null;
    }

    private function nextId(): string {
        return uniqid('', true) . bin2hex(random_bytes(4));
    }
}

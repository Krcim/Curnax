<?php
/**
 * 用户管理页面
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/Storage.php';
require_once __DIR__ . '/includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { header('Location: index.php'); exit; }
$user = $auth->user();

$usersStore = new Storage(FILE_USERS);
$fullUser = $usersStore->find($user['id']) ?? [];

$msgType = ''; $msgText = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // 修改昵称
    if ($action === 'update_nickname') {
        $nickname = trim($_POST['nickname'] ?? '');
        if (mb_strlen($nickname) > 30) {
            $msgType = 'err'; $msgText = '昵称不能超过30个字符';
        } else {
            $usersStore->update($user['id'], ['nickname' => $nickname]);
            $_SESSION['user']['nickname'] = $nickname;
            $fullUser = $usersStore->find($user['id']);
            $msgType = 'ok'; $msgText = '昵称已更新';
        }
    }

    // 修改密码
    elseif ($action === 'update_password') {
        $oldPassword = $_POST['old_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $newPassword2 = $_POST['new_password2'] ?? '';

        if (!password_verify($oldPassword, $fullUser['password_hash'] ?? '')) {
            $msgType = 'err'; $msgText = '旧密码不正确';
        } elseif (strlen($newPassword) < 6) {
            $msgType = 'err'; $msgText = '新密码至少6个字符';
        } elseif ($newPassword !== $newPassword2) {
            $msgType = 'err'; $msgText = '两次输入的新密码不一致';
        } else {
            $usersStore->update($user['id'], [
                'password_hash' => password_hash($newPassword, PASSWORD_BCRYPT),
            ]);
            $msgType = 'ok'; $msgText = '密码已修改，请妥善保管';
        }
    }


}

// 退出
if (isset($_GET['logout'])) { $auth->logout(); header('Location: index.php'); exit; }
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>用户管理 - <?= SYS_NAME ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:#f0f2f5;min-height:100vh;font-size:14px;color:#333}
.header{background:#fff;border-bottom:1px solid #e8e8e8;padding:0 20px;height:52px;display:flex;align-items:center;justify-content:space-between}
.header h1{font-size:16px}
.header .user{font-size:13px;color:#666}
.header .user a{color:#1677ff;text-decoration:none;margin-left:8px}
.container{max-width:700px;margin:0 auto;padding:20px}
.card{background:#fff;border-radius:8px;padding:24px;margin-bottom:16px;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.card h3{margin-bottom:16px;font-size:15px;padding-bottom:10px;border-bottom:1px solid #f0f0f0}
.fg{margin-bottom:14px}
.fg label{display:block;font-size:13px;color:#555;margin-bottom:6px}
.fg input{width:100%;padding:8px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px}
.fg input:focus{outline:none;border-color:#1677ff}
.fg .hint{font-size:11px;color:#999;margin-top:2px}
.btn{padding:8px 20px;border:none;border-radius:5px;font-size:14px;cursor:pointer;transition:all .15s}
.btn-p{background:#1677ff;color:#fff}.btn-p:hover{background:#4096ff}
.btn-d{background:#fff;color:#333;border:1px solid #d9d9d9}.btn-d:hover{border-color:#1677ff;color:#1677ff}
.modal-btns{display:flex;gap:8px;margin-top:18px;justify-content:flex-end}
.toast{position:fixed;top:20px;right:20px;padding:10px 18px;border-radius:6px;color:#fff;font-size:13px;z-index:9999;opacity:0;transition:opacity .25s;pointer-events:none}
.toast.show{opacity:1}.toast.ok{background:#52c41a}.toast.err{background:#ff4d4f}.toast.warn{background:#fa8c16}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f5f5f5}
.info-row:last-child{border-bottom:none}
.info-label{color:#999;font-size:13px}
.info-value{color:#333;font-size:13px}
</style>
</head>
<body>

<div class="header">
  <h1><a href="dashboard.php" style="color:inherit;text-decoration:none"><?= SYS_NAME ?></a> · 用户管理</h1>
  <div class="user">
    <?= htmlspecialchars(($fullUser['nickname'] ?? '') ?: $user['username']) ?>
    <a href="dashboard.php">返回管理</a>
    <a href="settings.php">设置</a>
  </div>
</div>

<div class="container">

<!-- 基本信息 -->
<div class="card">
  <h3>基本信息</h3>
  <div class="info-row">
    <span class="info-label">用户ID</span>
    <span class="info-value"><?= htmlspecialchars($user['id']) ?></span>
  </div>
  <div class="info-row">
    <span class="info-label">用户名</span>
    <span class="info-value"><?= htmlspecialchars($fullUser['username'] ?? '') ?></span>
  </div>
  <div class="info-row">
    <span class="info-label">昵称</span>
    <span class="info-value"><?= htmlspecialchars($fullUser['nickname'] ?? '未设置') ?></span>
  </div>
  <div class="info-row">
    <span class="info-label">角色</span>
    <span class="info-value"><?= htmlspecialchars($fullUser['role'] ?? 'user') ?></span>
  </div>
  <div class="info-row">
    <span class="info-label">注册时间</span>
    <span class="info-value"><?= htmlspecialchars($fullUser['created_at'] ?? '-') ?></span>
  </div>
  <div class="info-row">
    <span class="info-label">最后登录</span>
    <span class="info-value"><?= htmlspecialchars($fullUser['last_login'] ?? '-') ?></span>
  </div>
</div>

<!-- 修改昵称 -->
<div class="card">
  <h3>自定义昵称</h3>
  <form method="post">
    <input type="hidden" name="action" value="update_nickname">
    <div class="fg">
      <label>昵称（用于页面显示）</label>
      <input type="text" name="nickname" value="<?= htmlspecialchars($fullUser['nickname'] ?? '') ?>" placeholder="输入昵称..." maxlength="30">
      <div class="hint">留空则使用用户名显示</div>
    </div>
    <div class="modal-btns">
      <button type="submit" class="btn btn-p">保存昵称</button>
    </div>
  </form>
</div>

<!-- 修改密码 -->
<div class="card">
  <h3>修改密码</h3>
  <form method="post">
    <input type="hidden" name="action" value="update_password">
    <div class="fg">
      <label>旧密码</label>
      <input type="password" name="old_password" required placeholder="输入当前密码">
    </div>
    <div class="fg">
      <label>新密码</label>
      <input type="password" name="new_password" required minlength="6" placeholder="至少6个字符">
    </div>
    <div class="fg">
      <label>确认新密码</label>
      <input type="password" name="new_password2" required minlength="6" placeholder="再次输入新密码">
    </div>
    <div class="modal-btns">
      <button type="submit" class="btn btn-p">修改密码</button>
    </div>
  </form>
</div>

</div>

<div class="toast" id="toast"></div>
<script>
function T(m,t){var e=document.getElementById('toast');e.textContent=m;e.className='toast '+t+' show';setTimeout(function(){e.classList.remove('show')},3000)}
</script>

<?php if ($msgText): ?>
<script>T(<?= json_encode($msgText, JSON_UNESCAPED_UNICODE) ?>,<?= json_encode($msgType) ?>)</script>
<?php endif; ?>
</body>
</html>

<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/Storage.php';
require_once __DIR__ . '/includes/Auth.php';

$auth = new Auth();
if (!$auth->check()) { header('Location: index.php'); exit; }
$user = $auth->user();

// 确保 CDN 目录存在
if (!is_dir(CDN_PATH)) mkdir(CDN_PATH, 0755, true);
if (!is_dir(CDN_TMP_PATH)) mkdir(CDN_TMP_PATH, 0755, true);
if (!is_dir(CDN_DOWN_PATH)) mkdir(CDN_DOWN_PATH, 0755, true);

$images = new Storage(FILE_CDN_IMAGES);
$links = new Storage(FILE_CDN_LINKS);
$folders = new Storage(FILE_CDN_FOLDERS);

$msgType = ''; $msgText = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // URL 添加
    if ($action === 'add_url') {
        $url = trim($_POST['url'] ?? '');
        $folderId = $_POST['folder_id'] ?? '';
        if ($url && filter_var($url, FILTER_VALIDATE_URL)) {
            $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_EXTENSION)) ?: 'file';
            $origName = basename(parse_url($url, PHP_URL_PATH)) ?: 'cdn_file.' . $ext;
            $img = $images->insert([
                'name' => $_POST['name'] ?: $origName,
                'original_name' => $origName,
                'file_size' => 0,
                'file_type' => $ext,
                'folder_id' => $folderId ?: null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $links->insert([
                'image_id' => $img['id'],
                'url' => $url,
                'label' => $_POST['label'] ?: '分发链接',
                'is_primary' => true,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            // 自动生成统一链接 slug
            $slug = generateSlug($img['name'], $img['id'], $images->all(), $img['id']);
            $images->update($img['id'], ['unified_slug' => $slug]);
            $msgType = 'ok'; $msgText = 'CDN 链接已添加';
        } else {
            $msgType = 'err'; $msgText = '请输入有效的 URL';
        }
    }
    // 自定义添加
    elseif ($action === 'add_custom') {
        $folderId = $_POST['folder_id'] ?? '';
        $img = $images->insert([
            'name' => $_POST['name'] ?: '未命名',
            'original_name' => $_POST['original_name'] ?: 'custom',
            'file_size' => 0,
            'file_type' => $_POST['file_type'] ?: '-',
            'folder_id' => $folderId ?: null,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        if (!empty($_POST['link_url'])) {
            $links->insert([
                'image_id' => $img['id'],
                'url' => $_POST['link_url'],
                'label' => $_POST['link_label'] ?: '分发链接',
                'is_primary' => true,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
        }
        // 自动生成统一链接 slug
        $slug = generateSlug($img['name'], $img['id'], $images->all(), $img['id']);
        $images->update($img['id'], ['unified_slug' => $slug]);
        $msgType = 'ok'; $msgText = 'CDN 条目已创建';
    }
    // 新建文件夹
    elseif ($action === 'folder_create') {
        $name = trim($_POST['folder_name'] ?? '');
        if ($name) {
            $folders->insert(['name' => $name, 'created_at' => date('Y-m-d H:i:s')]);
            $msgType = 'ok'; $msgText = "文件夹「{$name}」已创建";
        }
    }
    // 文件夹删除
    elseif ($action === 'folder_delete') {
        $fid = $_POST['folder_id'] ?? '';
        if ($folders->find($fid)) {
            $fn = $folders->find($fid)['name'];
            $images->updateWhere(['folder_id' => $fid], ['folder_id' => null]);
            $folders->delete($fid);
            $msgType = 'ok'; $msgText = "文件夹「{$fn}」已删除，条目已移入未分类";
        }
    }
    // 文件夹重命名
    elseif ($action === 'folder_rename') {
        $fid = $_POST['folder_id'] ?? '';
        $name = trim($_POST['folder_name'] ?? '');
        if ($fid && $name && $folders->find($fid)) {
            $folders->update($fid, ['name' => $name]);
            $msgType = 'ok'; $msgText = "已重命名为「{$name}」";
        }
    }
    // 添加链接
    elseif ($action === 'add_link') {
        $imageId = $_POST['image_id'] ?? '';
        $url = trim($_POST['url'] ?? '');
        if ($imageId && $url && filter_var($url, FILTER_VALIDATE_URL)) {
            $links->insert([
                'image_id' => $imageId,
                'url' => $url,
                'label' => $_POST['label'] ?: '备用',
                'is_primary' => false,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $msgType = 'ok'; $msgText = '链接已添加';
        }
    }
    // 编辑链接
    elseif ($action === 'edit_link') {
        $linkId = $_POST['link_id'] ?? '';
        $url = trim($_POST['url'] ?? '');
        $label = trim($_POST['label'] ?? '');
        if ($linkId && $links->find($linkId)) {
            $links->update($linkId, ['url' => $url, 'label' => $label]);
            $msgType = 'ok'; $msgText = '链接已更新';
        }
    }
    // 删除链接
    elseif ($action === 'delete_link') {
        $linkId = $_POST['link_id'] ?? '';
        if ($links->find($linkId)) {
            $links->delete($linkId);
            $msgType = 'ok'; $msgText = '链接已删除';
        }
    }
    // 设为主链接
    elseif ($action === 'set_primary') {
        $linkId = $_POST['link_id'] ?? '';
        $link = $links->find($linkId);
        if ($link) {
            $links->updateWhere(['image_id' => $link['image_id']], ['is_primary' => false]);
            $links->update($linkId, ['is_primary' => true]);
            $msgType = 'ok'; $msgText = '已设为主链接';
        }
    }
    // 检测链接
    elseif ($action === 'check_link') {
        $linkId = $_POST['link_id'] ?? '';
        $link = $links->find($linkId);
        if ($link) {
            $status = checkLinkValid($link['url']);
            $links->update($linkId, ['status' => $status]);
            $msgType = 'ok'; $msgText = "检测结果：" . ($status === 'active' ? '有效' : '失效');
        }
    }
    // 检测全部链接
    elseif ($action === 'check_all') {
        $allLinks = $links->all();
        $ok = 0; $fail = 0;
        foreach ($allLinks as $lk) {
            $status = checkLinkValid($lk['url']);
            $links->update($lk['id'], ['status' => $status]);
            $status === 'active' ? $ok++ : $fail++;
        }
        $msgType = 'ok'; $msgText = "全部检测完成：{$ok} 有效 / {$fail} 失效";
    }
    // 删除图片
    elseif ($action === 'delete_image') {
        $id = $_POST['image_id'] ?? '';
        if ($images->find($id)) {
            $links->deleteWhere(['image_id' => $id]);
            $images->delete($id);
            // 清理缓存
            @unlink(CDN_TMP_PATH . '/' . $id . '.*');
            @unlink(CDN_DOWN_PATH . '/' . $id . '.*');
            $msgType = 'ok'; $msgText = 'CDN 条目已删除';
        }
    }
    // 批量删除
    elseif ($action === 'batch_delete') {
        $ids = json_decode($_POST['ids'] ?? '[]', true);
        $count = 0;
        foreach ($ids as $id) {
            if ($images->find($id)) {
                $links->deleteWhere(['image_id' => $id]);
                $images->delete($id);
                @unlink(CDN_TMP_PATH . '/' . $id . '.*');
                @unlink(CDN_DOWN_PATH . '/' . $id . '.*');
                $count++;
            }
        }
        $msgType = 'ok'; $msgText = "已删除 {$count} 条";
    }
    // 批量移动
    elseif ($action === 'batch_move') {
        $ids = json_decode($_POST['ids'] ?? '[]', true);
        $fid = $_POST['folder_id'] ?? '';
        $count = 0;
        foreach ($ids as $id) {
            if ($images->find($id)) {
                $images->update($id, ['folder_id' => $fid ?: null]);
                $count++;
            }
        }
        $msgType = 'ok'; $msgText = "已移动 {$count} 条";
    }
    // 下载到服务器
    elseif ($action === 'download_to_server') {
        $id = $_POST['image_id'] ?? '';
        $dlFolder = trim($_POST['dl_folder'] ?? '');
        $img = $images->find($id);
        if ($img) {
            $imgLinks = $links->where(['image_id' => $id]);
            $bestUrl = '';
            foreach ($imgLinks as $l) { if ($l['status'] === 'active') { $bestUrl = $l['url']; break; } }
            if (!$bestUrl && !empty($imgLinks)) $bestUrl = $imgLinks[0]['url'];
            if ($bestUrl) {
                // Determine target directory
                $targetDir = CDN_DOWN_PATH;
                if ($dlFolder) {
                    $targetDir .= '/' . sanitizeFileName($dlFolder);
                    if (!is_dir($targetDir)) mkdir($targetDir, 0755, true);
                }
                $ext = $img['file_type'] ?: 'file';
                $baseName = ($img['original_name'] && $img['original_name'] !== '-') ? pathinfo($img['original_name'], PATHINFO_FILENAME) : $img['name'];
                $baseName = sanitizeFileName($baseName);
                // Auto-rename if duplicate exists
                $dest = $targetDir . '/' . $baseName . '.' . $ext;
                $counter = 1;
                while (file_exists($dest)) {
                    $dest = $targetDir . '/' . $baseName . '_' . $counter . '.' . $ext;
                    $counter++;
                }
                $data = @file_get_contents($bestUrl);
                if ($data) {
                    file_put_contents($dest, $data);
                    $size = strlen($data);
                    $images->update($id, ['file_size' => $size]);
                    $msgType = 'ok'; $msgText = "已下载到服务器 (" . round($size/1048576,2) . "MB)";
                } else {
                    $msgType = 'err'; $msgText = '下载失败：无法获取文件';
                }
            } else {
                $msgType = 'err'; $msgText = '没有可用链接';
            }
        }
    }
    // 重新获取
    elseif ($action === 'refresh_item') {
        $id = $_POST['image_id'] ?? '';
        $img = $images->find($id);
        if ($img) {
            $imgLinks = $links->where(['image_id' => $id]);
            $bestUrl = '';
            foreach ($imgLinks as $l) { if ($l['status'] === 'active') { $bestUrl = $l['url']; break; } }
            if (!$bestUrl && !empty($imgLinks)) $bestUrl = $imgLinks[0]['url'];
            if ($bestUrl) {
                $ext = $img['file_type'] ?: 'file';
                $dest = CDN_DOWN_PATH . '/' . $id . '.' . $ext;
                $data = @file_get_contents($bestUrl);
                if ($data) {
                    file_put_contents($dest, $data);
                    $size = strlen($data);
                    $images->update($id, ['file_size' => $size]);
                    $msgType = 'ok'; $msgText = "重新获取成功 (" . round($size/1048576,2) . "MB)";
                } else {
                    $msgType = 'err'; $msgText = '重新获取失败';
                }
            } else {
                $msgType = 'err'; $msgText = '没有可用链接';
            }
        }
    }
    // 编辑条目属性
    elseif ($action === 'edit_item') {
        $id = $_POST['image_id'] ?? '';
        $updates = [];
        if (isset($_POST['name'])) $updates['name'] = $_POST['name'];
        if (isset($_POST['original_name'])) $updates['original_name'] = $_POST['original_name'];
        if (isset($_POST['file_type'])) $updates['file_type'] = $_POST['file_type'];
        if (isset($_POST['folder_id'])) $updates['folder_id'] = $_POST['folder_id'] ?: null;
        if (isset($_POST['file_size']) && $_POST['file_size'] !== '') $updates['file_size'] = intval($_POST['file_size']);
        if ($updates && $images->find($id)) {
            $images->update($id, $updates);
            $msgType = 'ok'; $msgText = '属性已更新';
        }
    }
    // 更新文件大小
    elseif ($action === 'update_size') {
        $id = $_POST['image_id'] ?? '';
        $size = intval($_POST['file_size'] ?? 0);
        if ($images->find($id)) {
            $images->update($id, ['file_size' => $size]);
            $msgType = 'ok'; $msgText = '文件大小已更新';
        }
    }
    // 清理 CDN 缓存
    elseif ($action === 'clean_cdn_cache') {
        cleanCdnCache();
        $msgType = 'ok'; $msgText = 'CDN 缓存已清理';
    }
    // 清理 CDN 下载目录过期文件
    elseif ($action === 'clean_cdn_down') {
        cleanCdnDown();
        $msgType = 'ok'; $msgText = '过期下载文件已清理';
    }
    // 批量添加
    elseif ($action === 'batch_add') {
        $itemsJson = $_POST['items'] ?? '[]';
        $items = json_decode($itemsJson, true);
        if (!is_array($items) || empty($items)) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'message' => '数据为空'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $allItems = $images->all();
        $successCount = 0;
        foreach ($items as $idx => $item) {
            $name = trim($item['name'] ?? '');
            $primaryUrl = trim($item['primary_url'] ?? '');
            $backupUrl = trim($item['backup_url'] ?? '');
            if (empty($name) || empty($primaryUrl)) continue;
            $ext = strtolower(pathinfo(parse_url($primaryUrl, PHP_URL_PATH), PATHINFO_EXTENSION)) ?: 'url';
            $img = $images->insert([
                'name' => $name,
                'original_name' => $name,
                'file_size' => 0,
                'file_type' => $ext,
                'folder_id' => null,
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            $links->insert([
                'image_id' => $img['id'],
                'url' => $primaryUrl,
                'label' => '主链接',
                'is_primary' => true,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ]);
            if (!empty($backupUrl)) {
                $links->insert([
                    'image_id' => $img['id'],
                    'url' => $backupUrl,
                    'label' => '备用链接',
                    'is_primary' => false,
                    'status' => 'pending',
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }
            $slug = generateSlug($img['name'], $img['id'], $images->all(), $img['id']);
            $images->update($img['id'], ['unified_slug' => $slug]);
            $successCount++;
        }
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success' => true,
            'count' => $successCount,
            'message' => '成功添加 ' . $successCount . ' 条'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

function checkLinkValid($url) {
    // Step 1: HEAD request
    $ctx = stream_context_create(['http' => [
        'timeout' => CHECK_TIMEOUT,
        'method' => 'HEAD',
        'header' => "User-Agent: CDN-Checker/1.0\r\n"
    ]]);
    $headers = @get_headers($url, 1, $ctx);
    if ($headers && isset($headers[0]) && strpos($headers[0], '200') !== false) {
        return 'active';
    }

    // Step 2: HEAD inconclusive → try GET with 3s timeout, read first KB
    $ctx = stream_context_create(['http' => [
        'timeout' => 3,
        'method' => 'GET',
        'header' => "User-Agent: CDN-Checker/1.0\r\n"
    ]]);
    $fp = @fopen($url, 'rb', false, $ctx);
    if ($fp) {
        $data = @fread($fp, 1024);
        @fclose($fp);
        if ($data && strlen($data) > 0) {
            return 'active';
        }
    }

    return 'invalid';
}

function sanitizeFileName($name) {
    $name = trim($name);
    // Remove path separators and dangerous chars
    $name = str_replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], '_', $name);
    $name = preg_replace('/[\x00-\x1f]/', '', $name);
    if (empty($name)) $name = 'unnamed';
    // Trim trailing dots/spaces (Windows restriction)
    $name = rtrim($name, ". \t\n\r\0\x0B");
    return $name;
}

function generateSlug($name, $fallbackId, $allItems, $excludeId) {
    // 1. Sanitize name
    $slug = sanitizeFileName($name);
    // 2. Remove file extension if present (e.g. "file.zip" → "file")
    $slug = preg_replace('/\.\w{1,10}$/', '', $slug);
    // 3. Remove non-ASCII chars (Chinese, etc.)
    $slug = preg_replace('/[^\x20-\x7E]/', '', $slug);
    // 4. Replace spaces and non-alphanumeric with hyphens
    $slug = preg_replace('/[^a-zA-Z0-9]+/', '-', $slug);
    $slug = trim($slug, '-');
    // 5. Fallback to hash if empty
    if (strlen($slug) < 1) $slug = substr(md5($fallbackId . time()), 0, 10);
    // 6. Deduplicate
    $baseSlug = $slug;
    $counter = 1;
    $exists = true;
    while ($exists) {
        $exists = false;
        foreach ($allItems as $item) {
            if (($item['id'] ?? '') !== $excludeId && ($item['unified_slug'] ?? '') === $slug) {
                $exists = true;
                $slug = $baseSlug . '-' . $counter;
                $counter++;
                break;
            }
        }
    }
    return $slug;
}

function cdnCacheStats() {
    $size = 0; $count = 0;
    if (is_dir(CDN_TMP_PATH)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(CDN_TMP_PATH, RecursiveDirectoryIterator::SKIP_DOTS));
        foreach ($rii as $f) { $size += $f->getSize(); $count++; }
    }
    return ['size' => $size, 'count' => $count];
}
function cdnDownStats() {
    $size = 0; $count = 0;
    if (is_dir(CDN_DOWN_PATH)) {
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(CDN_DOWN_PATH, RecursiveDirectoryIterator::SKIP_DOTS));
        foreach ($rii as $f) { $size += $f->getSize(); $count++; }
    }
    return ['size' => $size, 'count' => $count];
}
function cleanCdnCache() {
    if (!is_dir(CDN_TMP_PATH)) return;
    $now = time();
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(CDN_TMP_PATH, RecursiveDirectoryIterator::SKIP_DOTS));
    foreach ($rii as $f) { if ($now - $f->getMTime() > CDN_TTL) unlink($f->getPathname()); }
}
function cleanCdnDown() {
    if (!is_dir(CDN_DOWN_PATH)) return;
    $now = time();
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(CDN_DOWN_PATH, RecursiveDirectoryIterator::SKIP_DOTS));
    foreach ($rii as $f) { if ($now - $f->getMTime() > CDN_TTL) unlink($f->getPathname()); }
}

// 分页 + 筛选
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = intval($_GET['per_page'] ?? 20);
if (!in_array($perPage, [20, 50, 100, 200])) {
    $perPage = 20;
}
$currentFolder = $_GET['folder'] ?? 'all';
$allImages = array_reverse($images->all());
$allFolders = $folders->all();

if ($currentFolder !== 'all') {
    $allImages = array_filter($allImages, function($img) use ($currentFolder) {
        return ($img['folder_id'] ?? null) === $currentFolder;
    });
}
$allImages = array_values($allImages);
$totalPages = ceil(count($allImages) / $perPage);
$pageImages = array_slice($allImages, ($page - 1) * $perPage, $perPage);

// 构建图片-链接映射
$cdnDataMap = [];
foreach ($allImages as $img) {
    $imgLinks = $links->where(['image_id' => $img['id']]);
    $folderName = '';
    if (!empty($img['folder_id'])) {
        $f = $folders->find($img['folder_id']);
        $folderName = $f ? $f['name'] : '';
    }
    $cdnDataMap[$img['id']] = [
        'id' => $img['id'],
        'name' => $img['name'],
        'original_name' => $img['original_name'],
        'file_size' => $img['file_size'],
        'file_type' => $img['file_type'],
        'folder_id' => $img['folder_id'] ?? null,
        'folder_name' => $folderName,
        'unified_slug' => $img['unified_slug'] ?? '',
        'links' => $imgLinks,
    ];
}

$cdnCache = cdnCacheStats();
$cdnDown = cdnDownStats();

// 退出
if (isset($_GET['logout'])) { $auth->logout(); header('Location: index.php'); exit; }

// 页脚配置
$footerCfg = file_exists(DATA_PATH . '/footer_config.json') ? (json_decode(file_get_contents(DATA_PATH . '/footer_config.json'), true) ?: []) : [];
$showFooter = in_array('cdn', $footerCfg['show_on'] ?? []) || in_array('all', $footerCfg['show_on'] ?? []);
?><!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CDN 分发管理 - <?= SYS_NAME ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:#f0f2f5;min-height:100vh;font-size:14px;color:#333}
.header{background:#fff;border-bottom:1px solid #e8e8e8;padding:0 20px;height:52px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.header h1{font-size:16px}
.header .beta-badge{display:inline-block;background:#ff4d4f;color:#fff;font-size:10px;padding:1px 6px;border-radius:8px;margin-left:6px;vertical-align:middle}
.header .user{font-size:13px;color:#666}
.header .user a{color:#ff4d4f;text-decoration:none;margin-left:10px}
.header .user a.nav-btn{display:inline-block;padding:3px 12px;background:#1677ff;color:#fff;border-radius:20px;text-decoration:none;margin-left:8px;font-size:12px;transition:background .2s}.header .user a.nav-btn:hover{background:#4096ff}
.layout{display:flex;min-height:calc(100vh - 52px)}
/* 侧边栏 */
.sidebar{width:220px;background:#fff;border-right:1px solid #e8e8e8;padding:12px 0;flex-shrink:0;overflow-y:auto}
.sidebar .section{padding:0 14px;margin-bottom:8px}
.sidebar .section-title{font-size:12px;color:#999;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;padding:0 2px}
.sidebar .section-title .beta-dot{display:inline-block;width:6px;height:6px;background:#ff4d4f;border-radius:50%;margin-left:4px;vertical-align:middle}
.sidebar .folder-item{display:flex;align-items:center;padding:7px 14px;font-size:13px;cursor:pointer;transition:background .15s;text-decoration:none;color:#333;gap:8px}
.sidebar .folder-item:hover{background:#f5f5f5}
.sidebar .folder-item.active{background:#e6f7ff;color:#1677ff;font-weight:500;border-right:3px solid #1677ff}
.sidebar .folder-item .icon{font-size:16px;width:20px;text-align:center;flex-shrink:0}
.sidebar .folder-item .count{font-size:11px;color:#999;margin-left:auto}
.sidebar .folder-item.active .count{color:#1677ff}
.sidebar .folder-actions{display:none;gap:2px;margin-left:auto}
.sidebar .folder-item:hover .count{display:none}
.sidebar .folder-item:hover .folder-actions{display:flex}
.sidebar .folder-actions button{background:none;border:none;cursor:pointer;font-size:12px;padding:2px 5px;border-radius:3px;color:#999}
.sidebar .folder-actions button:hover{background:#f0f0f0;color:#333}
.sidebar .folder-actions .del-btn:hover{color:#ff4d4f;background:#fff2f0}
.sidebar .new-folder{padding:8px 14px;display:flex;gap:6px}
.sidebar .new-folder input{flex:1;padding:6px 8px;border:1px solid #d9d9d9;border-radius:4px;font-size:12px;min-width:0}
.sidebar .new-folder input:focus{outline:none;border-color:#1677ff}
.sidebar .new-folder button{padding:6px 10px;background:#1677ff;color:#fff;border:none;border-radius:4px;font-size:12px;cursor:pointer;white-space:nowrap}
.sidebar .new-folder button:hover{background:#4096ff}
/* 主区域 */
.main{flex:1;padding:16px;overflow-y:auto;min-width:0}
.container{max-width:1400px}
.cache-bar{background:#fff;border-radius:6px;padding:10px 16px;margin-bottom:12px;display:flex;align-items:center;gap:14px;font-size:13px;box-shadow:0 1px 3px rgba(0,0,0,.04)}
.cache-bar .meter{flex:1;height:8px;background:#f0f0f0;border-radius:4px;overflow:hidden}
.cache-bar .meter div{height:100%;background:#1677ff;border-radius:4px;transition:width .3s}
.toolbar{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;align-items:center}
.toolbar .search-input{padding:6px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px;width:200px}
.toolbar .search-input:focus{outline:none;border-color:#1677ff}
.btn{padding:6px 14px;border:none;border-radius:5px;font-size:13px;cursor:pointer;transition:all .15s;white-space:nowrap}
.btn-p{background:#1677ff;color:#fff}.btn-p:hover{background:#4096ff}
.btn-d{background:#fff;color:#333;border:1px solid #d9d9d9}.btn-d:hover{border-color:#1677ff;color:#1677ff}
.btn-r{background:#ff4d4f;color:#fff}.btn-r:hover{background:#ff7875}
.btn-w{background:#fa8c16;color:#fff}.btn-w:hover{background:#ffa940}
.btn-g{background:#52c41a;color:#fff}.btn-g:hover{background:#73d13d}
.btn-xs{padding:2px 8px;font-size:12px}
.btn:disabled{opacity:.6;cursor:not-allowed}
table{width:100%;border-collapse:collapse;background:#fff;border-radius:6px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.04)}
th{background:#fafafa;padding:10px 14px;text-align:left;font-size:13px;color:#666;font-weight:500;border-bottom:1px solid #f0f0f0;white-space:nowrap}
td{padding:8px 14px;border-bottom:1px solid #f5f5f5;font-size:13px;vertical-align:top}
tr:hover td{background:#fafafa}
.link-row{display:flex;align-items:center;gap:5px;margin:3px 0;flex-wrap:wrap}
.url-txt{font-size:12px;color:#1677ff;word-break:break-all;flex:1;min-width:0;cursor:pointer}
.url-txt:hover{text-decoration:underline}
.tag{padding:1px 6px;border-radius:3px;font-size:11px;white-space:nowrap}
.tag-ok{background:#f6ffed;color:#52c41a}.tag-fail{background:#fff2f0;color:#ff4d4f}.tag-bk{background:#fff7e6;color:#fa8c16}.tag-pd{background:#f0f0f0;color:#999}
.tag-p{background:#e6f7ff;color:#1677ff}
.pagination{text-align:center;margin-top:12px;display:flex;gap:6px;justify-content:center}
.pagination a,.pagination span{padding:5px 10px;border-radius:4px;border:1px solid #d9d9d9;font-size:13px;text-decoration:none;color:#333}
.pagination a:hover{border-color:#1677ff;color:#1677ff}
.pagination .active{background:#1677ff;color:#fff;border-color:#1677ff}
.pagination .disabled{color:#bbb;border-color:#e8e8e8;cursor:default}
/* 弹窗 */
.modal-o{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,.4);z-index:999;align-items:center;justify-content:center}
.modal-o.show{display:flex}
.modal{background:#fff;border-radius:10px;padding:28px;width:480px;max-width:90%;max-height:85vh;overflow-y:auto}
.modal.wide{width:900px}
.modal h3{margin-bottom:16px;font-size:16px}
.fg{margin-bottom:12px}
.fg label{display:block;font-size:13px;color:#555;margin-bottom:4px}
.fg input,.fg select{width:100%;padding:7px 10px;border:1px solid #d9d9d9;border-radius:5px;font-size:13px}
.fg input:focus,.fg select:focus{outline:none;border-color:#1677ff}
.fg .hint{font-size:11px;color:#999;margin-top:2px}
.fg-row{display:flex;gap:10px}.fg-row .fg{flex:1}
.modal-btns{display:flex;gap:8px;margin-top:18px;justify-content:flex-end}
/* 详情弹窗 */
.detail-layout{display:flex;gap:20px;min-height:300px}
.detail-info{flex:1;min-width:0;overflow-y:auto;max-height:60vh}
.detail-info table{box-shadow:none;margin-bottom:16px}
.detail-info table td{padding:5px 8px;font-size:12px}
.detail-info .attr-label{color:#999;width:80px;white-space:nowrap}
/* 批量操作 */
.batch-header{display:flex;align-items:center;gap:12px;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #f0f0f0}
.batch-list{max-height:300px;overflow-y:auto;margin-bottom:12px}
.batch-list .batch-row{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #f8f8f8;font-size:13px}
.batch-list .batch-row label{flex:1;cursor:pointer;min-width:0}
.batch-list .batch-row select{font-size:12px;padding:3px 6px;border:1px solid #d9d9d9;border-radius:4px}
/* 消息提示 */
.msg{display:none;padding:8px 14px;border-radius:5px;margin-bottom:10px;font-size:13px}
.msg.show{display:block}
.msg.ok{background:#f6ffed;border:1px solid #b7eb8f;color:#52c41a}
.msg.err{background:#fff2f0;border:1px solid #ffccc7;color:#ff4d4f}
</style>
</head>
<body>
<div class="header">
  <h1><?= SYS_NAME ?> <span class="beta-badge">内测</span> &mdash; CDN 分发管理</h1>
  <div class="user">
    <?= htmlspecialchars($user['username'] ?? '') ?>
    <a href="dashboard.php" class="nav-btn">仪表板</a>
    <a href="?logout=1">退出</a>
  </div>
</div>

<div class="layout">
<!-- 侧边栏 -->
<div class="sidebar">
  <div class="section">
    <div class="section-title">文件夹<span class="beta-dot"></span></div>
    <a href="?folder=all" class="folder-item <?= $currentFolder==='all'?'active':'' ?>">
      <span class="icon">&#128193;</span>全部
      <span class="count"><?= count($images->all()) ?></span>
    </a>
    <?php foreach ($allFolders as $f): ?>
    <?php $fcount = count(array_filter($images->all(), fn($i) => ($i['folder_id']??null)===$f['id'])); ?>
    <a href="?folder=<?= htmlspecialchars($f['id']) ?>" class="folder-item <?= $currentFolder===$f['id']?'active':'' ?>">
      <span class="icon">&#128194;</span><?= htmlspecialchars($f['name']) ?>
      <span class="count"><?= $fcount ?></span>
      <span class="folder-actions">
        <button title="重命名" onclick="event.preventDefault();event.stopPropagation();startRename('<?= htmlspecialchars($f['id']) ?>','<?= htmlspecialchars(addslashes($f['name'])) ?>')">&#9998;</button>
        <button class="del-btn" title="删除" onclick="event.preventDefault();event.stopPropagation();if(confirm('删除文件夹「<?= htmlspecialchars(addslashes($f['name'])) ?>」？\n条目将移入未分类。'))submitForm('folder_delete','folder_id','<?= htmlspecialchars($f['id']) ?>')">&#10005;</button>
      </span>
    </a>
    <?php endforeach; ?>
  </div>
  <form method="post" class="new-folder" onsubmit="return this.folder_name.value.trim()!==''">
    <input type="hidden" name="action" value="folder_create">
    <input type="text" name="folder_name" placeholder="新文件夹名称..." required maxlength="50">
    <button type="submit">+ 新建</button>
  </form>
</div>

<!-- 主区域 -->
<div class="main">
<div class="container">

<div id="msgBox" class="msg <?= $msgType ?> <?= $msgText ? 'show' : '' ?>"><?= htmlspecialchars($msgText) ?></div>

<div class="cache-bar">
  <span>缓存目录: Stock/CDN/tmp</span>
  <div class="meter"><div style="width:<?= min(100, $cdnCache['size']/CDN_CACHE_MAX*100) ?>%"></div></div>
  <span><?= round($cdnCache['size']/1048576,1) ?>MB / 10240MB · <?= $cdnCache['count'] ?>个文件</span>
  <button class="btn btn-w btn-xs" onclick="submitForm('clean_cdn_cache')">清理过期</button>
</div>

<div class="cache-bar" style="background:#f6ffed;border:1px solid #b7eb8f">
  <span>下载目录: Stock/CDN/down</span>
  <div class="meter"><div style="width:<?= min(100, $cdnDown['size']/CDN_CACHE_MAX*100); background:#52c41a ?>%"></div></div>
  <span><?= round($cdnDown['size']/1048576,1) ?>MB / 10240MB · <?= $cdnDown['count'] ?>个文件</span>
  <button class="btn btn-r btn-xs" onclick="submitForm('clean_cdn_down')">清理过期48h</button>
</div>

<div class="toolbar">
  <button class="btn btn-w" onclick="if(confirm('确定检测全部链接有效性？'))submitForm('check_all')">检测全部链接</button>
  <input type="text" class="search-input" id="searchInput" placeholder="搜索名称/原始名..." oninput="filterTable()">
  <button class="btn btn-d btn-xs" onclick="filterTable()">搜索</button>
  <button class="btn btn-p" onclick="showModal('urlModal')">URL 添加</button>
  <button class="btn btn-d" onclick="showModal('customModal')">自定义添加</button>
  <button class="btn btn-d btn-xs" onclick="toggleBatchAdd()">批量添加</button>
  <button class="btn btn-d" onclick="showBatchCopy()">批量复制</button>
  <button class="btn btn-d" onclick="showBatchDownload()">批量下载</button>
  <button class="btn btn-d" onclick="showBatchDownloadLocal()">批量下载至本地</button>
  <button class="btn btn-r btn-xs" onclick="batchDelete()" style="display:none" id="batchDeleteBtn">批量删除</button>
  <button class="btn btn-d btn-xs" onclick="showBatchMove()" style="display:none" id="batchMoveBtn">移动到文件夹</button>
  <button class="btn btn-d btn-xs" onclick="showBatchDownload()" style="display:none" id="batchDlServerBtn"><span style="font-size:14px">&#9729;</span> 下载至服务器</button>
  <button class="btn btn-g btn-xs" onclick="showBatchDownloadLocal()" style="display:none" id="batchDlLocalBtn"><span style="font-size:14px">&#8681;</span> 下载至本地</button>
</div>

<div id="batchAddArea" style="display:none;margin:16px 0;padding:16px;background:#fafafa;border:1px solid #e8e8e8;border-radius:6px">
  <div style="margin-bottom:10px;font-weight:500;color:#333">批量添加链接</div>
  <div style="font-size:11px;color:#999;margin-bottom:8px">
    格式：名称 [主链接] [备用链接]（每行一个，备用链接可选）
  </div>
  <textarea id="batchInput" rows="6" placeholder="示例：
WPS办公软件 [https://vip.123pan.cn/xxx/wps.zip] [https://ycoemxt.cn/xxx/wps.exe]
Steam客户端 [https://vip.123pan.cn/xxx/steam.exe]" 
  style="width:100%;padding:8px;border:1px solid #d9d9d9;border-radius:4px;font-family:monospace;font-size:12px;resize:vertical"></textarea>
  <div style="margin-top:10px;display:flex;align-items:center;gap:10px">
    <button class="btn btn-p" onclick="batchAdd()">批量添加</button>
    <span id="batchResult" style="font-size:12px"></span>
  </div>
</div>

<table id="cdnTable">
<thead><tr>
  <th style="width:30px"><input type="checkbox" id="selectAll" onclick="toggleAllRows(this)"></th>
  <th>名称</th><th>原始文件名</th><th>大小</th><th style="width:70px">类型</th><th style="width:100px">文件夹</th><th>链接</th><th style="width:130px">操作</th>
</tr></thead>
<tbody>
<?php if (empty($pageImages)): ?>
<tr><td colspan="8" class="empty">暂无 CDN 条目，点击上方按钮添加</td></tr>
<?php else: foreach ($pageImages as $img):
    $imgLinks = $links->where(['image_id' => $img['id']]);
    $hasValid = false;
    foreach ($imgLinks as $l) { if ($l['status'] === 'active') { $hasValid = true; break; } }
    $folderName = '';
    if (!empty($img['folder_id'])) {
        $f = $folders->find($img['folder_id']);
        $folderName = $f ? $f['name'] : '';
    }
    $displayName = $img['name'];
    $truncName = mb_strlen($displayName) > 15 ? mb_substr($displayName, 0, 15) . '...' : $displayName;
    $displayOrig = $img['original_name'] ?: '-';
    $truncOrig = mb_strlen($displayOrig) > 15 ? mb_substr($displayOrig, 0, 15) . '...' : $displayOrig;
?>
<tr data-image-id="<?= htmlspecialchars($img['id']) ?>">
  <td><input type="checkbox" class="row-check" value="<?= htmlspecialchars($img['id']) ?>" onchange="updateBatchBtns()"></td>
  <td><strong title="<?= htmlspecialchars($displayName) ?>"><?= htmlspecialchars($truncName) ?></strong></td>
  <td style="font-size:12px;color:#888" title="<?= htmlspecialchars($displayOrig) ?>"><?= htmlspecialchars($truncOrig) ?></td>
  <td><?= $img['file_size'] ? ($img['file_size']>1048576 ? round($img['file_size']/1048576,1).'MB' : round($img['file_size']/1024,1).'KB') : '-' ?></td>
  <td style="font-size:12px"><?= htmlspecialchars($img['file_type'] ?: '-') ?></td>
  <td style="font-size:12px;color:#888"><?= htmlspecialchars($folderName ?: '未分类') ?></td>
  <td>
    <!-- 统一链接 -->
    <?php if (!empty($img['unified_slug'])): ?>
    <?php $uniUrl = 'https://imgapi.hiyxin.top/CDN/d/' . $img['unified_slug']; ?>
    <div class="link-row uni-link" style="background:#f0f5ff;border:1px dashed #1677ff;border-radius:4px;padding:4px 6px;margin-bottom:6px">
      <span style="font-size:11px;color:#1677ff;font-weight:bold;white-space:nowrap">统一链接</span>
      <span class="url-txt" onclick="copyUrl('<?= htmlspecialchars($uniUrl) ?>')" title="点击复制"><?= htmlspecialchars($uniUrl) ?></span>
      <button class="btn btn-p btn-xs" onclick="copyUrl('<?= htmlspecialchars($uniUrl) ?>')">复制</button>
    </div>
    <?php endif; ?>
    <?php foreach ($imgLinks as $lk): ?>
    <div class="link-row" id="link-row-<?= $lk['id'] ?>">
      <span class="url-txt" onclick="copyUrl('<?= htmlspecialchars($lk['url']) ?>')" title="点击复制：<?= htmlspecialchars($lk['url']) ?>"><?= htmlspecialchars($lk['label']) ?></span>
      <?php if ($lk['is_primary']): ?><span class="tag tag-p">主</span><?php endif; ?>
      <span class="tag <?= $lk['status']==='active'?'tag-ok':($lk['status']==='invalid'?'tag-fail':'tag-pd') ?>"><?= ['active'=>'有效','invalid'=>'失效','backup'=>'备用','pending'=>'待检测'][$lk['status']] ?></span>
      <button class="btn btn-d btn-xs" onclick="copyUrl('<?= htmlspecialchars($lk['url']) ?>')">复制</button>
      <button class="btn btn-d btn-xs" onclick="submitForm('check_link','link_id','<?= $lk['id'] ?>')">检测</button>
      <?php if (!$lk['is_primary']): ?>
      <button class="btn btn-g btn-xs" onclick="submitForm('set_primary','link_id','<?= $lk['id'] ?>')">设主</button>
      <?php endif; ?>
      <button class="btn btn-d btn-xs" onclick="editLinkInline('<?= $lk['id'] ?>','<?= htmlspecialchars(addslashes($lk['url'])) ?>','<?= htmlspecialchars(addslashes($lk['label'])) ?>')">编辑</button>
      <?php if (!$lk['is_primary']): ?>
      <button class="btn btn-r btn-xs" onclick="if(confirm('确认删除此链接？'))submitForm('delete_link','link_id','<?= $lk['id'] ?>')">删除</button>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <button class="btn btn-d btn-xs" style="margin-top:5px" onclick="showAddLink('<?= $img['id'] ?>')">+ 添加链接</button>
  </td>
  <td>
    <button class="btn btn-p btn-xs" onclick="showDetail('<?= $img['id'] ?>')">详情</button>
    <button class="btn btn-g btn-xs" style="margin-top:4px" onclick="submitForm('download_to_server','image_id','<?= $img['id'] ?>')">下载到服务器</button>
    <button class="btn btn-d btn-xs" style="margin-top:4px" onclick="showEditItem('<?= $img['id'] ?>')">属性/编辑</button>
    <button class="btn btn-w btn-xs" style="margin-top:4px" onclick="submitForm('refresh_item','image_id','<?= $img['id'] ?>')">重新获取</button>
    <button class="btn btn-d btn-xs" style="margin-top:4px" onclick="downloadLocal('<?= $img['id'] ?>')">下载至本地</button>
    <button class="btn btn-r btn-xs" style="margin-top:4px" onclick="if(confirm('确认删除此 CDN 条目及所有链接？'))submitForm('delete_image','image_id','<?= $img['id'] ?>')">删除</button>
  </td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>

<?php if ($totalPages > 1): ?>
<div class="pagination">
  <?php
  $f = htmlspecialchars($currentFolder);
  $pp = $perPage;
  if ($page > 1): ?>
    <a href="?page=<?=($page-1)?>&per_page=<?=$pp?>&folder=<?=$f?>">上一页</a>
  <?php else: ?>
    <span class="disabled">上一页</span>
  <?php endif;
  if ($totalPages <= 7): 
    for ($i=1;$i<=$totalPages;$i++):
      if ($i==$page): ?><span class="active"><?=$i?></span><?php else: ?><a href="?page=<?=$i?>&per_page=<?=$pp?>&folder=<?=$f?>"><?=$i?></a><?php endif;
    endfor;
  else:
    $pages = [1];
    if ($page > 3) $pages[] = '...';
    for ($i=max(2,$page-1);$i<=min($totalPages-1,$page+1);$i++) $pages[] = $i;
    if ($page < $totalPages - 2) $pages[] = '...';
    $pages[] = $totalPages;
    foreach ($pages as $p):
      if ($p === '...'): ?><span>...</span><?php 
      elseif ($p == $page): ?><span class="active"><?=$p?></span><?php 
      else: ?><a href="?page=<?=$p?>&per_page=<?=$pp?>&folder=<?=$f?>"><?=$p?></a><?php endif;
    endforeach;
  endif;
  if ($page < $totalPages): ?>
    <a href="?page=<?=($page+1)?>&per_page=<?=$pp?>&folder=<?=$f?>">下一页</a>
  <?php else: ?>
    <span class="disabled">下一页</span>
  <?php endif; ?>
  <span style="margin-left:12px">每页
    <?php foreach ([20,50,100,200] as $n): ?>
      <?php if ($n==$pp): ?><span class="active"><?=$n?></span><?php else: ?><a href="?page=1&per_page=<?=$n?>&folder=<?=$f?>"><?=$n?></a><?php endif; ?>
    <?php endforeach; ?>条
  </span>
</div>
<?php endif; ?>
</div>
</div>
</div>

<!-- 隐藏表单 -->
<form method="post" id="actionForm" style="display:none">
  <input type="hidden" name="action" id="afAction">
  <input type="hidden" name="image_id" id="afImageId">
  <input type="hidden" name="link_id" id="afLinkId">
  <input type="hidden" name="folder_id" id="afFolderId">
  <input type="hidden" name="folder_name" id="afFolderName">
  <input type="hidden" name="ids" id="afIds">
  <input type="hidden" name="name" id="afName">
  <input type="hidden" name="original_name" id="afOrigName">
  <input type="hidden" name="file_type" id="afFileType">
  <input type="hidden" name="dl_folder" id="afDlFolder">
</form>

<!-- URL 添加弹窗 -->
<div class="modal-o" id="urlModal"><div class="modal">
<h3>URL 添加 CDN 分发</h3>
<form method="post"><input type="hidden" name="action" value="add_url">
  <div class="fg"><label>分发 URL *</label><input type="url" name="url" required placeholder="https://..."></div>
  <div class="fg-row">
    <div class="fg"><label>显示名称</label><input type="text" name="name" placeholder="留空自动提取文件名"></div>
    <div class="fg"><label>链接标签</label><input type="text" name="label" value="分发链接" placeholder="CDN/图床1"></div>
  </div>
  <div class="fg"><label>文件夹</label><select name="folder_id"><option value="">未分类</option><?php foreach ($allFolders as $f): ?><option value="<?= htmlspecialchars($f['id']) ?>"><?= htmlspecialchars($f['name']) ?></option><?php endforeach; ?></select></div>
  <div class="modal-btns">
    <button type="submit" class="btn btn-p">添加</button>
    <button type="button" class="btn btn-d" onclick="closeModal('urlModal')">取消</button>
  </div>
</form></div></div>

<!-- 自定义添加弹窗 -->
<div class="modal-o" id="customModal"><div class="modal">
<h3>自定义添加 CDN 条目</h3>
<form method="post"><input type="hidden" name="action" value="add_custom">
  <div class="fg-row">
    <div class="fg"><label>名称 *</label><input type="text" name="name" required placeholder="CDN 文件名称"></div>
    <div class="fg"><label>类型</label><input type="text" name="file_type" placeholder="如 pdf / zip / mp4"></div>
  </div>
  <div class="fg"><label>原始文件名</label><input type="text" name="original_name" placeholder="原始文件名（可选）"></div>
  <div class="fg"><label>分发链接</label><input type="url" name="link_url" placeholder="https://...（可选）"></div>
  <div class="fg"><label>链接标签</label><input type="text" name="link_label" placeholder="标签（可选）"></div>
  <div class="fg"><label>文件夹</label><select name="folder_id"><option value="">未分类</option><?php foreach ($allFolders as $f): ?><option value="<?= htmlspecialchars($f['id']) ?>"><?= htmlspecialchars($f['name']) ?></option><?php endforeach; ?></select></div>
  <div class="modal-btns">
    <button type="submit" class="btn btn-p">创建</button>
    <button type="button" class="btn btn-d" onclick="closeModal('customModal')">取消</button>
  </div>
</form></div></div>

<!-- 添加链接弹窗 -->
<div class="modal-o" id="linkModal"><div class="modal">
<h3>添加备用链接</h3>
<form method="post"><input type="hidden" name="action" value="add_link">
  <input type="hidden" name="image_id" id="linkImgId">
  <div class="fg"><label>链接 URL *</label><input type="url" name="url" required placeholder="https://..."></div>
  <div class="fg"><label>标签</label><input type="text" name="label" value="备用" placeholder="备用/CDN/图床2"></div>
  <div class="modal-btns">
    <button type="submit" class="btn btn-p">添加</button>
    <button type="button" class="btn btn-d" onclick="closeModal('linkModal')">取消</button>
  </div>
</form></div></div>

<!-- 属性/编辑弹窗 -->
<div class="modal-o" id="editModal"><div class="modal">
<h3>编辑 CDN 条目属性</h3>
<div class="fg"><label>名称</label><input type="text" id="editName" onchange="editFieldChanged()"></div>
<div class="fg"><label>原始文件名</label><input type="text" id="editOrigName" onchange="editFieldChanged()"></div>
<div class="fg"><label>类型</label><input type="text" id="editFileType" onchange="editFieldChanged()"></div>
<div class="fg"><label>文件夹</label><select id="editFolderId" onchange="editFieldChanged()"><option value="">未分类</option><?php foreach ($allFolders as $f): ?><option value="<?= htmlspecialchars($f['id']) ?>"><?= htmlspecialchars($f['name']) ?></option><?php endforeach; ?></select></div>
<div class="fg"><label>文件大小 (字节)</label><input type="number" id="editFileSize" placeholder="手动输入" onchange="editFieldChanged()"></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" id="editSaveBtn" onclick="saveEdit()">保存</button>
  <button type="button" class="btn btn-d" onclick="closeModal('editModal')">取消</button>
</div>
</div></div>

<!-- 详情弹窗 -->
<div class="modal-o" id="detailModal"><div class="modal wide">
<h3>CDN 条目详情</h3>
<div class="detail-layout">
  <div class="detail-info" id="detailInfo"></div>
</div>
<div class="modal-btns">
  <button type="button" class="btn btn-d" onclick="closeModal('detailModal')">关闭</button>
</div>
</div></div>

<!-- 批量复制弹窗 -->
<div class="modal-o" id="batchCopyModal"><div class="modal wide">
<h3>批量复制链接</h3>
<p style="font-size:12px;color:#999;margin-bottom:12px">为每个 CDN 条目选择一个链接，点击按钮复制全部选中链接（每行一个URL）</p>
<div class="batch-header">
  <label style="font-size:12px;cursor:pointer"><input type="checkbox" id="batchCopySelectAll" onchange="toggleAllCopyCheck(this)"> 全选</label>
  <span style="margin-left:auto;font-size:12px;color:#999">默认选择：最佳链接</span>
</div>
<div class="batch-list" id="batchCopyList"></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doBatchCopy()">一键复制选中链接</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchCopyModal')">取消</button>
</div>
</div></div>

<!-- 批量下载弹窗 -->
<div class="modal-o" id="batchDownloadModal"><div class="modal wide">
<h3>批量下载（服务器缓存）</h3>
<p style="font-size:12px;color:#999;margin-bottom:12px">勾选条目，批量下载至服务器缓存目录 Stock/CDN/down</p>
<div class="fg" style="margin-bottom:10px">
  <label>目标文件夹名称</label>
  <input type="text" id="batchDlFolderName" placeholder="默认使用第一个条目的名称新建文件夹" style="flex:1;padding:6px 10px;border:1px solid #d9d9d9;border-radius:4px">
</div>
<div class="batch-header">
  <label style="font-size:12px;cursor:pointer"><input type="checkbox" id="batchDlSelectAll" onchange="toggleAllDlCheck(this)"> 全选</label>
  <span style="font-size:12px;color:#999">当前筛选共 <span id="batchDlCount">0</span> 条</span>
</div>
<div class="batch-list" id="batchDownloadList" style="max-height:250px"></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doBatchDownload()">开始批量下载</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchDownloadModal')">取消</button>
</div>
</div></div>

<!-- 批量下载至本地弹窗 -->
<div class="modal-o" id="batchDlLocalModal"><div class="modal wide">
<h3>批量下载至本地</h3>
<p style="font-size:12px;color:#999;margin-bottom:12px">勾选条目，逐个下载至本地</p>
<div class="batch-header">
  <label style="font-size:12px;cursor:pointer"><input type="checkbox" id="batchDlLocalSelectAll" onchange="toggleAllDlLocalCheck(this)"> 全选</label>
</div>
<div class="batch-list" id="batchDlLocalList" style="max-height:250px"></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doBatchDownloadLocal()">开始下载</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchDlLocalModal')">取消</button>
</div>
</div></div>

<!-- 批量移动弹窗 -->
<div class="modal-o" id="batchMoveModal"><div class="modal">
<h3>移动到文件夹</h3>
<div class="fg"><label>目标文件夹</label><select id="batchMoveTarget"><option value="">未分类</option><?php foreach ($allFolders as $f): ?><option value="<?= htmlspecialchars($f['id']) ?>"><?= htmlspecialchars($f['name']) ?></option><?php endforeach; ?></select></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doBatchMove()">移动</button>
  <button type="button" class="btn btn-d" onclick="closeModal('batchMoveModal')">取消</button>
</div>
</div></div>

<!-- 链接编辑弹窗 -->
<div class="modal-o" id="editLinkModal"><div class="modal">
<h3>编辑链接</h3>
<input type="hidden" id="editLinkId">
<div class="fg"><label>URL</label><input type="url" id="editLinkUrl" required></div>
<div class="fg"><label>标签</label><input type="text" id="editLinkLabel"></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="saveLinkEdit()">保存</button>
  <button type="button" class="btn btn-d" onclick="closeModal('editLinkModal')">取消</button>
</div>
</div></div>

<!-- 重命名弹窗 -->
<div class="modal-o" id="renameModal"><div class="modal">
<h3>重命名文件夹</h3>
<input type="hidden" id="renameFolderId">
<div class="fg"><label>新名称</label><input type="text" id="renameFolderName" required></div>
<div class="modal-btns">
  <button type="button" class="btn btn-p" onclick="doRename()">确认</button>
  <button type="button" class="btn btn-d" onclick="closeModal('renameModal')">取消</button>
</div>
</div></div>

<script>
const cdnDataMap = <?= json_encode($cdnDataMap, JSON_UNESCAPED_UNICODE) ?>;
const allFolders = <?= json_encode($allFolders, JSON_UNESCAPED_UNICODE) ?>;

// 批量添加
function toggleBatchAdd() {
    var el = document.getElementById('batchAddArea');
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
function batchAdd() {
    var input = document.getElementById('batchInput').value.trim();
    if (!input) { alert('请输入内容'); return; }
    var lines = input.split('\n').filter(function(l){ return l.trim(); });
    var items = [];
    var errors = [];
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        var nameMatch = line.match(/^(.+?)\s*\[/);
        if (!nameMatch) { errors.push('第' + (i+1) + '行格式错误：找不到名称'); continue; }
        var name = nameMatch[1].trim();
        var urlMatches = line.match(/\[([^\]]+)\]/g);
        if (!urlMatches || urlMatches.length === 0) { errors.push('第' + (i+1) + '行：缺少 [链接]'); continue; }
        var urls = urlMatches.map(function(m){ return m.slice(1, -1).trim(); });
        var primaryUrl = urls[0];
        var backupUrl = urls.length > 1 ? urls[1] : '';
        if (!/^https?:\/\/.+/.test(primaryUrl)) { errors.push('第' + (i+1) + '行：主链接格式无效'); continue; }
        if (backupUrl && !/^https?:\/\/.+/.test(backupUrl)) { errors.push('第' + (i+1) + '行：备用链接格式无效'); continue; }
        items.push({name: name, primary_url: primaryUrl, backup_url: backupUrl});
    }
    if (errors.length > 0) {
        alert('以下行有错误：\n' + errors.join('\n'));
        if (items.length === 0) return;
        if (!confirm('共 ' + items.length + ' 条格式正确，是否继续添加？（错误行将跳过）')) return;
    }
    if (items.length === 0) { alert('没有有效的条目'); return; }
    var fd = new FormData();
    fd.append('action', 'batch_add');
    fd.append('items', JSON.stringify(items));
    var btn = document.querySelector('#batchAddArea .btn-p');
    var result = document.getElementById('batchResult');
    btn.disabled = true;
    btn.textContent = '添加中...';
    result.textContent = '';
    fetch('', {method:'POST', body:fd})
        .then(function(r){return r.json()})
        .then(function(d){
            btn.disabled = false;
            btn.textContent = '批量添加';
            if (d.success) {
                result.innerHTML = '<span style="color:#52c41a">成功添加 ' + d.count + ' 条</span>';
                setTimeout(function(){ location.reload(); }, 1000);
            } else {
                result.innerHTML = '<span style="color:#ff4d4f">' + (d.message || '失败') + '</span>';
            }
        })
        .catch(function(){
            btn.disabled = false;
            btn.textContent = '批量添加';
            result.innerHTML = '<span style="color:#ff4d4f">请求失败</span>';
        });
}

// 隐藏表单提交
function submitForm(action, key, val) {
    document.getElementById('afAction').value = action;
    if (key === 'image_id') document.getElementById('afImageId').value = val;
    if (key === 'link_id') document.getElementById('afLinkId').value = val;
    if (key === 'folder_id') document.getElementById('afFolderId').value = val;
    if (key === 'folder_name') document.getElementById('afFolderName').value = val;
    document.getElementById('actionForm').submit();
}

// 弹窗控制
function showModal(id) { document.getElementById(id).classList.add('show'); }
function closeModal(id) { document.getElementById(id).classList.remove('show'); }

// 复制 URL
function copyUrl(url) {
    navigator.clipboard.writeText(url).then(() => {
        alert('链接已复制到剪贴板');
    }).catch(() => {
        prompt('手动复制：', url);
    });
}

// 过滤表格
function filterTable() {
    const kw = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#cdnTable tbody tr');
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = kw ? (text.includes(kw) ? '' : 'none') : '';
    });
}

// 全选/取消全选
function toggleAllRows(cb) {
    document.querySelectorAll('#cdnTable .row-check').forEach(c => { c.checked = cb.checked; });
    updateBatchBtns();
}

function updateBatchBtns() {
    const checked = document.querySelectorAll('#cdnTable .row-check:checked');
    const show = checked.length ? '' : 'none';
    document.getElementById('batchDeleteBtn').style.display = show;
    document.getElementById('batchMoveBtn').style.display = show;
    document.getElementById('batchDlServerBtn').style.display = show;
    document.getElementById('batchDlLocalBtn').style.display = show;
}

// 批量删除
function batchDelete() {
    const ids = Array.from(document.querySelectorAll('#cdnTable .row-check:checked')).map(c => c.value);
    if (!ids.length) return;
    if (!confirm('确认删除选中的 ' + ids.length + ' 条 CDN 条目？')) return;
    document.getElementById('afAction').value = 'batch_delete';
    document.getElementById('afIds').value = JSON.stringify(ids);
    document.getElementById('actionForm').submit();
}

// 批量移动
function showBatchMove() {
    const ids = Array.from(document.querySelectorAll('#cdnTable .row-check:checked')).map(c => c.value);
    if (!ids.length) return;
    document.getElementById('afIds').value = JSON.stringify(ids);
    showModal('batchMoveModal');
}
function doBatchMove() {
    document.getElementById('afAction').value = 'batch_move';
    document.getElementById('afFolderId').value = document.getElementById('batchMoveTarget').value;
    document.getElementById('actionForm').submit();
}

// 添加链接
function showAddLink(imageId) {
    document.getElementById('linkImgId').value = imageId;
    showModal('linkModal');
}

// 编辑链接
function editLinkInline(linkId, url, label) {
    document.getElementById('editLinkId').value = linkId;
    document.getElementById('editLinkUrl').value = url;
    document.getElementById('editLinkLabel').value = label;
    showModal('editLinkModal');
}
function saveLinkEdit() {
    document.getElementById('afAction').value = 'edit_link';
    document.getElementById('afLinkId').value = document.getElementById('editLinkId').value;
    const form = document.getElementById('actionForm');
    const d1 = document.createElement('input'); d1.type='hidden'; d1.name='url'; d1.value = document.getElementById('editLinkUrl').value; form.appendChild(d1);
    const d2 = document.createElement('input'); d2.type='hidden'; d2.name='label'; d2.value = document.getElementById('editLinkLabel').value; form.appendChild(d2);
    form.submit();
}

// 详情
function showDetail(imageId) {
    const d = cdnDataMap[imageId];
    if (!d) return;
    let html = '<table>';
    html += '<tr><td class="attr-label">名称</td><td>' + esc(d.name) + '</td></tr>';
    html += '<tr><td class="attr-label">原始文件名</td><td>' + esc(d.original_name || '-') + '</td></tr>';
    html += '<tr><td class="attr-label">大小</td><td>' + (d.file_size ? (d.file_size > 1048576 ? (d.file_size/1048576).toFixed(1) + 'MB' : (d.file_size/1024).toFixed(1) + 'KB') : '-') + '</td></tr>';
    html += '<tr><td class="attr-label">类型</td><td>' + esc(d.file_type || '-') + '</td></tr>';
    html += '<tr><td class="attr-label">文件夹</td><td>' + esc(d.folder_name || '未分类') + '</td></tr>';
    html += '</table>';
    if (d.links && d.links.length) {
        html += '<h4 style="margin-bottom:8px">分发链接 (' + d.links.length + ')</h4>';
        html += '<table>';
        d.links.forEach(l => {
            const statusMap = {active:'有效',invalid:'失效',backup:'备用',pending:'待检测'};
            html += '<tr><td>' + esc(l.label) + (l.is_primary ? ' <span class="tag tag-p">主</span>' : '') + '</td>';
            html += '<td><span class="tag ' + (l.status==='active'?'tag-ok':(l.status==='invalid'?'tag-fail':(l.status==='pending'?'tag-pd':'tag-bk'))) + '">' + (statusMap[l.status]||l.status) + '</span></td>';
            html += '<td style="font-size:12px;word-break:break-all">' + esc(l.url) + '</td></tr>';
        });
        html += '</table>';
    }
    document.getElementById('detailInfo').innerHTML = html;
    showModal('detailModal');
}

function esc(s) {
    if (!s) return '';
    s = String(s);
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// 编辑条目属性
let editingImageId = null;
function showEditItem(imageId) {
    editingImageId = imageId;
    const d = cdnDataMap[imageId];
    if (!d) return;
    document.getElementById('editName').value = d.name || '';
    document.getElementById('editOrigName').value = d.original_name || '';
    document.getElementById('editFileType').value = d.file_type || '';
    document.getElementById('editFolderId').value = d.folder_id || '';
    document.getElementById('editFileSize').value = d.file_size || '';
    showModal('editModal');
}
function editFieldChanged() {
    // no-op, save handles all
}
function saveEdit() {
    const form = document.getElementById('actionForm');
    document.getElementById('afAction').value = 'edit_item';
    document.getElementById('afImageId').value = editingImageId;
    document.getElementById('afName').value = document.getElementById('editName').value;
    document.getElementById('afOrigName').value = document.getElementById('editOrigName').value;
    document.getElementById('afFileType').value = document.getElementById('editFileType').value;
    document.getElementById('afFolderId').value = document.getElementById('editFolderId').value;
    // 添加 file_size 隐藏字段
    let fsInput = form.querySelector('input[name="file_size"]');
    if (!fsInput) { fsInput = document.createElement('input'); fsInput.type = 'hidden'; fsInput.name = 'file_size'; form.appendChild(fsInput); }
    fsInput.value = document.getElementById('editFileSize').value;
    form.submit();
}

// 下载至本地
function downloadLocal(imageId) {
    const d = cdnDataMap[imageId];
    if (!d) return;
    const imgLinks = d.links || [];
    if (imgLinks.length === 0) { alert('没有可用链接'); return; }
    let bestUrl = '';
    for (const l of imgLinks) { if (l.status === 'active') { bestUrl = l.url; break; } }
    if (!bestUrl) bestUrl = imgLinks[0].url;
    if (!bestUrl) { alert('没有可用链接'); return; }
    const a = document.createElement('a');
    a.href = bestUrl;
    a.download = d.original_name || d.name || 'download';
    a.target = '_blank';
    a.click();
}

// 批量复制
let batchCopyIds = [];
function showBatchCopy() {
    const visibleRows = Array.from(document.querySelectorAll('#cdnTable tbody tr')).filter(r => r.style.display !== 'none' && r.getAttribute('data-image-id'));
    batchCopyIds = visibleRows.map(r => r.getAttribute('data-image-id'));
    if (!batchCopyIds.length) { alert('当前无 CDN 条目'); return; }
    let html = '';
    batchCopyIds.forEach(id => {
        const d = cdnDataMap[id];
        if (!d) return;
        const imgLinks = d.links || [];
        let bestUrl = '', bestId = '';
        for (const l of imgLinks) { if (l.status === 'active') { bestUrl = l.url; bestId = l.id; break; } }
        if (!bestUrl && imgLinks.length) { bestUrl = imgLinks[0].url; bestId = imgLinks[0].id; }
        let opts = imgLinks.map(l => '<option value="' + l.id + '" ' + (l.id === bestId ? 'selected' : '') + '>' + esc(l.label) + ' (' + (l.status === 'active' ? '有效' : l.status === 'invalid' ? '失效' : '备用') + ')</option>').join('');
        if (!opts) opts = '<option value="">无链接</option>';
        html += '<div class="batch-row"><input type="checkbox" class="batch-copy-check" value="' + id + '" checked onchange="updateCopySelectAll()"><label>' + esc(d.name) + '</label><select class="batch-copy-select">' + opts + '</select></div>';
    });
    document.getElementById('batchCopyList').innerHTML = html;
    document.getElementById('batchCopySelectAll').checked = true;
    showModal('batchCopyModal');
}
function toggleAllCopyCheck(cb) {
    document.querySelectorAll('.batch-copy-check').forEach(c => { c.checked = cb.checked; });
}
function updateCopySelectAll() {
    const all = document.querySelectorAll('.batch-copy-check');
    const checked = document.querySelectorAll('.batch-copy-check:checked');
    document.getElementById('batchCopySelectAll').checked = checked.length === all.length;
}
function doBatchCopy() {
    const rows = document.querySelectorAll('#batchCopyList .batch-row');
    const urls = [];
    rows.forEach(row => {
        const cb = row.querySelector('.batch-copy-check');
        if (!cb.checked) return;
        const sel = row.querySelector('.batch-copy-select');
        const linkId = sel.value;
        if (!linkId) return;
        const imgId = cb.value;
        const d = cdnDataMap[imgId];
        if (!d) return;
        const lk = (d.links || []).find(l => l.id === linkId);
        if (lk) urls.push(lk.url);
    });
    if (!urls.length) { alert('没有选中任何链接'); return; }
    navigator.clipboard.writeText(urls.join('\n')).then(() => {
        alert('已复制 ' + urls.length + ' 个链接');
        closeModal('batchCopyModal');
    }).catch(() => {
        prompt('手动复制（每行一个URL）：', urls.join('\n'));
        closeModal('batchCopyModal');
    });
}

// 批量下载（服务器缓存）
function showBatchDownload() {
    const visibleRows = Array.from(document.querySelectorAll('#cdnTable tbody tr')).filter(r => r.style.display !== 'none' && r.getAttribute('data-image-id'));
    const ids = visibleRows.map(r => r.getAttribute('data-image-id'));
    if (!ids.length) { alert('当前无 CDN 条目'); return; }
    document.getElementById('batchDlCount').textContent = ids.length;
    let html = '';
    ids.forEach(id => {
        const d = cdnDataMap[id];
        if (!d) return;
        html += '<div class="batch-row"><input type="checkbox" class="batch-dl-check" value="' + id + '" checked onchange="updateDlSelectAll()"><label>' + esc(d.name) + '</label></div>';
    });
    document.getElementById('batchDownloadList').innerHTML = html;
    document.getElementById('batchDlSelectAll').checked = true;
    showModal('batchDownloadModal');
}
function toggleAllDlCheck(cb) {
    document.querySelectorAll('.batch-dl-check').forEach(c => { c.checked = cb.checked; });
}
function updateDlSelectAll() {
    const all = document.querySelectorAll('.batch-dl-check');
    const checked = document.querySelectorAll('.batch-dl-check:checked');
    document.getElementById('batchDlSelectAll').checked = checked.length === all.length;
}
function doBatchDownload() {
    const ids = Array.from(document.querySelectorAll('.batch-dl-check:checked')).map(c => c.value);
    if (!ids.length) { alert('没有选中任何条目'); return; }
    // Get folder name from input, fallback to first item's name
    let folderName = document.getElementById('batchDlFolderName').value.trim();
    if (!folderName && ids.length > 0 && cdnDataMap[ids[0]]) {
        folderName = cdnDataMap[ids[0]].name;
    }
    document.getElementById('afDlFolder').value = folderName;
    closeModal('batchDownloadModal');
    downloadNext(ids, 0);
}
function downloadNext(ids, idx) {
    if (idx >= ids.length) {
        alert('批量下载完成');
        location.reload();
        return;
    }
    document.getElementById('afAction').value = 'download_to_server';
    document.getElementById('afImageId').value = ids[idx];
    const form = document.getElementById('actionForm');
    fetch('', { method: 'POST', body: new URLSearchParams(new FormData(form)) })
        .then(() => { setTimeout(() => downloadNext(ids, idx + 1), 500); })
        .catch(() => { setTimeout(() => downloadNext(ids, idx + 1), 500); });
}

// 批量下载至本地
let batchDlLocalIds = [];
function showBatchDownloadLocal() {
    const visibleRows = Array.from(document.querySelectorAll('#cdnTable tbody tr')).filter(r => r.style.display !== 'none' && r.getAttribute('data-image-id'));
    batchDlLocalIds = visibleRows.map(r => r.getAttribute('data-image-id'));
    if (!batchDlLocalIds.length) { alert('当前无 CDN 条目'); return; }
    let html = '';
    batchDlLocalIds.forEach(id => {
        const d = cdnDataMap[id];
        if (!d) return;
        html += '<div class="batch-row"><input type="checkbox" class="batch-dllocal-check" value="' + id + '" checked onchange="updateDlLocalSelectAll()"><label>' + esc(d.name) + '</label></div>';
    });
    document.getElementById('batchDlLocalList').innerHTML = html;
    document.getElementById('batchDlLocalSelectAll').checked = true;
    showModal('batchDlLocalModal');
}
function toggleAllDlLocalCheck(cb) {
    document.querySelectorAll('.batch-dllocal-check').forEach(c => { c.checked = cb.checked; });
}
function updateDlLocalSelectAll() {
    const all = document.querySelectorAll('.batch-dllocal-check');
    const checked = document.querySelectorAll('.batch-dllocal-check:checked');
    document.getElementById('batchDlLocalSelectAll').checked = checked.length === all.length;
}
function doBatchDownloadLocal() {
    const ids = Array.from(document.querySelectorAll('.batch-dllocal-check:checked')).map(c => c.value);
    if (!ids.length) { alert('没有选中任何条目'); return; }
    ids.forEach(id => { downloadLocal(id); });
    closeModal('batchDlLocalModal');
}

// 文件夹重命名
function startRename(fid, name) {
    document.getElementById('renameFolderId').value = fid;
    document.getElementById('renameFolderName').value = name;
    showModal('renameModal');
}
function doRename() {
    document.getElementById('afAction').value = 'folder_rename';
    document.getElementById('afFolderId').value = document.getElementById('renameFolderId').value;
    document.getElementById('afFolderName').value = document.getElementById('renameFolderName').value;
    document.getElementById('actionForm').submit();
}

// 页面加载时清除残留参数
(function(){
    if (window.performance && window.performance.navigation.type === 1) {
        if (window.location.search) {
            window.history.replaceState(null, '', window.location.pathname + '?' + (new URLSearchParams(window.location.search).toString()));
        }
    }
})();

window.addEventListener('message', function(e) {
    if (e.data && e.data.type === 'cdn-refresh') {
        location.reload();
    }
});
</script>
</body>
</html>

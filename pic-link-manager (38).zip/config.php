<?php
define('SYS_VERSION', '2.0');
define('BASE_PATH', __DIR__);
define('DATA_PATH', BASE_PATH . '/data');
define('STOCK_PATH', BASE_PATH . '/Stock');
define('TEMP_PATH', STOCK_PATH . '/temp');
define('DOWNLOAD_PATH', STOCK_PATH . '/systemtmp');

// 面板名称：优先从安装配置读取，否则默认「图链管理」
define('FILE_SETTINGS', DATA_PATH . '/settings.json');
$_settings = file_exists(FILE_SETTINGS) ? json_decode(file_get_contents(FILE_SETTINGS), true) : null;
define('SYS_NAME', ($_settings['panel_name'] ?? '') ?: '图链管理');
unset($_settings);

define('CACHE_MAX_SIZE', 5368709120);
define('CACHE_TTL', 86400);
define('SITE_URL', rtrim((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['SCRIPT_NAME']), '/'));

ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
session_start();
date_default_timezone_set('Asia/Shanghai');

define('FILE_USERS', DATA_PATH . '/users.json');
define('FILE_IMAGES', DATA_PATH . '/images.json');
define('FILE_LINKS', DATA_PATH . '/links.json');
define('FILE_FOLDERS', DATA_PATH . '/folders.json');
define('CHECK_TIMEOUT', 10);

// CDN 分发
define('CDN_PATH', STOCK_PATH . '/CDN');
define('CDN_TMP_PATH', CDN_PATH . '/tmp');
define('CDN_DOWN_PATH', CDN_PATH . '/down');
define('FILE_CDN_IMAGES', DATA_PATH . '/cdn_images.json');
define('FILE_CDN_LINKS', DATA_PATH . '/cdn_links.json');
define('FILE_CDN_FOLDERS', DATA_PATH . '/cdn_folders.json');
define('CDN_CACHE_MAX', 10737418240); // 10GB
define('CDN_TTL', 172800); // 48h

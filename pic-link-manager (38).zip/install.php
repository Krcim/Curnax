<?php
/**
 * 安装向导 — 初始化数据目录和默认配置
 * 安装完成后删除此文件
 */
require_once __DIR__ . '/config.php';

$step = $_GET['step'] ?? 1;
$error = '';
$installed = file_exists(FILE_SETTINGS);

if ($installed && $step != 'done') {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>安装 - <?= SYS_NAME ?></title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI','Microsoft YaHei',sans-serif;background:linear-gradient(135deg,#7c3aed,#a855f7,#ec4899);min-height:100vh;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
/* 波浪动画 */
body::before,body::after{content:'';position:absolute;bottom:-80px;left:-50%;width:200%;height:200px;background:rgba(255,255,255,.15);border-radius:45%;animation:wave 8s linear infinite}
body::after{bottom:-100px;animation-duration:12s;animation-direction:reverse;opacity:.1}
@keyframes wave{0%{transform:translateX(0) translateY(0) rotate(0deg)}50%{transform:translateX(-3%) translateY(-15px) rotate(2deg)}100%{transform:translateX(0) translateY(0) rotate(0deg)}}
.card{background:rgba(255,255,255,.92);backdrop-filter:blur(10px);border-radius:16px;box-shadow:0 8px 32px rgba(0,0,0,.15);padding:44px 40px;width:500px;max-width:90%;position:relative;z-index:1;border:1px solid rgba(255,255,255,.3)}
h1{font-size:26px;color:#5b21b6;margin-bottom:8px;display:flex;align-items:center;gap:10px}
h1 .emoji{font-size:30px}
.sub{color:#a78bfa;font-size:14px;margin-bottom:28px}
.form-group{margin-bottom:18px}
label{display:block;font-size:14px;color:#4c1d95;margin-bottom:6px;font-weight:500}
input[type=text],input[type=password],input[type=email]{width:100%;padding:11px 14px;border:2px solid #e9d5ff;border-radius:8px;font-size:14px;transition:all .2s;background:#faf5ff}
input:focus{outline:none;border-color:#a855f7;box-shadow:0 0 0 3px rgba(168,85,247,.15);background:#fff}
.btn{display:block;width:100%;padding:12px;background:linear-gradient(135deg,#7c3aed,#a855f7);color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:all .2s;letter-spacing:0.5px}
.btn:hover{background:linear-gradient(135deg,#6d28d9,#9333ea);transform:translateY(-1px);box-shadow:0 4px 16px rgba(124,58,237,.4)}
.btn:disabled{background:#d9d9d9;cursor:not-allowed;transform:none;box-shadow:none}
.error{background:#fff2f0;border:1px solid #ffccc7;color:#ff4d4f;padding:10px 14px;border-radius:8px;margin-bottom:18px;font-size:14px}
.success{background:#f0fdf4;border:1px solid #bbf7d0;color:#16a34a;padding:10px 14px;border-radius:8px;margin-bottom:18px;font-size:14px}
table{width:100%;font-size:14px;margin-bottom:28px;border-collapse:collapse}
table td{padding:8px 0;border-bottom:1px solid #f3e8ff}
table td:last-child{text-align:right}
</style>
</head>
<body>
<div class="card">

<?php if ($step == 1): ?>
<h1>系统安装</h1>
<p class="sub"><?= SYS_NAME ?> v<?= SYS_VERSION ?></p>
<?php
$checks = [];
// 检查PHP版本
$checks[] = ['name' => 'PHP版本 >= 7.4', 'ok' => version_compare(PHP_VERSION, '7.4', '>='), 'info' => PHP_VERSION];
// 检查curl
$checks[] = ['name' => 'cURL 扩展', 'ok' => function_exists('curl_init')];
// 检查JSON
$checks[] = ['name' => 'JSON 扩展', 'ok' => function_exists('json_encode')];
// 检查data目录可写
$dw = is_dir(DATA_PATH) ? is_writable(DATA_PATH) : is_writable(dirname(DATA_PATH));
$checks[] = ['name' => '数据目录可写', 'ok' => $dw, 'info' => DATA_PATH];
// 检查Stock缓存目录可写
$sw = is_dir(STOCK_PATH) ? is_writable(STOCK_PATH) : is_writable(dirname(STOCK_PATH));
$checks[] = ['name' => '缓存目录可写', 'ok' => $sw, 'info' => STOCK_PATH];

$allOk = true;
foreach ($checks as $c) { if (!$c['ok']) $allOk = false; }
?>
<table style="width:100%;font-size:14px;margin-bottom:24px">
<?php foreach ($checks as $c): ?>
<tr>
  <td style="padding:6px 0"><?= $c['name'] ?></td>
  <td style="text-align:right;color:<?= $c['ok'] ? '#52c41a' : '#ff4d4f' ?>">
    <?= $c['ok'] ? '✓' : '✗' ?>
    <?= $c['info'] ?? '' ?>
  </td>
</tr>
<?php endforeach; ?>
</table>
<form method="get">
  <input type="hidden" name="step" value="2">
  <button type="submit" class="btn" <?= !$allOk ? 'disabled' : '' ?>>下一步：创建管理员</button>
</form>
<?php if (!$allOk): ?>
<div class="error">请先解决以上问题再继续</div>
<?php endif; ?>

<?php elseif ($step == 2):

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $panel_name = trim($_POST['panel_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';
    if (strlen($username) < 3) $error = '用户名至少3个字符';
    elseif (strlen($password) < 6) $error = '密码至少6个字符';
    elseif ($password !== $password2) $error = '两次密码不一致';
    else {
        // 确保目录存在
        if (!is_dir(DATA_PATH)) mkdir(DATA_PATH, 0755, true);
        if (!is_dir(STOCK_PATH)) mkdir(STOCK_PATH, 0755, true);
        if (!is_dir(TEMP_PATH)) mkdir(TEMP_PATH, 0755, true);

        require_once __DIR__ . '/includes/Storage.php';
        require_once __DIR__ . '/includes/Auth.php';

        $auth = new Auth();
        $result = $auth->register($username, $password, '');
        if ($result['ok']) {
            // 写入安装标志
            file_put_contents(FILE_SETTINGS, json_encode([
                'installed' => true,
                'installed_at' => date('Y-m-d H:i:s'),
                'version' => SYS_VERSION,
            ]));
            header('Location: install.php?step=done');
            exit;
        } else {
            $error = $result['msg'];
        }
    }
}
?>
<h1>创建管理员</h1>
<p class="sub">设置管理员账号和面板信息</p>
<?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
  <div class="form-group">
    <label>面板名称</label>
    <input type="text" name="panel_name" placeholder="不填则默认为「图链管理」" value="图链管理">
  </div>
  <div class="form-group">
    <label>用户名</label>
    <input type="text" name="username" required minlength="3">
  </div>
  <div class="form-group">
    <label>密码</label>
    <input type="password" name="password" required minlength="6">
  </div>
  <div class="form-group">
    <label>确认密码</label>
    <input type="password" name="password2" required minlength="6">
  </div>
  <button type="submit" class="btn">完成安装</button>
</form>

<?php elseif ($step == 'done'): ?>
<h1><span class="emoji">✅</span> 安装完成</h1>
<div class="success">系统已成功安装，请删除 install.php 文件以确保安全</div>
<p style="margin-top:16px;text-align:center"><a href="index.php" class="btn" style="display:inline-block;text-decoration:none;width:auto;padding:10px 32px">进入系统</a></p>
<?php endif; ?>

</div>
</body>
</html>
